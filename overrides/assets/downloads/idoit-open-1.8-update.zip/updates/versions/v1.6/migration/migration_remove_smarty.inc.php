<?php
/**
 * i-doit - Updates
 *
 *
 * @package     i-doit
 * @subpackage  Update
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 * @author      Dennis Stücken <dstuecken@i-doit.de>
 */
register_shutdown_function(
    function ()
    {
        $smarty_dir = rtrim(isys_application::instance()->app_path, DS) . DS . 'src' . DS . 'classes' . DS . 'libraries' . DS . 'smarty' . DS;

        isys_glob_delete_recursive($smarty_dir . 'internals', $deleted, $undeleted);
        isys_glob_delete_recursive($smarty_dir . 'libs', $deleted, $undeleted);

        @unlink($smarty_dir . 'Smarty.class.php');
        @unlink($smarty_dir . 'change_log.txt');
        @unlink($smarty_dir . 'Config_File.class.php');
        @unlink($smarty_dir . 'COPYING.lib');
        @unlink($smarty_dir . 'debug.tpl');
        @unlink($smarty_dir . 'README');
        @unlink($smarty_dir . 'SMARTY_2_BC_NOTES.txt');
        @unlink($smarty_dir . 'SMARTY_3.0_BC_NOTES.txt');
        @unlink($smarty_dir . 'SMARTY_3.1_NOTES.txt');
        @unlink($smarty_dir . 'Smarty_Compiler.class.php');
        @unlink(rtrim(isys_application::instance()->app_path, DS) . DS . 'temp/cache__autoload.php');

    }
);