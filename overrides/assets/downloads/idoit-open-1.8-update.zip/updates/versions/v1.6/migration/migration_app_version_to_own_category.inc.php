<?php
/**
 * i-doit - Updates
 * This migration shall bring "version" information from all specific application categories to the global "version" category.
 *
 * @package     i-doit
 * @subpackage  Update
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 * @author      Leonard Fischer <lfischer@i-doit.com>
 */

// Initialization
global $g_comp_database, $g_comp_database_system;

$g_migration_identifier = "migration_app_version_to_own_category";

if ($this->is_migration_done($g_migration_identifier))
{
	$g_migration_log[] = "<span class=\"bold grey indent\">Version Migration has already been executed.</span>";
}
else
{
	try
	{
		$l_dao = new isys_cmdb_dao($g_comp_database);

		$l_res = $l_dao->retrieve('SELECT * FROM isys_cats_application_list WHERE isys_cats_application_list__release <> "";');

		if (count($l_res))
		{
			$g_migration_log[] = '<span class="bold">Starting migration of ' . count($l_res) . '...</span>';

			while ($l_row = $l_res->get_row())
			{
				$g_migration_log[] = '<span class="indent">Migration version from Object # ' . $l_row['isys_cats_application_list__isys_obj__id'] . ' (Version "' . $l_row['isys_cats_application_list__release'] . '").</span>';
				$l_sql = 'INSERT INTO isys_catg_version_list SET
					isys_catg_version_list__isys_obj__id = ' . $l_dao->convert_sql_id($l_row['isys_cats_application_list__isys_obj__id']) . ',
					isys_catg_version_list__title = ' . $l_dao->convert_sql_text($l_row['isys_cats_application_list__release']) . ',
					isys_catg_version_list__status = ' . $l_dao->convert_sql_int(C__RECORD_STATUS__NORMAL) . ';';

				$l_dao->update($l_sql);
			} // while

			$l_dao->apply_update();
		}
		else
		{
			$g_migration_log[] = '<span class="bold">No rows to migrate :)</span>';
		} // if

		// Set flag in db.
		$this->migration_done($g_migration_identifier);

		$g_migration_log[] = "<span class=\"bold\">Migration successful.</span>";
	}
	catch (Exception $e)
	{
		$g_migration_log[] = "<span class=\"bold red\">" . $e->getMessage() . "</span>";
	} // try
} // if