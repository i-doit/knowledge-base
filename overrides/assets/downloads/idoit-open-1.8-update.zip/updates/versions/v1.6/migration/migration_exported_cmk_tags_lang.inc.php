<?php
/**
 * i-doit - Updates
 *
 * This migration migrates all data from isys_check_mk_exported_tags to use "english" as the default language.
 *
 * @package     i-doit
 * @subpackage  Update
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 * @author      Leonard Fischer <lfischer@i-doit.com>
 */

// Initialization
global $g_comp_database, $g_comp_database_system;

$g_migration_identifier = "migration_exported_cmk_tags_language";

if ($this->is_migration_done($g_migration_identifier))
{
	$g_migration_log[] = "<span class=\"bold grey indent\">Migration of exported Check_MK tags. Their default language is set to english.</span>";
}
else
{
	try
	{
		$l_dao_system = new isys_cmdb_dao($g_comp_database_system);
		$l_dao = new isys_cmdb_dao($g_comp_database);

		$l_english_language_id = $l_dao_system->retrieve('SELECT isys_language__id FROM isys_language WHERE isys_language__const = "ISYS_LANGUAGE_ENGLISH";')->get_row_value('isys_language__id');

		$l_dao->update('UPDATE isys_check_mk_exported_tags SET isys_check_mk_exported_tags__language = ' . $l_dao->convert_sql_id($l_english_language_id) . ';');
		$l_dao->apply_update();

		// Set flag in db.
		$this->migration_done($g_migration_identifier);

		$g_migration_log[] = "<span class=\"bold indent\">Migration successful.</span>";
	}
	catch (Exception $e)
	{
		$g_migration_log[] = "<span class=\"bold red\">" . $e->getMessage() . "</span>";
	} // try
} // if