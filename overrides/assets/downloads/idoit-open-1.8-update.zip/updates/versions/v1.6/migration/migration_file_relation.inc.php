<?php
/**
 * i-doit - Updates
 * This migration updates all file assignment with a relation entry
 *
 * @package     i-doit
 * @subpackage  Update
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 * @author      Van Quyen Hoang <qhoang@i-doit.com>
 */

// Initialization
global $g_comp_database, $g_comp_database_system;

$g_migration_identifier = "migration_file_relation";

if ($this->is_migration_done($g_migration_identifier))
{
	$g_migration_log[] = "<span class=\"bold grey indent\">File relation Migration has already been executed.</span>";
}
else
{
	try
	{
		$l_dao = new isys_cmdb_dao_category_g_relation($g_comp_database);

		$l_sql = 'SELECT * FROM isys_catg_file_list
			INNER JOIN isys_connection ON isys_connection__id = isys_catg_file_list__isys_connection__id
			WHERE isys_connection__isys_obj__id IS NOT NULL
				AND isys_catg_file_list__isys_catg_relation_list__id IS NULL
				AND isys_catg_file_list__status = ' . C__RECORD_STATUS__NORMAL;
		$l_res = $l_dao->retrieve($l_sql);

		if (count($l_res))
		{
			$l_relation_type_data = $l_dao->get_relation_type('C__RELATION_TYPE__FILE', null, true);

			$g_migration_log[] = '<span class="bold">Starting migration of ' . count($l_res) . '...</span>';

			while ($l_row = $l_res->get_row())
			{
				$g_migration_log[] = '<span class="indent">Migration version from Object # ' . $l_row['isys_cats_application_list__isys_obj__id'] . ' (Version "' . $l_row['isys_cats_application_list__release'] . '").</span>';
				$l_dao->handle_relation($l_row['isys_catg_file_list__id'], 'isys_catg_file_list',
					$l_relation_type_data['isys_relation_type__id'], null, $l_row['isys_catg_file_list__isys_obj__id'],
					$l_row['isys_connection__isys_obj__id']);
			} // while

			$l_dao->apply_update();
		}
		else
		{
			$g_migration_log[] = '<span class="bold">No rows to migrate :)</span>';
		} // if

		// Set flag in db.
		$this->migration_done($g_migration_identifier);

		$g_migration_log[] = "<span class=\"bold\">Migration successful.</span>";
	}
	catch (Exception $e)
	{
		$g_migration_log[] = "<span class=\"bold red\">" . $e->getMessage() . "</span>";
	} // try
} // if