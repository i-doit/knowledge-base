<?php
/**
 * i-doit - Updates
 * This migration brings all data from the specific to the global WAN category.
 * It also assignes the global category, where the specific one has been assigned.
 *
 * @package     i-doit
 * @subpackage  Update
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 * @author      Leonard Fischer <lfischer@i-doit.com>
 */

// Initialization
global $g_comp_database, $g_comp_database_system;

$g_migration_identifier = "migration_wan_category";

if ($this->is_migration_done($g_migration_identifier))
{
	$g_migration_log[] = "<span class=\"bold grey indent\">WAN Migration has already been executed.</span>";
}
else
{
	try
	{
		$l_dao = new isys_cmdb_dao($g_comp_database);
		$l_global_wan = $l_dao->retrieve('SELECT isysgui_catg__id FROM isysgui_catg WHERE isysgui_catg__const = "C__CATG__WAN";')->get_row_value('isysgui_catg__id');

		if (! $l_global_wan)
		{
			throw new isys_exception_general('Attention! The global WAN category (C__CATG__WAN) could not be found - migration will be aborted!');
		} // if

		$l_res = $l_dao->retrieve('SELECT * FROM isys_cats_wan_list;');

		if (count($l_res))
		{
			$g_migration_log[] = '<span class="bold">Starting migration of ' . count($l_res) . ' rows...</span>';

			while ($l_row = $l_res->get_row())
			{
				$g_migration_log[] = '<span class="indent">Migration data from Object # ' . $l_row['isys_cats_wan_list__isys_obj__id'] . '.</span>';
				$l_sql = 'INSERT INTO isys_catg_wan_list SET
					isys_catg_wan_list__isys_obj__id = ' . $l_dao->convert_sql_id($l_row['isys_cats_wan_list__isys_obj__id']) . ',
					isys_catg_wan_list__description = ' . $l_dao->convert_sql_text($l_row['isys_cats_wan_list__description']) . ',
					isys_catg_wan_list__isys_wan_type__id = ' . $l_dao->convert_sql_id($l_row['isys_cats_wan_list__isys_wan_type__id']) . ',
					isys_catg_wan_list__isys_wan_role__id = ' . $l_dao->convert_sql_id($l_row['isys_cats_wan_list__isys_wan_role__id']) . ',
					isys_catg_wan_list__capacity_up = ' . $l_dao->convert_sql_text($l_row['isys_cats_wan_list__capacity']) . ',
					isys_catg_wan_list__capacity_up_unit = ' . $l_dao->convert_sql_id($l_row['isys_cats_wan_list__isys_wan_capacity_unit__id']) . ',
					isys_catg_wan_list__capacity_down = ' . $l_dao->convert_sql_text($l_row['isys_cats_wan_list__capacity']) . ',
					isys_catg_wan_list__capacity_down_unit = ' . $l_dao->convert_sql_id($l_row['isys_cats_wan_list__isys_wan_capacity_unit__id']) . ',
					isys_catg_wan_list__max_capacity_up = ' . $l_dao->convert_sql_text($l_row['isys_cats_wan_list__capacity']) . ',
					isys_catg_wan_list__max_capacity_up_unit = ' . $l_dao->convert_sql_id($l_row['isys_cats_wan_list__isys_wan_capacity_unit__id']) . ',
					isys_catg_wan_list__max_capacity_down = ' . $l_dao->convert_sql_text($l_row['isys_cats_wan_list__capacity']) . ',
					isys_catg_wan_list__max_capacity_down_unit = ' . $l_dao->convert_sql_id($l_row['isys_cats_wan_list__isys_wan_capacity_unit__id']) . ',
					isys_catg_wan_list__status = ' . $l_dao->convert_sql_int($l_row['isys_cats_wan_list__status']) . ';';

				$l_dao->update($l_sql);
			} // while

			$l_dao->apply_update();
		}
		else
		{
			$g_migration_log[] = '<span class="bold">No rows to migrate :)</span>';
		} // if


		$l_res = $l_dao->retrieve('SELECT isys_obj_type__id FROM isys_obj_type
			INNER JOIN isysgui_cats ON isysgui_cats__id = isys_obj_type__isysgui_cats__id
			WHERE isysgui_cats__const = "C__CATS__WAN";');

		if (count($l_res))
		{
			$l_affected_object_types = array();
			$g_migration_log[] = '<span class="indent">Assigning the new global category to ' . count($l_res) . ' object types...</span>';

			while ($l_row = $l_res->get_row())
			{
				$g_migration_log[] = '<span class="bold">Assigning to object type ID #' . $l_row['isys_obj_type__id'] . '.</span>';
				$l_sql = 'INSERT INTO isys_obj_type_2_isysgui_catg SET
					isys_obj_type_2_isysgui_catg__isys_obj_type__id = ' . $l_dao->convert_sql_id($l_row['isys_obj_type__id']) . ',
					isys_obj_type_2_isysgui_catg__isysgui_catg__id = ' . $l_dao->convert_sql_id($l_global_wan) . ';';

				$l_affected_object_types[] = $l_row['isys_obj_type__id'];
				$l_dao->update($l_sql);
			} // while

			$g_migration_log[] = '<span class="indent">Detaching the specific WAN category from the affected object types.</span>';
			$l_sql = 'UPDATE isys_obj_type SET isys_obj_type__isysgui_cats__id = NULL WHERE isys_obj_type__id ' . $l_dao->prepare_in_condition($l_affected_object_types) . ';';
			$l_dao->update($l_sql);

			$l_dao->apply_update();
		}
		else
		{
			$g_migration_log[] = '<span class="bold">The specific WAN category was assigned nowhere :)</span>';
		} // if

		// Set flag in db.
		$this->migration_done($g_migration_identifier);

		$g_migration_log[] = "<span class=\"bold\">Migration successful.</span>";
	}
	catch (Exception $e)
	{
		$g_migration_log[] = "<span class=\"bold red\">" . $e->getMessage() . "</span>";
	} // try
} // if