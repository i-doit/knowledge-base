<?php
/**
 * i-doit - Updates
 *
 * This migration migrates all data from isys_cats_service_list to isys_cats_application_list
 *
 * @package     i-doit
 * @subpackage  Update
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 * @author      Van Quyen Hoang <qhoang@i-doit.com>
 */

// Initialization
global $g_comp_database, $g_absdir;
$g_migration_identifier = "migration_service_to_application";

if ($this->is_migration_done($g_migration_identifier))
{
	$g_migration_log[] = "<span class=\"bold grey indent\">Migration of specific category service to specific category application has already been executed.</span>";
} else
{
	try
	{
		$g_comp_database->query('SET SESSION group_concat_max_len = 9999999;');
		$l_dao = new isys_cmdb_dao($g_comp_database);

		// Migration log instance.
		$l_mig_log = isys_log_migration::get_instance()
			->reset_log()
			->add_migration_log('notice', 'Starting migration of specific category service to specific category application.');

		$l_category_id = $l_dao->retrieve('SELECT isysgui_cats__id FROM isysgui_cats WHERE isysgui_cats__const = \'C__CATS__SERVICE\';')
			->get_row_value('isysgui_cats__id');

		// @todo Update isysgui_cats with source_table isys_cats_application_list

		$l_sql = 'SELECT * FROM isys_service_manufacturer;';
		$l_res = $l_dao->retrieve($l_sql);
		$l_s_manufacturer = array();
		$l_s_manufacturer_map = array();
		if($l_res->num_rows() > 0)
		{
			while ($l_row = $l_res->get_row())
			{
				$l_s_manufacturer[$l_row['isys_service_manufacturer__title']] = $l_row['isys_service_manufacturer__id'];
				$l_s_manufacturer_map[$l_row['isys_service_manufacturer__id']] = $l_row;
			} // while
		} // if

		// Migrate manufacturer from service to application
		$l_sql = 'SELECT * FROM isys_application_manufacturer;';
		$l_res = $l_dao->retrieve($l_sql);
		$l_a_manufacturer = array();
		if($l_res->num_rows() > 0)
		{
			while ($l_row = $l_res->get_row())
			{
				$l_a_manufacturer[$l_row['isys_application_manufacturer__title']] = $l_row['isys_application_manufacturer__id'];
			} // while
		} // if

		$l_diff = array_diff_key($l_s_manufacturer, $l_a_manufacturer);

		if(count($l_diff) > 0)
		{
			foreach ($l_diff AS $l_id)
			{
				$l_insert = 'INSERT INTO isys_application_manufacturer (
				isys_application_manufacturer__title,
				isys_application_manufacturer__description,
				isys_application_manufacturer__const,
				isys_application_manufacturer__status,
				isys_application_manufacturer__property)
				VALUES(' . $l_dao->convert_sql_text($l_s_manufacturer_map[$l_id]['isys_service_manufacturer__title']) . ', ' .
					$l_dao->convert_sql_text($l_s_manufacturer_map[$l_id]['isys_service_manufacturer__description']) . ', ' .
					$l_dao->convert_sql_text($l_s_manufacturer_map[$l_id]['isys_service_manufacturer__const']) . ', ' .
					$l_dao->convert_sql_int($l_s_manufacturer_map[$l_id]['isys_service_manufacturer__status']) . ', ' .
					$l_dao->convert_sql_int($l_s_manufacturer_map[$l_id]['isys_service_manufacturer__property']) . ');';
				$l_dao->update($l_insert);
				$l_a_manufacturer[$l_s_manufacturer_map[$l_id]['isys_service_manufacturer__title']] = $l_dao->get_last_insert_id();
			} // foreach
		}

		$l_sql = 'SELECT * FROM isys_cats_service_list
 			INNER JOIN isys_obj ON isys_obj__id = isys_cats_service_list__isys_obj__id
 			LEFT JOIN isys_service_manufacturer ON isys_cats_service_list__isys_service_manufacturer__id = isys_service_manufacturer__id;';
		$l_res = $l_dao->retrieve($l_sql);
		if($l_res->num_rows() > 0)
		{
			while ($l_row = $l_res->get_row())
			{
				$l_manufacturer_id = $l_a_manufacturer[$l_row['isys_service_manufacturer__title']];
				$l_check_query = 'SELECT isys_cats_application_list__id FROM isys_cats_application_list
				WHERE isys_cats_application_list__isys_obj__id = ' . $l_dao->convert_sql_id($l_row['isys_cats_service_list__isys_obj__id']);
				$l_res_check = $l_dao->retrieve($l_check_query);
				if ($l_res_check->num_rows() > 0)
				{
					$l_row_check = $l_res_check->get_row();
					// Just in case the entry exists
					$l_update = 'UPDATE isys_cats_application_list SET
					isys_cats_application_list__isys_application_manufacturer__id = ' . $l_dao->convert_sql_id($l_manufacturer_id) . ',
					isys_cats_application_list__title = ' . $l_dao->convert_sql_text($l_row['isys_cats_service_list__title']) . ',
					isys_cats_application_list__specification = ' . $l_dao->convert_sql_text($l_row['isys_cats_service_list__specification']) . ',
					isys_cats_application_list__release = ' . $l_dao->convert_sql_text($l_row['isys_cats_service_list__release']) . ',
					isys_cats_application_list__status = ' . $l_dao->convert_sql_int(C__RECORD_STATUS__NORMAL) . ',
					isys_cats_application_list__description = ' . $l_dao->convert_sql_text($l_row['isys_cats_service_list__description']) . '
					WHERE isys_cats_application_list__id = ' . $l_dao->convert_sql_id($l_row_check['isys_cats_application_list__id']);
				}
				else
				{
					$l_update = 'INSERT INTO isys_cats_application_list (
					isys_cats_application_list__isys_obj__id,
					isys_cats_application_list__isys_application_manufacturer__id,
					isys_cats_application_list__title,
					isys_cats_application_list__specification,
					isys_cats_application_list__release,
					isys_cats_application_list__status,
					isys_cats_application_list__description
				) VALUES(
					' . $l_dao->convert_sql_id($l_row['isys_cats_service_list__isys_obj__id']) . ',
					' . $l_dao->convert_sql_id($l_manufacturer_id) . ',
					' . $l_dao->convert_sql_text($l_row['isys_cats_service_list__title']) . ',
					' . $l_dao->convert_sql_text($l_row['isys_cats_service_list__specification']) . ',
					' . $l_dao->convert_sql_text($l_row['isys_cats_service_list__release']) . ',
					' . $l_dao->convert_sql_int($l_row['isys_cats_service_list__status']) . ',
					' . $l_dao->convert_sql_text($l_row['isys_cats_service_list__description']) . '
				)';
				}
				$l_dao->update($l_update);
			} // while
		} // if

		// @todo get all object types with specific category service and update their obj type list if exists
		$l_res = $l_dao->get_objtype_by_cats_id($l_category_id);
		$l_obj_types = array();
		while($l_row = $l_res->get_row())
		{
			$l_obj_types[] = $l_row['isys_obj_type__id'];
		} // while

		// Rebuild object lists
		if(count($l_obj_types) > 0)
		{
			$l_sql = 'SELECT * FROM isys_obj_type_list INNER JOIN isys_obj_type ON isys_obj_type__id = isys_obj_type_list__isys_obj_type__id WHERE isys_obj_type_list__isys_obj_type__id IN (' . implode(',', $l_obj_types) . ');';
			$l_res = $l_dao->retrieve($l_sql);

			if($l_res->num_rows() > 0)
			{
				// Rebuild properties so that we get the correct ids for rebuilding the object lists
				$l_dao_property = new isys_cmdb_dao_category_property($g_comp_database);
				$l_dao_property->rebuild_properties();

				// Get list config from isys_cmdb_dao_list_s_service
				$l_sql = "SELECT * FROM isys_property_2_cat WHERE isys_property_2_cat__cat_const = 'C__CATS__SERVICE'";
				$l_res_properties = $l_dao_property->retrieve($l_sql);
				$l_property_map = $l_property_ids = array();

				while($l_row_property = $l_res_properties->get_row())
				{
					$l_property_map[$l_row_property['isys_property_2_cat__prop_key']] = $l_row_property['isys_property_2_cat__id'];
				} // while

				$l_old_property_map = array(
					'specification' => array(
						'specification',
						array(
							C__PROPERTY_TYPE__STATIC,
							'specification',
							'isys_cat_application_list__specification',
							'LC__CMDB__CATS__SERVICE_SPECIFICATION',
							'isys_cmdb_dao_category_s_service::get_properties_ng',
							false,
							'LC__CMDB__CATG__SERVICE'
						)
					),
					'service_manufacturer' => array(
						'manufacturer',
						array(
							C__PROPERTY_TYPE__STATIC,
							'manufacturer',
							'isys_application_manufacturer__title',
							'LC__CMDB__CATG__MANUFACTURE',
							'isys_cmdb_dao_category_s_service::get_properties_ng',
							false,
							'LC__CMDB__CATG__SERVICE'
						)
					),
					'release' => array(
						'release',
						array(
							C__PROPERTY_TYPE__STATIC,
							'release',
							'isys_cats_application_list__release',
							'LC__CMDB__CATS__APPLICATION_RELEASE',
							'isys_cmdb_dao_category_s_service::get_properties_ng',
							false,
							'LC__CMDB__CATG__SERVICE'
						)
					),
					'description' => array(
						'description',
						array(
							C__PROPERTY_TYPE__STATIC,
							'description',
							'isys_cats_application_list__description',
							'LC__CMDB__LOGBOOK__DESCRIPTION',
							'isys_cmdb_dao_category_s_service::get_properties_ng',
							false,
							'LC__CMDB__CATG__SERVICE'
						)
					)
				);
				$l_dao_plugin = new isys_smarty_plugin_f_property_selector();
				$l_class_arr = array();
				while ($l_row = $l_res->get_row())
				{
					$l_properties = isys_format_json::decode($l_row['isys_obj_type_list__config']);
					$l_new_preselection = $l_new_property = array();
					// Update properties
					$l_counter = 0;
					foreach($l_properties AS $l_key => $l_prop_data)
					{
						if($l_prop_data[0] == C__PROPERTY_TYPE__STATIC && isset($l_old_property_map[$l_prop_data[1]]))
						{
							$l_key = $l_old_property_map[$l_prop_data[1]][0];
							$l_prop_data = $l_old_property_map[$l_prop_data[1]][1];
						}
						$l_new_property[$l_key] = $l_prop_data;

						$l_class = substr($l_prop_data[4], 0, strpos($l_prop_data[4], '::'));
						if(!isset($l_class_arr[$l_class]))
						{
							$l_class_arr[$l_class] = new $l_class($g_comp_database);
						} // if
						$l_class_obj = $l_class_arr[$l_class];
						$l_category_id = $l_class_obj->get_category_id();

						if(strpos($l_prop_data[4], '_g_') !== false)
						{
							$l_cat_type = 'g';
						}
						else
						{
							$l_cat_type = 's';
						} // if

						$l_new_preselection[$l_counter][$l_cat_type] = array(
							$l_category_id => array(
								$l_prop_data[1]
							)
						);

						$l_counter++;
					}

					$l_preselection_data = $l_dao_plugin->handle_preselection($l_new_preselection);

					if(is_array($l_preselection_data))
					{
						$l_prop_ids = array();
						foreach($l_preselection_data AS $l_data)
						{
							$l_prop_ids[] = $l_data['prop_id'];
						} // foreach

						$l_new_query = $l_dao_property->create_property_query_for_lists($l_prop_ids, $l_row['isys_obj_type_list__isys_obj_type__id']);
						$l_update = 'UPDATE isys_obj_type_list SET isys_obj_type_list__query = ' . $l_dao->convert_sql_text($l_new_query) . ', isys_obj_type_list__config = ' . $l_dao->convert_sql_text(isys_format_json::encode($l_new_property)) . ' WHERE isys_obj_type_list__id = ' . $l_dao->convert_sql_id($l_row['isys_obj_type_list__id']);
						$l_dao->update($l_update);
					} // if
				} // while
			} // if
		} // if

		// Tidy up isys_application_manufacturer and remove all duplicates
		$l_query = 'SELECT GROUP_CONCAT( isys_application_manufacturer__id ) AS selection, isys_application_manufacturer__id
			FROM isys_application_manufacturer
			GROUP BY isys_application_manufacturer__title
			HAVING COUNT( * ) > 1
			ORDER BY isys_application_manufacturer__id DESC;';

		$l_res = $l_dao->retrieve($l_query);
		if($l_res->num_rows() > 0)
		{
			while ($l_row = $l_res->get_row())
			{
				$l_selection = rtrim($l_row['selection'], ',');
				$l_selection_arr = explode(',', $l_selection);
				if(count($l_selection_arr) > 50)
				{
					$l_chunked_array = array_chunk($l_selection_arr, 50);
					foreach($l_chunked_array AS $l_selection_part)
					{
						$l_update_query = 'UPDATE isys_cats_application_list
							SET isys_cats_application_list__isys_application_manufacturer__id = ' . $l_dao->convert_sql_id($l_row['isys_application_manufacturer__id']) . '
							WHERE ';

						if(count($l_selection_part) === 1)
						{
							$l_update_query .= 'isys_cats_application_list__isys_application_manufacturer__id = ' . $l_dao->convert_sql_id(array_pop($l_selection_part)) . ';';
						}
						else
						{
							$l_update_query .= 'isys_cats_application_list__isys_application_manufacturer__id IN (' . implode(',', $l_selection_part) . ');';
						} // if

						$l_dao->update($l_update_query);
					} // foreach
				}
				else
				{
					$l_update_query = 'UPDATE isys_cats_application_list
						SET isys_cats_application_list__isys_application_manufacturer__id = ' . $l_dao->convert_sql_id($l_row['isys_application_manufacturer__id']) . '
						WHERE ';
					$l_update_query .= 'isys_cats_application_list__isys_application_manufacturer__id IN (' . $l_selection . ');';

					$l_dao->update($l_update_query);
				} // if

				$l_selection = substr($l_selection, strpos($l_selection, ',') + 1);
				if($l_selection != '')
				{
					$l_selection_arr = explode(',', $l_selection);
					if(count($l_selection_arr) > 50)
					{
						// Split array in chunks
						$l_chunked_array = array_chunk($l_selection_arr, 50);
						foreach($l_chunked_array AS $l_selection_part)
						{
							$l_delete_query = 'DELETE FROM isys_application_manufacturer WHERE ';

							if(count($l_selection_part) === 1)
							{
								$l_delete_query .= 'isys_application_manufacturer__id = ' . $l_dao->convert_sql_id(array_pop($l_selection_part)) . ';';
							}
							else
							{
								$l_delete_query .= 'isys_application_manufacturer__id IN (' . implode(',', $l_selection_part) . ');';
							} // if
							$l_dao->update($l_delete_query);
						} // foreach
					}
					else
					{
						$l_delete_query = 'DELETE FROM isys_application_manufacturer WHERE isys_application_manufacturer__id IN (' . $l_selection . ');';
						$l_dao->update($l_delete_query);
					} // if
				} // if
			} // while
		} // if

		$l_dao->apply_update();

		// Set flag in db
		$this->migration_done($g_migration_identifier);

		$g_migration_log[] = "<span class=\"bold indent\">Migration successful.</span>";

		$g_migration_log = array_merge($l_mig_log->get_migration_log(), $g_migration_log);
	} catch (Exception $e)
	{
		$g_migration_log[] = "<span class=\"bold red\">" . $e->getMessage() . "</span>";
	} // try
}