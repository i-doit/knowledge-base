/**
 * Fast autocompletion using json requests and caching
 *
 * @author Dennis Stücken
 */
//if (typeof Autocompleter === 'undefined') { var Autocompleter = {}; }

(function () {
    "use strict";

    Autocompleter.Json = Class.create(Autocompleter.Base, {
        // holds the last selected entry of the completion list, null if none was selected
        selectedItem: null,

        initialize: function (element, update, lookupFunction, options) {
            options = options || {};
            options.minChars = options.minChars || 3;
            options.searchPlaceHolder = options.searchPlaceHolder || 'Search';
            options.updateElement = options.updateElement.bind(this) || null;

            this.baseInitialize(element, update, options);

            this.lookupFunction = lookupFunction;
            this.options.choices = options.choices || 120;
        },

        getUpdatedChoices: function () {
            this.lookupFunction(this.getToken().toLowerCase(), this.updateJsonChoices.bind(this));
        },

        updateJsonChoices: function (choices) {
            this.updateChoices(
                '<ul>' +
                '<li data-search="1"><div class="title search-for">' + this.options.searchPlaceHolder.format(this.element.value) + '</div></li>'+
                choices.slice(0, this.options.choices).map(this.jsonChoiceToListChoice.bind(this)).join('') +
                '</ul>'
            );
        },

        jsonChoiceToListChoice: function (choice/*, mark*/) {
            return '<li data-link="' + choice.link + '"><div class="type" title="' + choice.source + '">' + choice.source + '</div><div class="title" title="' + choice.value + '">' + choice.value + '</div></li>';
        }
    });

    // Schedule next request
    // Only remembers two at a time
    // Current, and the waiting one
    Autocompleter.RateLimiting = function () {
        this.currentRequest = null;
        this.scheduledRequest = null;
    };

    Autocompleter.RateLimiting.prototype = {

        schedule: function (f, searchTerm, callback) {
            this.scheduledRequest = {
                f:          f,
                searchTerm: searchTerm,
                callback:   callback
            };
            this._sendRequest();
        },

        _sendRequest: function () {
            if (!this.currentRequest)
            {
                this.currentRequest = this.scheduledRequest;
                this.scheduledRequest = null;

                this.currentRequest.f(this.currentRequest.searchTerm, this._callback.bind(this));
            }
        },

        _callback: function (data) {
            try
            {
                this.currentRequest.callback(data);
            }
            catch (e)
            {
            }
            this.currentRequest = null;

            if (this.scheduledRequest)
            {
                this._sendRequest();
            }
        }

    };

    Autocompleter.Cache = Class.create({
        initialize: function (backendLookup, options) {
            this.cache = new Hash();
            this.backendLookup = backendLookup;
            this.rateLimiter = new Autocompleter.RateLimiting();
            this.options = Object.extend({
                choices:            120,
                fuzzySearch:        false,
                fuzzyNumericSearch: false
            }, options || {});
        },

        lookup: function (term, callback) {
            return this._lookupInCache(term, null, callback) ||
                   this.rateLimiter.schedule(this.backendLookup, term,
                       this._storeInCache.curry(term, callback).bind(this));
        },

        _lookupInCache: function (fullTerm, partialTerm, callback) {
            partialTerm = partialTerm || fullTerm;
            var result = this.cache.get(partialTerm);

            if (result == null || typeof result != 'object')
            {
                if (partialTerm.length > 1)
                {
                    return this._lookupInCache(fullTerm, partialTerm.substr(0, partialTerm.length - 1), callback);
                }
                else
                {
                    return false;
                }
            }
            else
            {
                if (fullTerm != partialTerm)
                {
                    var hasMore = result.length > 0 && result[result.length - 1]['more'] == true;
                    result = this._localSearch(result, fullTerm);
                    if (!hasMore)
                    {
                        this._storeInCache(fullTerm, null, result);
                    }
                    else
                    {
                        if (result.length < this.options.choices)
                        {
                            return false
                        }
                    }
                }
                if (result.length > 0 && result[result.length - 1]['more'] != undefined)
                {
                    result = result.slice(0, result.length - 1);
                }
                callback(result.slice(0, this.options.choices));
                return true;
            }
        },

        _naturalCompare: function(a, b) {
            if (a != b) for (var i, ca, cb = 1, ia = 0, ib = 0; cb;) {
                ca = a.charCodeAt ? a.charCodeAt(ia++) : 0 || 0;
                cb = b.charCodeAt ? b.charCodeAt(ib++) : 0 || 0;

                if (ca < 58 && ca > 47 && cb < 58 && cb > 47) {
                    for (i = ia; ca = a.charCodeAt(ia), ca < 58 && ca > 47; ia++);
                    ca = (a.slice(i - 1, ia) | 0) + 1;
                    for (i = ib; cb = b.charCodeAt(ib), cb < 58 && cb > 47; ib++);
                    cb = (b.slice(i - 1, ib) | 0) + 1;
                }

                if (ca != cb) return (ca < cb) ? -1 : 1;
            }
            return 0;
        },

        _localSearch: function (data, term) {

            var foundItems = [];
            if (this.options.fuzzySearch)
            {
                var f = new Fuse(data, {
                    keys: ['value'],
                    threshold: 0.2,
                    distance: 50,
                    shouldSort: false
                });
                foundItems = f.search(term);
            }
            else
            {
                var item, exp = (this.options.fuzzySearch) && term.indexOf(' ') > 0 &&
                      (!this.options.fuzzyNumericSearch && isNaN(term)) ?
                new RegExp(term.gsub(/./, ".*#{0}"), 'i') :
                new RegExp(term.gsub(/\+\.\-\?\#/, ""), 'i');
                for (var i = 0, len = data.length; i < len; ++i)
                {
                    item = data[i];
                    if (exp.test(item.value))
                    {
                        foundItems.push(item);
                    }
                }
            }

            return foundItems.sort(function (a, b) {
                return typeof a == 'object' ? this._naturalCompare(a.value.toLowerCase(), b.value.toLowerCase()) : this._naturalCompare(a.toLowerCase(), b.toLowerCase());
            }.bind(this));
        },

        _storeInCache: function (term, callback, data) {
            this.cache.set(term, data);
            if (callback)
            {
                var items = data.slice(0, this.options.choices);
                if (items.length > 1 && items[items.length - 1]['more'] != undefined)
                {
                    items = items.slice(0, items.length - 1);
                }
                callback(items);
            }
        }
    });

}());