/**
 * i-doit javascript dragbar component
 * @author Van Quyen Hoang <qhoang@i-doit.org>
 */
var mainMenuObserver = Class.create({
	options: {},
	initialize: function (options) {
		this.options = Object.extend({
			scrollingInterval: ''
		}, options || {});

		this.$menuScrollLeft = $('menuScrollLeft');
		this.$menuScrollRight = $('menuScrollRight');
		this.$mainMenu = $('mainMenu');
		this.$mainMenuContainer = this.$mainMenu.up();
		this.$moduleDropDown = $('module-dropdown');
		this.$mainMenuArrowSprite = $('downarrow');

		this.menuObserverLoad();
		this.menuObserverResize();
		this.menuObserverBtnRight();
		this.menuObserverBtnLeft();
	},

	/**
	 * Moves mainmenu to the left
	 */
	scrollBtnRight: function () {
		var new_pos_left = parseInt(this.$mainMenuContainer.offsetLeft) - 80,
			new_pos_extra_menu = parseInt(((this.$moduleDropDown.getStyle('left')) ? this.$moduleDropDown.getStyle('left').substring(0, this.$moduleDropDown.getStyle('left').length - 2) : 0)) - 20,
			endRight = parseInt(document.body.clientWidth) - (parseInt(document.body.clientWidth) - new_pos_left - parseInt(this.$mainMenuContainer.getWidth())),
			searchBarLeft = parseInt($('searchBar').offsetLeft),
			arrowSprite = parseInt(this.$mainMenuArrowSprite.offsetLeft) - 20;

		this.$mainMenuContainer.setStyle({left: new_pos_left + 'px'});
		this.$moduleDropDown.setStyle({left: new_pos_extra_menu + 'px'});
		this.$mainMenuArrowSprite.setStyle({left: arrowSprite + 'px'});

		if (endRight < searchBarLeft) {
			clearInterval(this.options.scrollingInterval);
			this.$menuScrollRight.hide();
		}
	},

	/**
	 * Moves mainmenu to the right
	 */
	scrollBtnLeft: function () {
		var endLeft = parseInt(this.$mainMenuContainer.offsetLeft) - 40;
			new_pos_extra_menu = parseInt(((this.$moduleDropDown.getStyle('left')) ? this.$moduleDropDown.getStyle('left').substring(0, this.$moduleDropDown.getStyle('left').length - 2) : 0)) + 20,
			arrowSprite = parseInt(this.$mainMenuArrowSprite.offsetLeft) + 20;

		if (endLeft > 0) {
			clearInterval(this.options.scrollingInterval);
			this.$mainMenuContainer.setStyle({left: '0px'});
			this.$menuScrollLeft.hide();
		} else {
			this.$moduleDropDown.setStyle({left: new_pos_extra_menu + 'px'});
			this.$mainMenuContainer.setStyle({left: endLeft + 'px'});
			this.$mainMenuArrowSprite.setStyle({left: arrowSprite + 'px'});
		}
	},

	/**
	 * Observer which checks on load if the searchbar is over the mainmenu or not
	 */
	menuObserverLoad: function () {
		new Event.observe(window, 'load', function () {
			var endLeft = parseInt(this.$mainMenuContainer.offsetLeft),
				endRight = parseInt(document.body.clientWidth) - (parseInt(document.body.clientWidth) - endLeft - parseInt(this.$mainMenuContainer.getWidth())),
				leftPosSearchBar = parseInt(document.body.clientWidth) - parseInt($('searchBar').getWidth());

			if (endRight > leftPosSearchBar) {
				this.$menuScrollRight.show();
			}
		}.bind(this));
	},

	/**
	 * Window resize observer
	 */
	menuObserverResize: function () {
		new Event.observe(window, 'resize', function () {
			var endLeft = parseInt(this.$mainMenuContainer.offsetLeft),
				endRight = parseInt(document.body.clientWidth) - (parseInt(document.body.clientWidth) - endLeft - parseInt(this.$mainMenuContainer.getWidth())),
				leftPosSearchBar = parseInt(document.body.clientWidth) - parseInt($('searchBar').getWidth());

			if (endRight > leftPosSearchBar) {
				this.$menuScrollRight.show();
			} else {
				this.$mainMenuContainer.setStyle({left: '0px'});
				this.$moduleDropDown.setStyle({left: $('mainMenu').down('.extras').offsetLeft + 'px'});
				this.$menuScrollRight.hide();
				this.$menuScrollLeft.hide();
				// move downarrow to new position
				move_arrow_to(this.$mainMenuContainer.down('.active'));
			}
		}.bind(this));

		this.calculateMainMenuWidth();
	},

	/**
	 * Method for calculating the pixel-width of #mainMenu.
	 */
	calculateMainMenuWidth: function () {
		var $menuItems = this.$mainMenu.select('li'),
			width;

		try {
			// Each menu item has a 10px margin.
			width = $menuItems.invoke('getWidth').sum() + $menuItems.length * 10;
		} catch (e) {
			width = this.$mainMenu.getWidth();
		}

		this.$mainMenu.setStyle({width: (60 + width) + 'px'});
	},

	/**
	 * Observer for the right button
	 */
	menuObserverBtnRight: function () {
		this.$menuScrollRight.on('mousedown', function () {
			var endLeft = parseInt(this.$mainMenuContainer.offsetLeft),
				endRight = parseInt(document.body.clientWidth) - (parseInt(document.body.clientWidth) + endLeft - parseInt(this.$mainMenuContainer.getWidth())),
				searchBarLeft = parseInt($('searchBar').offsetLeft);

			if (searchBarLeft <= endRight) {
				this.$menuScrollLeft.show();
				this.options.scrollingInterval = setInterval(this.scrollBtnRight.bind(this), 50);
			}
		}.bind(this));

		this.$menuScrollRight.on('mouseup', function () {
			clearInterval(this.options.scrollingInterval);
		}.bind(this));
	},

	/**
	 * Observer for the left button
	 */
	menuObserverBtnLeft: function () {
		this.$menuScrollLeft.on('mousedown', function () {
			if (parseInt(this.$mainMenuContainer.offsetLeft) <= 0) {
				this.$menuScrollRight.show();
				this.options.scrollingInterval = setInterval(this.scrollBtnLeft.bind(this), 50);
			}
		}.bind(this));

		this.$menuScrollLeft.on('mouseup', function () {
			clearInterval(this.options.scrollingInterval);
		}.bind(this));
	}
});