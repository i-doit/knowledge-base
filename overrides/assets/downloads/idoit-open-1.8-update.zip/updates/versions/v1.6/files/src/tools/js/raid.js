function raidcalc (p_disks, p_space, p_raidtype, p_target, p_targetReal) {
	var l_num_disks = parseInt(p_disks),
		l_space = "-",
		l_message = "",
		l_diskspace_each = parseFloat(p_space),
		l_diskspace,
		strUtilization,
		strUtilization2,
		l_space_real;

	if (l_num_disks % 2 != 0 && p_raidtype == "1") {
		l_message = " Disk amount must be a multiple of 2.";
		l_num_disks--;
	}
	if (l_num_disks % 2 != 0 && p_raidtype == "10") {
		l_message = " Disk amount must be a multiple of 2.";
		l_num_disks--;
	}

	l_diskspace = (l_num_disks * l_diskspace_each);

	switch (p_raidtype) {
		case "1":
			if (l_num_disks >= 2) {
				strUtilization = l_diskspace / 2;
				strUtilization2 = ((l_diskspace * 1000000000) / 1073741824) / 2;
				l_space = parseInt(strUtilization * 100) / 100;
				l_space_real = parseInt(strUtilization2 * 100) / 100;
			}
			break;
		case "10":
			if (l_num_disks >= 4) {
				strUtilization = l_diskspace / 2;
				strUtilization2 = ((l_diskspace * 1000000000) / 1073741824) / 2;
				l_space = parseInt(strUtilization * 100) / 100;
				l_space_real = parseInt(strUtilization2 * 100) / 100;
			}
			break;
		case "2":

			break;
		case "3":
			if (l_num_disks >= 3) {
				strUtilization = (l_diskspace * ((parseInt(((l_num_disks - 1) / l_num_disks) * 10000) / 100) / 100));
				strUtilization2 = (((l_diskspace * 1000000000) / 1073741824) * ((parseInt(((l_num_disks - 1) / l_num_disks) * 10000) / 100) / 100));
				l_space = parseInt(strUtilization * 100) / 100;
				l_space_real = parseInt(strUtilization2 * 100) / 100;
			}
			break;
		case "4":
			if (l_num_disks >= 3) {
				strUtilization = (l_diskspace * ((parseInt(((l_num_disks - 1) / l_num_disks) * 10000) / 100) / 100));
				strUtilization2 = (((l_diskspace * 1000000000) / 1073741824) * ((parseInt(((l_num_disks - 1) / l_num_disks) * 10000) / 100) / 100));

				l_space = parseInt(strUtilization * 100) / 100;
				l_space_real = parseInt(strUtilization2 * 100) / 100;
			}
			break;
		case "5":
			if (l_num_disks >= 3) {
				//strUtilization = (l_diskspace * ((parseInt(((l_num_disks-1)/l_num_disks)*10000)/100)/100));
				strUtilization = (l_diskspace / parseInt(l_num_disks)) * (parseInt(l_num_disks) - 1);
				strUtilization2 = (((l_diskspace * 1000000000) / 1073741824) * ((parseInt(((l_num_disks - 1) / l_num_disks) * 10000) / 100) / 100))

				l_space = parseInt(strUtilization * 100) / 100;
				l_space_real = parseInt(strUtilization2 * 100) / 100;
			}
			break;
		case "6":
			if (l_num_disks >= 4) {
				strUtilization = (l_diskspace * ((parseInt(((l_num_disks - 2) / l_num_disks) * 10000) / 100) / 100));
				strUtilization2 = (((l_diskspace * 1000000000) / 1073741824) * ((parseInt(((l_num_disks - 1) / l_num_disks) * 10000) / 100) / 100))

				l_space = parseInt(strUtilization * 100) / 100;
				l_space_real = parseInt(strUtilization2 * 100) / 100;
			}
			break;
		case "0":
			if (l_num_disks >= 2) {
				strUtilization = l_diskspace;
				strUtilization2 = ((l_diskspace * 1000000000) / 1073741824);

				l_space = parseInt(strUtilization * 100) / 100 + l_message;
				l_space_real = parseInt(strUtilization2 * 100) / 100;
			}
			break;
	}

	if ($(p_target)) {
		if (l_space != 0 && isNumeric(l_space)) {
			$(p_target).update(l_space + ' GB');

		} else {
			$(p_target).update('0.00');
		}
	}

	if (l_space != 0 && isNumeric(l_space)) {
		return l_space;
	}
}