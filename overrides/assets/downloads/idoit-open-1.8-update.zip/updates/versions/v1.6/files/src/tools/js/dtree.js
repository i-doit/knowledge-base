/*--------------------------------------------------|
 | dTree 2.05 | www.destroydrop.com/javascript/tree/ |
 |---------------------------------------------------|
 | Copyright (c) 2002-2003 Geir Landrö               |
 |                                                   |
 | This script can be used freely as long as all     |
 | copyright messages are intact.                    |
 |                                                   |
 | Updated: 17.04.2003                               |
 |--------------------------------------------------*/

/*--------------------------------------------------|
 | Updated: 17.06.2005                               |
 | i-doit 0.9                                        |
 | new parameter action                              |
 | extend the script to save values in js-vars		|
 | by mouseclick on folderNodes.						|
 | Used to save the objID of containerObj 			|
 | in LoactionViewMode.  							|
 | By changing to ObjectViewMode through press the 	|
 | TreeViewButtons this Parameter is stored as a GET	|
 | Parameter.                                        |
 |--------------------------------------------------*/

var menu_tree = null;
var drops = [];

// dNode object
function dNode(id, pid, name, url, title, target, icon, iconOpen, open, action, backSrc, class_name) {
	this.id = id;
	this.pid = pid;
	this.name = name;
	this.url = url;
	this.title = title;
	this.target = target;
	this.icon = icon;
	this.iconOpen = iconOpen;
	this.backSrc = backSrc;
	this._io = open || false;
	this._is = false;
	this._ls = false;
	this._hc = false;
	this._ai = 0;
	this._p;
	this.class_name = class_name || '';

	if (typeof action != "undefined") {
		this.action = action;
	} else {
		this.action = '';
	}
}

// Tree object
function dTree(objName, dirIcons) {
	this.config = {
		target: null,
		folderLinks: true,
		useSelection: true,
		useCookies: false,
		useLines: true,
		useIcons: true,
		useStatusText: false,
		closeSameLevel: false,
		inOrder: false,
		searcheable: true
	};

	this.icon = {
		root: window.dir_images + 'icons/silk/house.png',
		folder: dirIcons + 'folder.gif',
		folderOpen: dirIcons + 'folderopen.gif',
		node: dirIcons + 'page.gif',
		empty: dirIcons + 'empty.gif',
		line: dirIcons + 'line.gif',
		join: dirIcons + 'join.gif',
		joinBottom: dirIcons + 'joinbottom.gif',
		plus: dirIcons + 'plus.gif',
		plusBottom: dirIcons + 'plusbottom.gif',
		minus: dirIcons + 'minus.gif',
		minusBottom: dirIcons + 'minusbottom.gif',
		nlPlus: dirIcons + 'nolinesplus.gif',
		nlMinus: dirIcons + 'nolinesminus.gif',
		eye:[window.dir_images + 'icons/eye.png', window.dir_images + 'icons/eye-strike.png']
	};

	this.obj = objName;
	this.aNodes = [];
	this.aIndent = [];
	this.root = new dNode(-1);
	this.selectedNode = null;
	this.selectedFound = false;
	this.completed = false;
}

// Adds a new node to the node array
dTree.prototype.add = function(id, pid, name, url, title, target, icon, iconOpen, open, action, p_selected, backSrc, class_name) {
	this.aNodes[this.aNodes.length] = new dNode(id, pid, name, url, title, target, icon, iconOpen, open, action, backSrc, class_name);

	if (p_selected != 0) {
		this.selectedNode = this.aNodes.length - 1 ; // selected needs index
		this.selectedFound = true;
	}
};

// Open all nodes.
dTree.prototype.openAll = function() {
	this.oAll(true);
};

// Close all nodes.
dTree.prototype.closeAll = function() {
	this.oAll(false);
};

// Outputs the tree to the page.
dTree.prototype.toString = function () {
	var str = '<div class="dtree">\n';

	if (this.config.useCookies) {
		this.selectedNode = this.getSelected();
	}

	str += this.addNode(this.root, '');
	str += '</div>';

	if (!this.selectedFound) {
		this.selectedNode = null;
	}

	this.completed = true;

	return str;
};

// Creates the tree structure.
dTree.prototype.addNode = function (pNode) {
	var str = '',
		n = 0,
		cn;

	if (this.config.inOrder) {
		n = pNode._ai;
	}

	for (n; n < this.aNodes.length; n++) {
		if (this.aNodes[n].pid == pNode.id) {
			cn = this.aNodes[n];
			cn._p = pNode;
			cn._ai = n;

			this.setCS(cn);

			if (!cn.target && this.config.target) {
				cn.target = this.config.target;
			}

			if (cn._hc && !cn._io && this.config.useCookies) {
				cn._io = this.isOpen(cn.id);
			}

			if (!this.config.folderLinks && cn._hc) {
				cn.url = null;
			}

			if (this.config.useSelection && cn.id == this.selectedNode && !this.selectedFound) {
				cn._is = true;

				this.selectedNode = n;
				this.selectedFound = true;
			}

			str += this.node(cn, n);

			if (cn._ls) {
				break;
			}
		}
	}

	return str;
};


// Creates the node icon, url and text
dTree.prototype.node = function(node, nodeId) {
	var str = '<div class="node ' + (node.class_name || '') + '" data-nodeid="' + node.id + '" >' + this.indent(node, nodeId),
		class_name;

	if (this.config.useIcons) {
		if (!node.icon) {
			node.icon = (this.root.id == node.pid) ? this.icon.root : ((node._hc) ? this.icon.folder : this.icon.node);
		}

		if (!node.iconOpen) {
			node.iconOpen = (node._hc) ? this.icon.folderOpen : this.icon.node;
		}

		str += '<img id="i' + this.obj + nodeId + '" src="' + ((node._io) ? node.iconOpen : node.icon) + '" class="nodeIcon" />';
	}

	if (node.url) {
		// Store class name
		if (nodeId == this.selectedNode) {
			// dNode is selected
			class_name = 'nodeSel';
		} else {
			// Normal view
			class_name = 'node';
		}

		// Check if url is a real link
		if(node.url == 'javascript:;') {
			class_name = 'nodeDisabled';
		}

		if (nodeId == 0) {
			class_name = "rootNode";
		}

		str += '<a id="s' + this.obj + nodeId + '" class="' + class_name + '" href="' + node.url + '"';

		if (node.title) {
			str += ' title="' + node.title + '"';
		}

		if (node.target) {
			str += ' target="' + node.target + '"';
		}

		if (this.config.useStatusText) {
			str += ' onmouseover="window.status=\'' + node.name + '\';return true;" onmouseout="window.status=\'\';return true;" ';
		}

		if (this.config.useSelection && ((node._hc && this.config.folderLinks) || !node._hc)) {
			if (node.url != 'javascript:;') {
				str += ' onclick="javascript: ' + this.obj + '.s(' + nodeId + ');"';
			}
		}

		str += '>';

		if (typeof node.id == 'number')
			drops.push({
				nodeid:	nodeId,
				id: node.id
			});
	} else if ((!this.config.folderLinks || !node.url) && node._hc && node.pid != this.root.id) {
		if (node.action != '') {
			// put in some action :)
			str += '<a href="javascript: ' + this.obj + '.o(' + nodeId + ');' + node.action + '" class="node">';
		} else {
			str += '<a href="javascript: ' + this.obj + '.o(' + nodeId + ');" class="node">';
		}
	}

	str += node.name;

	if (node.url || ((!this.config.folderLinks || !node.url) && node._hc)) {
		str += '</a>';
	}

	str += '</div>';

	if (node._hc) {
		str += '<div id="d' + this.obj + nodeId + '" class="clip" style="display:' + ((this.root.id == node.pid || node._io) ? 'block' : 'none') + ';">';
		str += this.addNode(node);
		str += '</div>';
	}

	this.aIndent.pop();

	return str;
};

// Adds the empty and line icons
dTree.prototype.indent = function(node, nodeId) {
	var str     = '';
	var backSrc = '';

	//see if there is a background image
	if(node.backSrc.length > 0){
		backSrc = 'background-image:url('+node.backSrc+');';
	}

	if (this.root.id != node.pid) {
		for (var n=0; n<this.aIndent.length; n++) {
			str += '<img src="' + ( (this.aIndent[n] == 1 && this.config.useLines) ? this.icon.line : this.icon.empty ) + '" alt="" />';
		}

		(node._ls) ? this.aIndent.push(0) : this.aIndent.push(1);

		if (node._hc) {
			str+= '<a href="javascript: ' + this.obj + '.o(' + nodeId + ');"><img ';
			str+= 'style="'+backSrc+'" ';
			str+= 'id="j' + this.obj + nodeId + '" src="';

			if (!this.config.useLines) {
				str+= (node._io) ? this.icon.nlMinus : this.icon.nlPlus;
			} else {
				str+= ((node._io) ? ((node._ls && this.config.useLines) ? this.icon.minusBottom : this.icon.minus) : ((node._ls && this.config.useLines) ? this.icon.plusBottom : this.icon.plus ));
			}

			str += '" alt="" /></a>';

		} else {
			str += '<img style="'+backSrc+'" src="' + ( (this.config.useLines) ? ((node._ls) ? this.icon.joinBottom : this.icon.join ) : this.icon.empty) + '" alt="" />';
		}
	}

	return str;
};

// Checks if a node has any children and if it is the last sibling
dTree.prototype.setCS = function(node) {

	var lastId;

	for (var n=0; n<this.aNodes.length; n++) {

		if (this.aNodes[n].pid == node.id) node._hc = true;

		if (this.aNodes[n].pid == node.pid) lastId = this.aNodes[n].id;

	}

	if (lastId==node.id) node._ls = true;

};



// Returns the selected node

dTree.prototype.getSelected = function() {

	var sn = this.getCookie('cs' + this.obj);

	return (sn) ? sn : null;

};



// Highlights the selected node

dTree.prototype.s = function(id) {

	if (!this.config.useSelection) return;

	var cn = this.aNodes[id];

	if (cn._hc && !this.config.folderLinks) return;

	if (this.selectedNode != id) {

		if (this.selectedNode || this.selectedNode==0) {

			eOld = document.getElementById("s" + this.obj + this.selectedNode);

			if (eOld)
				eOld.className = "node";

		}

		eNew = $("s" + this.obj + id);

		if (eNew) {
			eNew.className = "nodeSel";
		}

		this.selectedNode = id;

		if (this.config.useCookies) this.setCookie('cs' + this.obj, cn.id);

	}

};



// Toggle Open or close

dTree.prototype.o = function (id) {
	var cn = this.aNodes[id];

	if (cn) {

		this.nodeStatus(!cn._io, id, cn._ls);

		cn._io = !cn._io;

		if (this.config.closeSameLevel) {
			this.closeLevel(cn);
		}

		if (this.config.useCookies) {
			this.updateCookie();
		}
	}
};

dTree.prototype.getNodeIdByName = function(name) {

	for (var n=0; n<this.aNodes.length; n++)
    {

        if (name == this.aNodes[n].name)
        {
            return this.aNodes[n].id;
        }
    }

    return null;
};

dTree.prototype.getNodeIdsByName = function(name, fuzzy) {

    var foundNodes = [];

	for (var n=0; n<this.aNodes.length; n++)
    {

        if (name == this.aNodes[n].name)
        {
            foundNodes.push(this.aNodes[n].id);
        }
    }

    return foundNodes;
};

// Open or close all nodes

dTree.prototype.oAll = function(status) {

	for (var n=0; n<this.aNodes.length; n++) {

		if (this.aNodes[n]._hc && this.aNodes[n].pid != this.root.id) {

			this.nodeStatus(status, n, this.aNodes[n]._ls);

			this.aNodes[n]._io = status;

		}

	}

	if (this.config.useCookies) this.updateCookie();

};

// Opens the tree to a specific node.
dTree.prototype.openTo = function (nId, bSelect, bFirst) {
	if (!bFirst) {
		for (var n = 0; n < this.aNodes.length; n++) {
			if (this.aNodes[n].id == nId) {
				nId = n;

				break;
			}
		}
	}

	var cn = this.aNodes[nId];
	if (cn) {
		if (cn.pid == this.root.id || !cn._p) {
			return;
		}

		cn._io = true;
		cn._is = bSelect;

		if (this.completed && cn._hc) {
			this.nodeStatus(true, cn._ai, cn._ls);
		}

		if (this.completed && bSelect) {
			this.s(cn._ai);
		} else if (bSelect) {
			this._sn = cn._ai;
		}

		this.openTo(cn._p._ai, false, true);
	}
};

// Closes all nodes on the same level as certain node.
dTree.prototype.closeLevel = function (node) {
	for (var n = 0; n < this.aNodes.length; n++) {
		if (this.aNodes[n].pid == node.pid && this.aNodes[n].id != node.id && this.aNodes[n]._hc) {

			this.nodeStatus(false, n, this.aNodes[n]._ls);

			this.aNodes[n]._io = false;

			this.closeAllChildren(this.aNodes[n]);
		}
	}
};

// Closes all children of a node.
dTree.prototype.closeAllChildren = function (node) {
	for (var n = 0; n < this.aNodes.length; n++) {
		if (this.aNodes[n].pid == node.id && this.aNodes[n]._hc) {
			if (this.aNodes[n]._io) {
				this.nodeStatus(false, n, this.aNodes[n]._ls);
			}

			this.aNodes[n]._io = false;

			this.closeAllChildren(this.aNodes[n]);
		}
	}
};

// Change the status of a node(open or closed)
dTree.prototype.nodeStatus = function (status, id, bottom) {
	var eDiv = document.getElementById('d' + this.obj + id),
		eJoin = document.getElementById('j' + this.obj + id);

	if (this.config.useIcons) {
		eIcon = document.getElementById('i' + this.obj + id);

		eIcon.src = (status) ? this.aNodes[id].iconOpen : this.aNodes[id].icon;
	}

	eJoin.src = (this.config.useLines) ?
		((status) ? ((bottom) ? this.icon.minusBottom : this.icon.minus) : ((bottom) ? this.icon.plusBottom : this.icon.plus)) :
		((status) ? this.icon.nlMinus : this.icon.nlPlus);

	eDiv.style.display = (status) ? 'block' : 'none';
};

// [Cookie] Clears a cookie.
dTree.prototype.clearCookie = function () {
	var now = new Date(),
		yesterday = new Date(now.getTime() - 1000 * 60 * 60 * 24);

	this.setCookie('co' + this.obj, 'cookieValue', yesterday);
	this.setCookie('cs' + this.obj, 'cookieValue', yesterday);
};

// [Cookie] Sets value in a cookie
dTree.prototype.setCookie = function (cookieName, cookieValue, expires, path, domain, secure) {
	document.cookie = escape(cookieName) + '=' + escape(cookieValue) +
		(expires ? '; expires=' + expires.toGMTString() : '') +
		(path ? '; path=' + path : '') +
		(domain ? '; domain=' + domain : '') +
		(secure ? '; secure' : '');
};

// [Cookie] Gets a value from a cookie.
dTree.prototype.getCookie = function (cookieName) {
	var cookieValue = '',
		posName = document.cookie.indexOf(escape(cookieName) + '='),
		posValue,
		endPos;

	if (posName != -1) {
		posValue = posName + (escape(cookieName) + '=').length;
		endPos = document.cookie.indexOf(';', posValue);

		if (endPos != -1) {
			cookieValue = unescape(document.cookie.substring(posValue, endPos));
		}

		else {
			cookieValue = unescape(document.cookie.substring(posValue));
		}
	}

	return (cookieValue);
};

// [Cookie] Returns ids of open nodes as a string.
dTree.prototype.updateCookie = function () {
	var str = '';

	for (var n = 0; n < this.aNodes.length; n++) {
		if (this.aNodes[n]._io && this.aNodes[n].pid != this.root.id) {
			if (str) {
				str += '.';
			}

			str += this.aNodes[n].id;
		}
	}

	this.setCookie('co' + this.obj, str);
};

// [Cookie] Checks if a node id is in a cookie.
dTree.prototype.isOpen = function (id) {
	var aOpen = this.getCookie('co' + this.obj).split('.');

	for (var n = 0; n < aOpen.length; n++) {
		if (aOpen[n] == id) {
			return true;
		}
	}

	return false;
};


/* -------------------------------------------------------------------------- */
/*                          Searcheable-Handling                              */
/* -------------------------------------------------------------------------- */
dTree.prototype.addSearchCapabilities = function ()
{
	var $rootNodeContainer = $(this.obj).down('div[data-nodeid=0]');

	if ($rootNodeContainer && $(this.obj).down('div[data-nodeid=0] > a')) {
		var $search_icon = new Element('img', {src: window.dir_images + 'icons/silk/magnifier.png', id: 'treeSearchIcon', className: 'treeSearchIcon greyscale'});
		var $search_field = new Element('input', {type: 'search', id: 'treeSearchInput', placeholder: 'Suche..', style: 'display:none;border-radius:0;'});

		$rootNodeContainer
			.insert($search_field)
			.insert($search_icon);

		$('treeSearchIcon').on("click", function (ev) {
			$(this.obj).down('div[data-nodeid=0] > a').hide();

			$('treeSearchInput').show().focus();

			ev.findElement('img').hide();
		}.bind(this));

		$search_field.on('blur', this.hideSearchBox.bindAsEventListener(this));
		$search_field.on('keyup', this.keyInput.bindAsEventListener(this));
		$search_field.on('click', this.keyInput.bindAsEventListener(this));
		$search_field.on('keypress', function (e) {
			if (e.keyCode == Event.KEY_RETURN) Event.stop(e);
		});
	}
};

dTree.prototype.hideSearchBox = function () {
	$('treeSearchIcon').show();
	$(this.obj).down('div[data-nodeid=0] > a').show();
	$('treeSearchInput').hide();

	$(this.obj).select('div.highlightSearch').each(function ($el) {
		$el.removeClassName('highlightSearch');
	});
};

// Toggle Open or close
dTree.prototype.o = function (id) {
	var cn = this.aNodes[id];

	if (cn) {
		this.nodeStatus(!cn._io, id, cn._ls);
		cn._io = !cn._io;
		if (this.config.closeSameLevel) {
			this.closeLevel(cn);
		}
		if (this.config.useCookies) {
			this.updateCookie();
		}

		$$('#dmenu_tree' + id + ' > div.node').each(function (p_element) {
			p_element.writeAttribute("style", null);
		});
	}
};

dTree.prototype.keyInput = function (ev) {
	var $tree = $('dmenu_tree0'),
		$filter = ev.findElement('input'),
		value = $filter.getValue().toLowerCase(),
		controlKeys = [Event.KEY_RETURN, Event.KEY_DOWN, Event.KEY_UP, Event.KEY_ESC],
		unwantedKeys = [Event.KEY_LEFT, Event.KEY_RIGHT],
		hide = ($('nodeVisibilityIcon').readAttribute('data-hide') == 1),
		highlight = $tree.select('div.highlightSearch');

	if (unwantedKeys.indexOf(ev.keyCode) !== -1)
	{
		return false;
	}

	// Control-key pressed.
	if (controlKeys.indexOf(ev.keyCode) !== -1)
	{
		// RETURN: open node
		if (ev.keyCode == Event.KEY_RETURN)
		{
			if (highlight.length > 0)
			{
				$tree.down('div.highlightSearch > a').simulate('click');
			}
		}

		// ESCAPE: exit the filter-mode.
		if (ev.keyCode == Event.KEY_ESC)
		{
			this.hideSearchBox();

			$filter.setValue('');

			$tree.select('div.node:not(.hide)').each(function ($node) {
				$node.removeClassName('treeSearchResult');

				if (!$node.down('span')) {
					$node.show();
				}
			});
			return;
		}
		else
		{
			// Get visible nodes.
			var $visible_elements = $tree.select('div.node:not(.hide)').findAll(function (el) {
				return el.up().visible() && el.visible();
			});

			// Is there a highlighted node.
			if (highlight.length > 0)
			{
				// Variables.
				var l_highlightedElement = highlight[0],
					l_highlightedElementIndex = $visible_elements.indexOf(l_highlightedElement),
					l_indexOfNext = 0;

				// Remove .highlightSearch from current element.
				l_highlightedElement.removeClassName('highlightSearch');

				// Set next elements INDEX.
				if (ev.keyCode == Event.KEY_DOWN) {
					l_indexOfNext = l_highlightedElementIndex + 1;
				} else if (ev.keyCode == Event.KEY_UP) {
					l_indexOfNext = l_highlightedElementIndex - 1;
				}

				// Reset INDEX if not exists.
				if (! $visible_elements[l_indexOfNext]) l_indexOfNext = 0;

				// Highlight the Element.
				$visible_elements[l_indexOfNext].addClassName('highlightSearch');

				ev.stop();
			}
			else
			{
				// Highlight the first Element
				$tree.down('div.node:not(.hide):visible').addClassName('highlightSearch');
			}
		}

		return false;
	}

	if (value.length >= 2) {
		this.oAll();

		// Hide all nodes.
		$tree.select('div.node:not(.hide) > a').each(function ($link) {
			var i = 0;

			if ($link.innerHTML.toLowerCase().indexOf(value) !== -1) {
				$link.up().addClassName('treeSearchResult').show();

				while ($link.up('.clip', i)) {
					$link.up('.clip', i)
						.writeAttribute('style', 'display: block')
						.previous().writeAttribute('style', 'display: block');

					if ($link.up('.clip', i).previous().down('a > img[src*="plus.gif"]')) {
						$link.up('.clip', i).previous().down('a').simulate('click');
					}

					i ++;
				}
			} else {
				$link.up().removeClassName('treeSearchResult').hide();
			}
		});
	} else {
		// First we display all nodes
		$tree.select('div.node').invoke('show');

		// Then, we process the visibility.
		this.processVisibility();
	}
};

// Hide or Show empty menu items.
dTree.prototype.addNodesVisibility = function (hide) {
	var $root_node_container = $(this.obj).down('div[data-nodeid="0"]'),
		$visibility_icon = new Element('img', {src: this.icon.eye[hide], id: 'nodeVisibilityIcon', className: 'greyscale', 'data-hide': hide});

	if ($root_node_container) {
		$root_node_container.insert($visibility_icon);

		$visibility_icon.on("click", function () {
			this.toggleVisibility();
		}.bind(this));

		this.processVisibility();
	}
};

dTree.prototype.toggleVisibility = function () {
	var $node_container = $('dmenu_tree0'),
		$toggler = $('nodeVisibilityIcon'),
		params = {},
		hide = ($toggler.readAttribute('data-hide') == 1);

	$toggler.writeAttribute('data-hide', (hide ? 0 : 1)).writeAttribute('src', this.icon.eye[$toggler.readAttribute('data-hide')]);

	if ($node_container) {
		$node_container.select('span.noentries,span.obj_noentries').invoke('up', 'div').invoke((hide ? 'addClassName' : 'removeClassName'), 'hide');
	}

	if ($node_container.down('.noentries')) {
		params.categories = hide ? 0 : 1;
	} else {
		params.objtype = hide ? 0 : 1;
	}

	// Ajax Request to save in user settings.
	new Ajax.Request('?call=menu&ajax=1&func=save_tree_visibility', {
		parameters: params
	});

	this.processVisibility();
};

dTree.prototype.processVisibility = function () {
	var $node_container = $('dmenu_tree0'),
		$toggler = $('nodeVisibilityIcon'),
		hide = ($toggler.readAttribute('data-hide') == 1);

	if ($node_container) {
		$node_container.select('span.noentries,span.obj_noentries').invoke('up', 'div').invoke((hide ? 'addClassName' : 'removeClassName'), 'hide');

		if (! hide) {
			// This may happen with parent/child-categories.
			$node_container.select('div.node.hide').invoke('removeClassName', 'hide');
		}
	}
};