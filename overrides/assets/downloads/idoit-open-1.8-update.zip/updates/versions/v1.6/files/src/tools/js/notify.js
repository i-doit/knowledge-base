document.observe('dom:loaded', function() {
	"use strict";

	idoit.Notify = Class.create({
		initialize: function (options) {
			var opt = Object.extend({
					location:'br'
				}, options || {});

			this.notification_options = {
				header: '',
				speedin: 0.3,
				speedout: 0.5,
				life: 2,
				sticky: false,
				className: '',
                width: '250px',
				created: Prototype.emptyFunction,
				destroyed: Prototype.emptyFunction
			};

			this.locations = {
				tr: {top:0, right:0},
				br: {bottom:'5px', right:'9px'},
				tl: {top:0, left:0},
				bl: {bottom:0, left:0},
				tc: {top:0, left:'25%', width:'50%'},
				bc: {bottom:0, left:'25%', width:'50%'}
			};

			this.element = new Element("div", {className:"Notify", id:"Notify"})
				.setStyle({position: "fixed", padding: "10px", zIndex: "50000"});

			if (opt.hasOwnProperty('location') && this.locations.hasOwnProperty(opt.location)) {
				this.element.setStyle(this.locations[opt.location]);
			}

			this.element.wrap(document.body);
		},

		/**
		 * Function for creating a Notify-message.
		 *
		 * @param  msg      The message.
		 * @param  options  The (optional) options object (associative "array").
		 * @retun  Element
		 */
		render: function (msg, options) {
			var opt = Object.extend(Object.clone(this.notification_options), options || {}),
			notice, notify = this.element;

			opt.className = (opt.hasOwnProperty('className') ? 'item ' + opt.className : 'item');

			notice = new Element("div", {"class": opt.className})
				.setStyle({display: "block", opacity: 0})
				.observe("notify:created", opt.created)
				.observe("notify:destroyed", opt.destroyed);

			if (opt.sticky) {
				notice.insert(new Element("div", {"class": "exit"}).update("&times;"));
			}

            if (opt.width) {
                notice.style.width = opt.width;
            }

			notice.insert(new Element("div", {"class": "head"}).update(opt.header))
				.insert(new Element("div", {"class": "body"}).update(msg))
				.on('click', function () {
					this.remove(notice, opt);
				}.bind(this));

			notify.insert(notice);

			var opacity = new Effect.Opacity(notice, { to: 0.85, duration: opt.speedin });

			if (!opt.sticky) {
				this.remove.delay(opt.life, notice, opt);
			}

			notice.fire("notify:created");

			return notice;
		},

		/**
		 * Function for removing the given notice and firing the "destroyed" callback.
		 *
		 * @param  notice   The "Notice" element.
		 * @param  options  The (optional) options object (associative "array").
		 */
		remove: function (notice, options) {
			var opt = Object.extend(
				Object.clone(this.notification_options), options || {}
			);

			var morph = new Effect.Morph(notice, {
				duration: opt.speedout,
				style: 'margin-bottom:' + (notice.getHeight() * -1) + 'px; opacity:0;',
				afterFinish: function () {
					try {
						notice.fire("notify:destroyed");
						notice.stopObserving().remove();
					} catch (e) {}
				}
			});
		},

		message: function (message, options) {
			options = Object.extend({
				header: idoit.Translate.get('LC__NOTIFY__MESSAGE')
			}, options || {});

            options.className = (options.hasOwnProperty('className') ? options.className + ' box-grey' : 'box-grey');

			this.render(message, options);
		},

		success: function (message, options) {
			options = Object.extend({
				header: idoit.Translate.get('LC__NOTIFY__SUCCESS')
			}, options || {});

			options.className = (options.hasOwnProperty('className') ? options.className + ' box-green' : 'box-green');

			this.render(message, options);
		},

		error: function (message, options) {
			options = Object.extend({
                life: 10,
				header: idoit.Translate.get('LC__NOTIFY__ERROR')
			}, options || {});

			options.className = (options.hasOwnProperty('className') ? options.className + ' box-red' : 'box-red');

			this.render(message, options);
		},

		info: function (message, options) {
			options = Object.extend({
				header: idoit.Translate.get('LC__NOTIFY__INFO')
			}, options || {});

			options.className = (options.hasOwnProperty('className') ? options.className + ' box-blue' : 'box-blue');

			this.render(message, options);
		},

		warning: function (message, options) {
			options = Object.extend({
				header: idoit.Translate.get('LC__NOTIFY__WARNING')
			}, options || {});

			options.className = (options.hasOwnProperty('className') ? options.className + ' box-yellow' : 'box-yellow');

			this.render(message, options);
		},

		renderNotification: function(notification) {
			switch (notification.type) {
				default:
				case 0:
					idoit.Notify.message(notification.message, notification.options);
					break;

				case 1:
					idoit.Notify.success(notification.message, notification.options);
					break;

				case 2:
					idoit.Notify.error(notification.message, notification.options);
					break;

				case 3:
					idoit.Notify.info(notification.message, notification.options);
					break;

				case 4:
					idoit.Notify.warning(notification.message, notification.options);
					break;
			}
		},

        test: function () {
            this.error('error', {sticky:true});
            this.success('success', {sticky:true});
            this.info('info', {sticky:true});
            this.warning('warning', {sticky:true});
            this.message('message', {sticky:true});
        }
	});

	// Create the global instance.
	idoit.Notify = new idoit.Notify();

	// And now we observe all ajax requests.
	Ajax.Responders.register({
		onComplete: function(ev) {
			var notification,
				cnt = 0;

			while (notification = ev.getHeader('X-Idoit-Notification-' + cnt)) {
				cnt ++;
				idoit.Notify.renderNotification(notification.evalJSON());
			}
		}
	});
});