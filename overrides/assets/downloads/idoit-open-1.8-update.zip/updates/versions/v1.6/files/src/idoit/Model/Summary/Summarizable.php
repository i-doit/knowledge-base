<?php
namespace idoit\Model\Summary;

/**
 * i-doit Summaries
 *
 * @package     i-doit
 * @subpackage  Core
 * @author      Dennis Stücken <dstuecken@synetics.de>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
interface Summarizable
{
    /**
     * Get summary
     *
     * @return int
     */
    public function get($key);

    /**
     * Set summary
     *
     * @return Summarizable
     */
    public function set($key, $count = 0);

    /**
     * @param $key
     *
     * @return Summarizable
     */
    public function remove($key);

    /**
     * @param $key
     *
     * @return Summarizable
     */
    public function increment($key);

    /**
     * @param $key
     *
     * @return Summarizable
     */
    public function decrement($key);
} // class