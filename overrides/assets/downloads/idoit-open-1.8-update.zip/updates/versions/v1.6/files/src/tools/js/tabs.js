/**
 * i-doit tab implementation
 *
 * @author  Dennis Stücken <dstuecken@i-doit.de>
 */
var Tabs = Class.create({
	current_body: '',
	options: {},
	initTab: '',
	close: '_close',

	initialize: function (element, options) {
		if ($(element)) {
			this.options = {
				wrapperClass: 'tabs',
				contentClass: 'tab-content',
				activeBodyClass: 'active-body',
				activeClass: 'active',
				tabClass: 'gradient text-shadow',
				onTabSelect: Prototype.emptyFunction
			};

			this.options = Object.extend(this.options, options || {});
			this.element = $(element).addClassName(this.options.wrapperClass);

			this.menu = $(element).select('li a');

			var preselection = document.location.href.match(/#(\w.+)/);

			if (preselection)
				this.initTab = this.menu.find(function (value) {
					return value.href.match(/#(\w.+)/)[1] == preselection[1];
				}) || this.menu.first();
			else this.initTab = this.menu.first();

			this.menu.each(this.tab_initialize.bind(this));
			this.show(this.initTab);
		} else {
			throw new Error('Element ' + element + ' does not exist.');
		}
	},
	show: function (el) {
		this.current_body = $(this.get(el));

		$(el).addClassName(this.options.activeClass).blur();

		this.current_body.addClassName(this.options.contentClass).show();
        this.options.onTabSelect(el);
	},
	hide: function (el) {
		this.current_body = $(this.get(el));

		$(el).removeClassName(this.options.activeClass);
		this.current_body.removeClassName(this.options.activeBodyClass).hide();
	},
	close: function (el) {

	},
	tab_initialize: function (el) {
		el.addClassName(this.options.tabClass);
		if ($(this.get(el))) $(this.get(el)).hide();

		if (!el.up().hasClassName('disabled')) {
			Event.observe(el, 'click', this.prepare.bindAsEventListener(this));
		}
	},
	activate: function (tabNumber) {
		if (this.menu[tabNumber]) {
			this.show(this.menu[tabNumber]);
			this.menu.without(this.menu[tabNumber]).each(this.hide.bind(this));
		}
	},
	prepare: function (ev) {
		var el = Event.findElement(ev, "a");
		Event.stop(ev);
		this.show(el);
		this.menu.without(el).each(this.hide.bind(this));
	},
	get: function (el) {
		var regex = el.href.match(/#([\S]+)/);
		if (regex) return regex[1];
		else return '';
	}
});