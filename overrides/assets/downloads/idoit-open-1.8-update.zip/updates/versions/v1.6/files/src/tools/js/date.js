/**
 * Extending the Date class with methods for calculating Dates, finding a leap year etc.
 *
 * @author  Leonard Fischer <lfischer@i-doit.com>
 * @author  Van Quyen Hoang <qhoang@i-doit.com>
 */

if (!Date.hasOwnProperty('is_leap_year')) {
	/**
	 * Returns true or false wether the year is a leap year.
	 *
	 * @returns  boolean
	 * @author   Leonard Fischer <lfischer@i-doit.com>
	 */
	Date.prototype.is_leap_year = function () {
		var year = this.getFullYear();

		return ((year % 4 === 0 && year % 100 !== 0) || year % 400 === 0);
	};
}

if (!Date.hasOwnProperty('get_days_in_month')) {
	/**
	 * Returns the number of days of the current month (and year).
	 *
	 * @returns  Number
	 * @author   Leonard Fischer <lfischer@i-doit.com>
	 */
	Date.prototype.get_days_in_month = function () {
		return [31, (this.is_leap_year() ? 29 : 28), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][this.getMonth()];
	};
}