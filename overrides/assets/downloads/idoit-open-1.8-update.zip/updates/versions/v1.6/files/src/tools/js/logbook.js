function popup_open(element, width, height) {
	var open_popups = $$('.popup').filter(function ($el) {
		return $el.visible();
	});

	// We use a default popup element, when no certain element is given.
	if (!element) {
		element = $('popup');
	} else {
		element = $(element);
	}

	Position.includeScrollOffsets = true;

	if (! width) {
		width = element.getWidth();
	}

	if (! height) {
		height = element.getHeight();
	}

	show_overlay();

	// We set the styles for our popup element (center it, position fixed and z-index above the transparent-layer).
	element.setStyle({
		position: "fixed",
		width: width + 'px',
		height: height + 'px',
		top: "50%",
		left: "50%",
		marginLeft: - parseInt(width/2) + 'px',
		marginTop: - parseInt(height/2) + 'px',
		zIndex: (1100 + open_popups.length)
	});

	new Effect.toggle(element, 'appear', { duration: 0.3 });
}

function popup_close(element) {
	if (!element) {
		element = $('popup');
	} else {
		element = $(element);
	}

	new Effect.Fade(element, {
		duration: 0.3,
		afterFinish: function () {
			// After popup is closed we have to check for other visible popup windows and hide the overlay when all popups are hidden.
			var open_popups = $$('.popup:not(.custom-popup)').filter(function ($el) {
				// We use the "custom-popup" class for smaller popups, which do not use the overlay - so we can ignore these when hiding the overlay.
				return $el.visible();
			});

			if (open_popups.length === 0) {
				hide_overlay();

                element.removeClassName('loaded');
			}
		}
	});

	new Effect.Move(element, {
		x: '50%',
		y: -500,
		mode: 'absolute',
		duration: 0.3
	});
}

function get_popup(p_popupname, p_urlparams, p_width, p_height, p_parameters, p_destination_popup) {
    var l_destination_popup = p_destination_popup || 'popup',
        l_url = window.www_dir + '?mod=cmdb&popup='+p_popupname;

	if (p_urlparams) {
		l_url += '&' + p_urlparams;
	}

	// We update the popup window with an empty string, so that we won't see some funny stuff.
	$(l_destination_popup).update('');

	popup_open($(l_destination_popup), p_width, p_height);

	/**
	 * Close popup with escape
	 */
	document.on('keydown', function(ev) {
		ev = ev || window.event;
	    if (ev.keyCode == Event.KEY_ESC) {
		    document.stopObserving('keydown');
	        popup_close();
	    }
	});

	new Ajax.Submit(l_url, l_destination_popup, false, {
        history:false,
        onSuccess: function() {
            document.stopObserving('keydown');
        },
        onComplete: function() {
            $(l_destination_popup).addClassName('loaded');
        },
        parameters: p_parameters
    });
}

function get_commentary() {
	get_popup('commentary', 'editMode=1', 490, 260, null, 'popup_commentary');
}

function expandEntry (id, p_archive, p_logbookid) {
	if ($('logb' + id).innerHTML == "") {
		var l_url = '?moduleID=' + p_logbookid + '&request=expandLogbookEntry&log_id=' + id;

		if (p_archive) {
			l_url = l_url + '&inArchive=1';
		}

		aj_submit(l_url, 'get', 'logb' + id, null, null, null, null,
			function () {
				if (!$('tr' + id).visible()) {
					new Effect.Appear('tr' + id, {duration: 0.15});
					swapExpandCollapse(id);
				}
			}
		);
	}
	else {
		if (!$('tr' + id).visible()) {
			new Effect.Appear('tr' + id, {duration: 0.15});
			swapExpandCollapse(id);
		}
	}
}

function collapseEntry(id) {
	if ($('tr'+id).visible()) {
		new Effect.Fade('tr'+id, {duration:0.15});
		swapExpandCollapse(id);
	}
}

function swapExpandCollapse(id) {
    var $td = $('ec' + id);

    if ($td.down('img').readAttribute('src').indexOf('bullet_toggle_minus') === -1)
    {
        $td.update(new Element('img', {src: window.dir_images + 'icons/silk/bullet_toggle_minus.png'})).onclick = function () {
            collapseEntry(id);
        };
    }
    else
    {
        $td.update(new Element('img', {src: window.dir_images + 'icons/silk/bullet_toggle_plus.png'})).onclick = function () {
            expandEntry(id);
        };
    }
}