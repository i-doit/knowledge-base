/**
 * i-doit javascript dragbar component
 * @author Van Quyen Hoang <qhoang@i-doit.org>
 */
var dragBar = Class.create({
    options:    {},
    initialize: function (options) {
        this.options = Object.extend({
            dragContainer:  '',
            leftContainer:  '',
            rightContainer: '',
            moveInfoBox:    false,
            dragType:       'col-resize',
            dragActive:     0,
            defaultTop:     '',
            defaultWidth:   '',
            minWidth:       10
        }, options || {});

        $(this.options.dragContainer).className = 'draggableBar';
        $(this.options.dragContainer).setStyle({'height': $(this.options.leftContainer).getHeight() + 'px'});
        $(this.options.dragContainer).setStyle({
            'top': ((this.options.defaultTop != '') ? this.options.defaultTop +
                                                      'px' : $(this.options.leftContainer).getStyle('top'))
        });

        if (this.options.defaultWidth != '') {
            $(this.options.leftContainer).setStyle({'width': this.options.defaultWidth + 'px'});
            if (this.options.rightContainer != '') {
                $(this.options.rightContainer).setStyle({'left': (parseInt(this.options.defaultWidth)) + 'px'})
            }

            $(this.options.dragContainer).setStyle({'left': (this.options.defaultWidth - 1) + 'px'});
            if (this.options.moveInfoBox && $('infoBox')) {
                $('infoBox').setStyle({'left': (parseInt(this.options.defaultWidth) + 1) + 'px'});
            }
        }

        var shadow_bar_ident = 'shadowBar_' + Math.floor((Math.random() * 100) + 1);

        while ($(shadow_bar_ident)) {
            shadow_bar_ident = 'shadowBar_' + Math.floor((Math.random() * 100) + 1);
        }

        var shadow_bar = new Element('div',
            {
                'id': shadow_bar_ident,
                'style': 'z-index:1000;display:none;background:#324;position:absolute;top:' +
                         $(this.options.dragContainer).getStyle('top') +
                         ';left:' +
                         $(this.options.dragContainer).getStyle('left') +
                         ';width:' +
                         $(this.options.dragContainer).getStyle('width') +
                         ';height:' +
                         $(this.options.dragContainer).getStyle('height')
            });

        $('content').insert(shadow_bar);

        $(this.options.dragContainer).on('mouseover', function () {
            if (shadow_bar.getHeight() != $(this.options.leftContainer).getHeight()) {
                shadow_bar.setStyle({'height': $(this.options.leftContainer).getHeight() + 'px'});
            }
            $(this.options.dragContainer).setStyle({height: (document.viewport.getHeight() - 32) + 'px'});
            $('content').style.cursor = this.options.dragType;
        }.bind(this));

        $(this.options.dragContainer).on('mouseout', function () {
            $('content').style.cursor = '';
        });

        $(this.options.dragContainer).on('mousedown', function (e) {
            this.options.dragActive = 1;
            if (e.preventDefault) {
                e.preventDefault();
            }
            else {
                e.returnValue = false;
            }
            shadow_bar.show();
        }.bind(this));

        $('content').on('mouseup', function (e) {
            if (this.options.dragActive == 1) {
                //var left_width = $(this.options.leftContainer).getWidth();
                var left_position = (e.pageX > this.options.minWidth) ?
                    (((document.body.offsetWidth - (this.options.minWidth * 2)) > e.pageX) ?
                        e.pageX : document.body.offsetWidth - (this.options.minWidth * 2)) :
                    this.options.minWidth;
                var new_left_width = left_position;

                if (this.options.rightContainer != '') {
                    $(this.options.rightContainer).setStyle({'left': left_position + 'px'});
                }

                $(this.options.dragContainer).setStyle({'left': (left_position - 1) + 'px'});
                $(this.options.leftContainer).setStyle({'width': new_left_width + 'px'});
                if (this.options.moveInfoBox && $('infoBox')) {
                    $('infoBox').setStyle({'left': (new_left_width + 1) + 'px'});
                }

                shadow_bar.hide();
                this.callback_save();
	            idoit.callbackManager.triggerCallback('idoit-dragbar-update');
            }
            this.options.dragActive = 0;
            $('content').style.cursor = '';
        }.bind(this));

        $('content').on('mousemove', function (e) {
            if (this.options.dragActive == 1) {
                $('content').style.cursor = this.options.dragType;
                shadow_bar.setStyle(
                    {
                        'left': ((e.pageX > this.options.minWidth) ? (((document.body.offsetWidth -
                                                                        (this.options.minWidth * 2)) > e.pageX) ?
                            e.pageX : document.body.offsetWidth - (this.options.minWidth * 2)) :
                            this.options.minWidth) + 'px'
                    }
                );
            }
        }.bind(this));
    },

    callback_save: function () {
        /* do nothing */
    }
});