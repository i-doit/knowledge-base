/**
 * i-doit CMDB Explorer javascript base class.
 *
 * @author  Leonard Fischer <lfischer@i-doit.com>
 */
window.CMDB_Explorer = Class.create({
    vis:          null,
    svg:          null,
    layout:       null,
    zoom_ev:      null,
    options:      {},
    profile:      {},
    $tooltip_div: null,

    set_name: function (name) {
        this.options.name = name;

        return this;
    },

    get_name: function () {
        return this.options.name;
    },

    get_option: function (option) {
        return this.options[option];
    },

    set_option: function (option, value) {
        this.options[option] = value;

        return this;
    },

    get_svg: function () {
        return this.svg
    },

    set_svg: function (svg) {
        this.svg = svg;

        return this;
    },

    initialize: function ($el, data, options, profile, object_types) {
        this.$element = $el;
        this.data = data || [];
        this.options = {
            name:            '',                      // This name will be used as ID on the SVG element.
            zoom:            true,                    // Shall the canvas be zoomable?
            min_zoom_level:  0.25,                    // Defines the minimal zoom level.
            max_zoom_level:  8,                       // Defines the maximal zoom level.
            node_width:      50,                      // Is used to position the nodes (horizontally) next to each other.
            node_height:     10,                      // Is used to position the nodes (vertically) next to each other.
            node_row_height: 20,                      // Is used to position the node rows.
            mouseover:       Prototype.emptyFunction, // MouseOver event for any nodes.
            mouseout:        Prototype.emptyFunction, // MouseOut event for any nodes.
            click:           Prototype.emptyFunction, // Click event for any nodes.
            dblclick:        Prototype.emptyFunction, // DoubleClick event for any nodes.
            width:           null,                    // This can be used to change the viewpoints width. The SVG element will always remain 100%x100%.
            height:          null,                    // This can be used to change the viewpoints height. The SVG element will always remain 100%x100%.
            append_styles:   this.append_styles,      // This callback can be used to implement some own stylings via the <def> element.
            tooltips:        false                    // Enable this option to display tooltips (for "micro" or "net" profile).
        };

        this.profile = profile || {};
        this.object_types = object_types || {};

        // Setting the default width and height.
        this.options.width = $el.getWidth();
        this.options.height = $el.getHeight();

        idoit.callbackManager.registerCallback('visualization-zoom', this.zoom, this);

        Object.extend(this.options, options || {});

        this.flash_node();
    },

    flash_node: function () {
        setTimeout(function () {
            if (this.vis)
            {
                this.vis.selectAll('.flash')
                    .select('rect')
                    .transition()
                    .style({
                        stroke:           this.profile['highlight-color'],
                        'stroke-width':   '7px',
                        'stroke-opacity': 1
                    })
                    .transition()
                    .delay(500)
                    .style({
                        stroke:           null,
                        'stroke-width':   null,
                        'stroke-opacity': null
                    })
            }

            this.flash_node();
        }.bind(this), 1000);
    },

    append_styles: function () {
        var defs = this.svg.select('defs');
        if (defs.node() === null)
        {
            defs = this.svg.append('defs');

            defs.append('style').attr('type', 'text/css').text(
                "text { \
                    font-size:11px; \
                    font-family: \"Helvetica Neue\", \"Lucida Grande\", \"Tahoma\", Arial; \
                } \
                .link { \
                    fill: none; \
                    stroke: #aaa; \
                    stroke-linejoin: round; \
                    stroke-width: 1px; \
                }\
                .arrow {\
                    fill: #aaa;\
                }\
                .link.highlight {\
                    stroke-width: 3px;\
                }\
                .node {\
                    cursor: pointer;\
                }\
                .node:hover rect:first-child {\
                    stroke-width: 3px;\
                }\
                .node rect:first-child {\
                    fill: transparent;\
                    stroke: #000;\
                    stroke-opacity: 0.5;\
                }\
                .node.active rect:first-child {\
                    stroke-width: 4px;\
                    stroke-opacity: 1;\
                }\
                .node.highlight rect:first-child,\
                .node rect.root-object {\
                    stroke-width: 4px;\
                    stroke-opacity: 1;\
                }\
                .transparent {\
                    fill-opacity: 0.2;\
                    stroke-opacity: 0.2;\
                }"
            );

            // This section adds in the arrows.
            defs
                .append("svg:marker")
                .attr("id", 'end')
                .attr("viewBox", "0 -5 10 10")
                .attr("refX", 17)
                .attr("refY", 0)
                .attr("markerWidth", 18)
                .attr("markerHeight", 7)
                .attr("orient", "auto")
                .append("svg:path")
                .attr("d", "M0,-5L10,0L0,5")
                .attr("class", "arrow");

            defs
                .append("svg:marker")
                .attr("id", 'end-highlight')
                .attr("viewBox", "0 -5 10 10")
                .attr("refX", 13)
                .attr("refY", 0)
                .attr("markerWidth", 18)
                .attr("markerHeight", 3)
                .attr("orient", "auto")
                .append("svg:path")
                .attr("d", "M0,-5L10,0L0,5")
                .attr("class", "arrow-highlight")
                .style('stroke-width', '2px')
                .style('fill', this.profile['highlight-color']);
        }
    },

    process: Prototype.emptyFunction,

    render_nodes: function (nodes) {
        var i,
            explorer     = this,
            profile      = this.profile,
            object_types = this.object_types,
            profile_rows = Object.keys(profile.rows).length,
            fillcolor, fontcolor, text, text_margin, row,
            pos_y        = (profile_rows * this.options.node_row_height) * -0.5;

        nodes
            .attr('data-relation-obj-id', function (d) { return d.data.relation_obj_id; })
            .attr('data-obj-type-id', function (d) { return d.data.obj_type_id; })
            .attr('data-object-id', function (d) { return d.data.obj_id })
            .attr('data-id', function (d) { return d.id });

        if (profile.mikro)
        {
            nodes.append('circle')
                 .attr('r', '5px')
                 .attr('style', function (d) {
                     return 'fill:' + d.data.obj_type_color + '; stroke:#eee; stroke-width:1px;';
                 });

            nodes.append('text')
                 .attr('x', 13)
                 .attr('y', 4)
                 .text(function (d) {
                     return d.data.obj_type_title + ': ' + d.data.obj_title;
                 });
        }
        else
        {
            nodes.append('rect')
                 .attr('x', -(profile.width / 2))
                 .attr('y', pos_y)
                 .attr('width', profile.width)
                 .attr('height', (profile_rows * this.options.node_row_height))
                 .attr('class', function (d) {
                     return (d.data['root-object']) ? 'root-object' : null;
                 })
                 .attr('style', function (d) {
                     var style = '';

                     if (d.data['root-object'])
                     {
                         style += 'stroke:' + profile['highlight-color'] + ';';
                     }

                     if (d.data.doubling)
                     {
                         style += 'stroke-dasharray:7,2; stroke-width:3px;';
                     }

                     return style;
                 });

            for (i in profile.rows)
            {
                if (profile.rows.hasOwnProperty(i))
                {
                    row = profile.rows[i];

                    fillcolor = row.fillcolor || '';
                    fontcolor = row.fontcolor || '#000000';
                    text = null;
                    text_margin = 0;

                    if (!(Object.isString(fillcolor) && fillcolor.substr(0, 1) == '#'))
                    {
                        fillcolor = function (d) {
                            return object_types[d.data.obj_type_id].color;
                        };
                    }

                    nodes.append('rect')
                         .style('fill', fillcolor)
                         .attr('x', -(profile.width / 2))
                         .attr('y', pos_y)
                         .attr('width', profile.width)
                         .attr('height', this.options.node_row_height);

                    if (row.option == 'obj-type-title-icon')
                    {
                        nodes.append('image')
                             .attr('xlink:href', function (d) {
                                 return object_types[d.data.obj_type_id].icon
                             })
                             .attr('x', -((profile.width / 2) - 3))
                             .attr('y', (pos_y + 2))
                             .attr('width', 16)
                             .attr('height', 16);

                        text = nodes.append('text')
                                    .text(function (d) {
                                        return explorer.text_format.call(this, d.content[row.option], (profile.width - 30));
                                    });

                        if (row['font-align-right'])
                        {
                            text_margin = 5;
                        }
                        else
                        {
                            text.attr('x', -((profile.width / 2) - 22));
                        }
                    }
                    else if (row.option == 'obj-title-type-title-icon-cmdb-status')
                    {
                        nodes.append('image')
                             .attr('xlink:href', function (d) {
                                 return object_types[d.data.obj_type_id].icon
                             })
                             .attr('x', -((profile.width / 2) - 3))
                             .attr('y', (pos_y + 2))
                             .attr('width', 16)
                             .attr('height', 16);

                        nodes.append('rect')
                             .style('fill', function (d) {
                                 return d.content[row.option]['cmdb-color'];
                             })
                             .style('stroke', '#000000')
                             .style('stroke-width', 0.5)
                             .attr('rx', 3)
                             .attr('ry', 3)
                             .attr('x', ((profile.width / 2) - 13))
                             .attr('y', (pos_y + 4))
                             .attr('width', 10)
                             .attr('height', 12);

                        text = nodes.append('text')
                                    .text(function (d) {
                                        return explorer.text_format.call(this, d.content[row.option]['obj-type-title'] + ': ' + d.content[row.option]['obj-title'], (profile.width - 40));
                                    });

                        if (row['font-align-right'])
                        {
                            text_margin = 15;
                        }
                        else
                        {
                            text.attr('x', -((profile.width / 2) - 22));
                        }
                    }
                    else if (row.option == 'obj-title-cmdb-status')
                    {
                        nodes.append('rect')
                             .style('fill', function (d) {
                                 return d.content[row.option]['cmdb-color'];
                             })
                             .style('stroke', '#000000')
                             .style('stroke-width', 0.5)
                             .attr('rx', 3)
                             .attr('ry', 3)
                             .attr('x', ((profile.width / 2) - 13))
                             .attr('y', (pos_y + 4))
                             .attr('width', 10)
                             .attr('height', 12);

                        text = nodes.append('text')
                                    .text(function (d) {
                                        return explorer.text_format.call(this, d.content[row.option]['obj-title'], (profile.width - 40));
                                    });

                        if (row['font-align-middle'])
                        {
                            text_margin = 10;
                        }
                        else if (row['font-align-right'])
                        {
                            text_margin = 15;
                        }
                        else
                        {
                            text.attr('x', -((profile.width / 2) - 5));
                        }
                    }
                    else if (row.option == 'cmdb-status')
                    {
                        nodes.append('rect')
                             .style('fill', function (d) {
                                 return d.content[row.option].color;
                             })
                             .style('stroke', '#000000')
                             .style('stroke-width', 0.5)
                             .attr('rx', 3)
                             .attr('ry', 3)
                             .attr('x', -((profile.width / 2) - 3))
                             .attr('y', (pos_y + 4))
                             .attr('width', 10)
                             .attr('height', 12);

                        text = nodes.append('text')
                                    .text(function (d) {
                                        return explorer.text_format.call(this, d.content[row.option].title, (profile.width - 20));
                                    });

                        if (row['font-align-right'])
                        {
                            text_margin = 5;
                        }
                        else
                        {
                            text.attr('x', -((profile.width / 2) - 16));
                        }
                    }
                    else
                    {
                        text = nodes.append('text')
                                    .attr('x', -((profile.width / 2) - 5))
                                    .text(function (d) {
                                        return explorer.text_format.call(this, d.content[row.option], (profile.width - 15));
                                    });
                    }

                    if (text !== null)
                    {
                        text.attr('y', (pos_y + 4 + (this.options.node_row_height / 2))).style('fill', fontcolor);

                        if (row['font-align-middle'])
                        {
                            text.attr('x', -text_margin).style('text-anchor', 'middle');
                        }

                        if (row['font-align-right'])
                        {
                            text
                                .attr('x', function (d) {
                                    return ((profile.width / 2) - (this.getComputedTextLength() + text_margin));
                                })
                                .style('text-anchor', 'right');
                        }

                        if (row['font-bold'])
                        {
                            text.style('font-weight', 'bold');
                        }

                        if (row['font-italic'])
                        {
                            text.style('font-style', 'italic');
                        }

                        if (row['font-underline'])
                        {
                            text.style('text-decoration', 'underline');
                        }
                    }

                    pos_y += this.options.node_row_height;
                }
            }
        }
    },

    stop: function () {
        this.layout.stop();
    },

    zooming: function () {
        this.hide_tooltip();

        // Somethines "this.vis" is not yet set...
        var g     = this.vis || d3.select('#' + this.options.name + '_g'),
            scale = (this.options.zoom ? d3.event.scale : 1);

        g.attr('transform', 'translate(' + d3.event.translate + ') scale(' + scale + ')');
    },

    zoom: function (factor) {
        var current_scale     = this.zoom_ev.scale(),
            current_translate = this.zoom_ev.translate(),
            new_scale,
            new_translate     = [];

        this.hide_tooltip();

        switch (factor)
        {
            case '=':
                if (this.instance == 'CMDB_Explorer_Graph')
                {
                    new_translate = [
                        0,
                        0
                    ];
                }
                else
                {
                    new_translate = [
                        (this.options.width / 2),
                        (this.options.height / 2)
                    ];
                }

                this.zoom_ev
                    .scale(1)
                    .translate(new_translate)
                    .event(this.svg);
                return;

            case '+':
                new_scale = current_scale + 0.5;

                new_translate[0] = current_translate[0] + ((current_translate[0] - (this.options.width / 4)) * (current_scale * 0.125));
                new_translate[1] = current_translate[1] + ((current_translate[1] - (this.options.height / 4)) * (current_scale * 0.125));
                break;

            case '-':
                new_scale = current_scale - 0.5;

                new_translate[0] = current_translate[0] - ((current_translate[0] - (this.options.width / 4)) * (current_scale * 0.125));
                new_translate[1] = current_translate[1] - ((current_translate[1] - (this.options.height / 4)) * (current_scale * 0.125));
                break;
        }

        if (new_scale < this.options.min_zoom_level)
        {
            new_scale = this.options.min_zoom_level;
        }

        if (new_scale > this.options.max_zoom_level)
        {
            new_scale = this.options.max_zoom_level;
        }

        this.zoom_ev
            .scale(new_scale)
            .translate(new_translate)
            .event(this.svg);
    },

    text_format: function (text, width) {
        var result = text;

        if (width <= 0)
        {
            return '';
        }

        d3.select(this).text(result);

        while (this.getComputedTextLength() > width)
        {
            result = result.substr(0, (result.length - 2));
            d3.select(this).text(result);
        }

        if (result != text && width > 2)
        {
            result += '..';
        }

        return result;
    },

    toggle_obj_type_transparency: function (obj_types) {
        if (!Object.isArray(obj_types))
        {
            this.options.obj_type_filter = [];
            return false;
        }

        this.vis
            .selectAll('[data-obj-type-id]')
            .classed('transparent', function (d) {
                return !obj_types.in_array(d.data.obj_type_id);
            })
            .selectAll('image')
            .classed('opacity-30', function (d) {
                return !obj_types.in_array(d.data.obj_type_id);
            });

        this.options.obj_type_filter = obj_types;
    },

    // This method will prepare the tooltips for the GUI.
    prepare_tooltips: function () {
        if (this.options.tooltips)
        {
            if (!this.$tooltip_div)
            {
                this.$tooltip_div = new Element('div', {
                    className: 'mouse-pointer explorer-tooltip',
                    style:     'position:fixed; top:-20; left:-20;'
                });
            }

            this.$element.insert(this.$tooltip_div);

            this.vis.selectAll('.node')
                .on('mouseover', function (d) {
                    var style = {
                        top:    (d3.event.clientY - 5) + 'px',
                        left:   (d3.event.clientX - 5) + 'px',
                        height: '10px',
                        width:  '10px'
                    };

                    this.$tooltip_div.stopObserving('click').on('click', function () {
                        this.options.click(d);
                    }.bind(this));

                    this.$tooltip_div.stopObserving('dblclick').on('dblclick', function () {
                        this.options.dblclick(d);
                    }.bind(this));

                    new Tip(
                        this.$tooltip_div.setStyle(style),
                        new Element('p', {
                            className: 'p5',
                            style:     'font-size:12px;'
                        }).update(d.data.obj_type_title + ': ' + d.data.obj_title),
                        {
                            effect: 'appear',
                            style:  'darkgrey'
                        });
                }.bind(this));
        }

        return this;
    },

    // This method will be used when zooming / dragging to hide the tooltip.
    hide_tooltip: function () {
        if (this.options.tooltips && this.$element.down('.explorer-tooltip'))
        {
            this.$element.select('.explorer-tooltip').each(function ($tooltip) {
                $tooltip.setStyle({
                    top:  -20,
                    left: -20
                })
            });
        }
    }
});

/**
 * i-doit CMDB Explorer javascript graph class.
 *
 * @author  Leonard Fischer <lfischer@i-doit.com>
 */
window.CMDB_Explorer_Graph = Class.create(window.CMDB_Explorer, {
    initialize: function ($super, $el, data, options, profile, object_types) {
        this.instance = 'CMDB_Explorer_Graph';

        // Adding a few default options for this explorer view.
        this.options.distance = 20;         // The node distance to eachother.
        this.options.gravity = .1;          // This is used to center all nodes. On "0" they will just float around.
        this.options.charge = -30;          // The attraction of the nodes under eachother.
        this.options.obj_type_filter = [];  // This filter will set the selected object types transparent.

        idoit.callbackManager.registerCallback('visualization-toggle-obj-types', this.toggle_obj_type_transparency, this);

        $super($el, data, options, profile, object_types);
    },

    show_root_path: function (d) {
        var nodes = d3.select('.node.active').classed('active', false),
            node  = d3.select('[data-id="' + d.id + '"]').classed('active', true);

        nodes.select('rect').style('stroke', null);
        node.select('rect').style('stroke', this.profile['highlight-color']);

        if (this.profile.mikro)
        {
            nodes.select('text').style('font-weight', null);
            node.select('text').style('font-weight', 'bold');
        }

        this.vis.selectAll('.link')
            .classed('highlight', false)
            .style('stroke', null)
            .attr("marker-end", "url(#end)")
            .filter(function (d2) {
                return (d2.source === d || d2.target === d);
            })
            .classed('highlight', true)
            .style('stroke', this.profile['highlight-color'])
            .attr("marker-end", "url(#end-highlight)");
    },

    process: function (first_shot) {
        var link,
            i,
            i2,
            width         = this.$element.getWidth(),
            height        = this.$element.getHeight(),
            link_distance = (this.profile.mikro ? 160 : Math.sqrt(Math.pow(this.options.node_width, 2) + Math.pow(this.options.node_height, 2)) * 1.25),
            id_mapper     = [],
            link_array    = [];

        if (!this.zoom_ev || this.zoom_ev === null)
        {
            this.zoom_ev = d3.behavior.zoom()
                             .scaleExtent([
                                 this.options.min_zoom_level,
                                 this.options.max_zoom_level
                             ])
                             .on('zoom', this.zooming.bind(this));
        }

        if (!this.layout)
        {
            this.layout = cola.d3adaptor().convergenceThreshold(0.1);
        }

        if (!this.svg)
        {
            this.svg = d3.select(this.$element)
                         .append('svg')
                         .attr("xmlns", "http://www.w3.org/2000/svg")
                         .attr("class", "responsive-observe");
        }

        if (!this.vis)
        {
            this.vis = this.svg.append('g')
                           .attr('id', this.options.name + '_g')
                           .attr('transform', 'translate(0,0) scale(1)');
        }

        // D3 WebCola
        this.layout
            .size([
                width,
                height
            ])
            .linkDistance(link_distance)
            .on("tick", function () {
                var links;

                this.vis.selectAll('.node')
                    .attr('transform', function (d) {
                        return 'translate(' + d.x + ',' + d.y + ')';
                    });

                links = this.vis.selectAll('.link')
                            .attr('x1', function (d) {
                                return d.source.x;
                            })
                            .attr('y1', function (d) {
                                return d.source.y;
                            })
                            .attr('x2', function (d) {
                                return d.target.x;
                            })
                            .attr('y2', function (d) {
                                return d.target.y;
                            });

                if (Prototype.Browser.IE || !!navigator.userAgent.match(/Trident.*rv[ :]*11\./))
                {
                    // IE has a problem with paths which inherit markers. This is a "hack" to make it work more or less...
                    links.each(function () {
                        this.parentNode.insertBefore(this, this);
                    });
                }

            }.bind(this));

        this.svg
            .attr('id', this.options.name)
            .attr('width', width)
            .attr('height', height);

        if (first_shot)
        {
            this.svg
                .call(this.zoom_ev)
                .call(this.zoom_ev.event)
                .on('dblclick.zoom', null);
        }

        // Process the data.
        for (i in this.data)
        {
            if (this.data.hasOwnProperty(i))
            {
                if (id_mapper.indexOf(parseInt(this.data[i].id)) == -1)
                {
                    id_mapper.push(parseInt(this.data[i].id));
                }
            }
        }

        for (i in this.data)
        {
            if (this.data.hasOwnProperty(i))
            {
                for (i2 in this.data[i].children)
                {
                    if (this.data[i].children.hasOwnProperty(i2) && id_mapper.indexOf(parseInt(this.data[i].children[i2])) != -1)
                    {
                        link_array.push({
                            source: id_mapper.indexOf(parseInt(this.data[i].id)),
                            target: id_mapper.indexOf(parseInt(this.data[i].children[i2]))
                        });
                    }
                }

                this.data[i].id = null;
                delete this.data[i].children;
            }
        }

        this.render(first_shot, link_array);
        this.prepare_tooltips();
        this.options.append_styles.call(this);
    },

    render: function (first_shot, list_array) {
        var nodeEnter,
            node = this.vis.selectAll('.node'),
            link = this.vis.selectAll('.link');

        // D3 WebCola
        this.layout
            .nodes(this.data)
            .links(list_array)
            .start(20, 60, 200);

        node = node.data(this.layout.nodes());

        // Declare the nodes.
        nodeEnter = node
            .enter().append("g")
            .style("opacity", 0)
            .attr("class", "node")
            .on('mouseover', this.options.mouseover)
            .on('mouseout', this.options.mouseout)
            .on('click', this.options.click)
            .on('dblclick', this.options.dblclick);

        node.interrupt().transition().duration(750)
            .style("opacity", 1);

        // Declare the links.
        link = link.data(this.layout.links());

        link.enter()
            .insert("line", "g")
            .style("opacity", 0)
            .attr("class", "link")
            .attr("marker-end", "url(#end)");

        link.interrupt().transition().duration(750)
            .style("opacity", 1);

        try
        {
            this.render_nodes(nodeEnter);
        }
        catch (e)
        {
            idoit.Notify.error(e);
        }

        if (Object.isArray(this.options.obj_type_filter))
        {
            this.toggle_obj_type_transparency(this.options.obj_type_filter);
        }
    }
});

/**
 * i-doit CMDB Explorer javascript tree class.
 *
 * @author  Leonard Fischer <lfischer@i-doit.com>
 */
window.CMDB_Explorer_Tree = Class.create(CMDB_Explorer, {
    initialize: function ($super, $el, data, options, profile, object_types) {
        this.instance = 'CMDB_Explorer_Tree';

        // Adding a few default options for this explorer view.
        this.options.vertical = true;       // Shall the tree be displayed from top to bottom or left to right?
        this.options.level_distance = 100;  // This number defines the space between to tree levels.
        this.options.mirrored = false;      // This is used for a tree, which has its root at the bottom.
        this.options.top_tree = '';         // This is used for the zooming function (we need the ID of the top and bottom tree).
        this.options.bottom_tree = '';      // This is used for the zooming function (we need the ID of the top and bottom tree).
        this.options.obj_type_filter = [];  // This filter will set the selected object types transparent.

        idoit.callbackManager.registerCallback('visualization-toggle-orientation', this.toggle_orientation, this);
        idoit.callbackManager.registerCallback('visualization-toggle-obj-types', this.toggle_obj_type_transparency, this);

        $super($el, data, options, profile, object_types);
    },

    show_root_path: function (d) {
        this.svg.select('.node.active').classed('active', false);

        var parent              = this.vis.select('[data-id="' + d.id + '"]').classed('active', true).data()[0],
            node_path_to_parent = [];

        // This is necessary to remove ALL highlighted nodes / links, because we work with two trees.
        this.svg
            .selectAll('.highlight').classed('highlight', false)
            .select('rect:not(.root-object)').style('stroke', null);

        while (!Object.isUndefined(parent))
        {
            node_path_to_parent.push(parent);

            this.vis
                .select('[data-id="' + parent.id + '"]').classed('highlight', true)
                .select('rect').style('stroke', this.profile['highlight-color']);

            parent = parent.parent;
        }

        this.svg.selectAll('path.link')
            .style('stroke', null)
            .filter(function (d) {
                return (node_path_to_parent.in_array(d.target));
            })
            .classed('highlight', true)
            .style('stroke', this.profile['highlight-color']);
    },

    toggle_orientation: function () {
        this.options.vertical = !this.options.vertical;

        this.hide_tooltip();
        this.process();
    },

    process: function (first_shot) {
        if (!this.zoom_ev || this.zoom_ev === null)
        {
            this.zoom_ev = d3.behavior.zoom()
                             .scaleExtent([
                                 this.options.min_zoom_level,
                                 this.options.max_zoom_level
                             ])
                             .on('zoom', this.zooming.bind(this));
        }

        if (!this.layout)
        {
            this.layout = d3.layout.tree();
        }

        if (!this.svg)
        {
            this.svg = d3.select(this.$element)
                         .append('svg')
                         .attr("xmlns", "http://www.w3.org/2000/svg");
        }

        if (!this.vis)
        {
            this.vis = this.svg.append('g')
                           .attr('id', this.options.name + '_g')
                           .attr('transform', 'translate(0,0) scale(1)');
        }

        this.layout
            .size([
                '100%',
                '100%'
            ])
            .separation(function () {
                return 1;
            })
            .nodeSize(this.options.vertical ? [
                this.options.node_width,
                this.options.node_height
            ] : [
                this.options.node_height,
                this.options.node_width
            ]);

        this.svg
            .attr('id', this.options.name)
            .attr('width', '100%')
            .attr('height', '100%');

        if (first_shot)
        {
            this.svg
                .call(this.zoom_ev)
                .call(this.zoom_ev.event)
                .on('dblclick.zoom', null);
        }

        this.render(first_shot);
        this.prepare_tooltips();
        this.options.append_styles.call(this);
    },

    render: function (first_shot) {
        // Compute the new tree layout.
        var nodeEnter,
            node,
            link,
            nodes         = this.layout.nodes(this.data),
            links         = this.layout.links(nodes),
            stroke_margin = 5;

        var diagonal = d3.svg.diagonal()
                         .source(function (d) {
                             if (this.options.vertical)
                             {
                                 if (this.options.mirrored)
                                 {
                                     return {
                                         x: d.source.x,
                                         y: (d.source.y - (this.options.node_height / 2) + stroke_margin)
                                     };
                                 }
                                 return {
                                     x: d.source.x,
                                     y: (d.source.y + (this.options.node_height / 2) - stroke_margin)
                                 };
                             }
                             else
                             {
                                 if (this.options.mirrored)
                                 {
                                     return {
                                         x: d.source.x,
                                         y: (d.source.y - (this.options.node_width / 2) + stroke_margin)
                                     };
                                 }
                                 return {
                                     x: d.source.x,
                                     y: (d.source.y + (this.options.node_width / 2) - stroke_margin)
                                 };
                             }
                         }.bind(this))
                         .target(function (d) {
                             if (this.options.vertical)
                             {
                                 if (this.options.mirrored)
                                 {
                                     return {
                                         x: d.target.x,
                                         y: (d.target.y + (this.options.node_height / 2) - stroke_margin)
                                     };
                                 }
                                 return {
                                     x: d.target.x,
                                     y: (d.target.y - (this.options.node_height / 2) + stroke_margin)
                                 };
                             }
                             else
                             {
                                 if (this.options.mirrored)
                                 {
                                     return {
                                         x: d.target.x,
                                         y: (d.target.y + (this.options.node_width / 2) - stroke_margin)
                                     };
                                 }
                                 return {
                                     x: d.target.x,
                                     y: (d.target.y - (this.options.node_width / 2) + stroke_margin)
                                 };
                             }
                         }.bind(this))
                         .projection(function (d) {
                             return (this.options.vertical) ? [d.x, d.y] : [d.y, d.x];
                         }.bind(this));

        // Normalize for fixed-depth.
        nodes.forEach(function (d) {
            d.y = d.depth * this.options.level_distance;

            if (this.options.mirrored)
            {
                d.y *= -1;
            }
        }.bind(this));

        node = this.vis.selectAll("g.node")
                   .data(nodes, function (d) {
                       return d.id || (d.id = ++i);
                   });

        // Declare the nodes.
        nodeEnter = node
            .enter().append("g")
            .style("opacity", (first_shot ? 1 : 0))
            .attr("class", "node")
            .attr("transform", function (d) {
                if (d.parent && !first_shot)
                {
                    if (this.options.vertical)
                    {
                        return "translate(" + d.parent.x + "," + d.parent.y + ")";
                    }
                    else
                    {
                        return "translate(" + d.parent.y + "," + d.parent.x + ")";
                    }
                }
            }.bind(this))
            .on('mouseover', this.options.mouseover)
            .on('mouseout', this.options.mouseout)
            .on('click', this.options.click)
            .on('dblclick', this.options.dblclick);

        node
            .interrupt().transition().duration(750)
            .style("opacity", 1)
            .attr("transform", function (d) {
                if (this.options.vertical)
                {
                    return "translate(" + d.x + "," + d.y + ")";
                }
                else
                {
                    return "translate(" + d.y + "," + d.x + ")";
                }
            }.bind(this));

        // Handle "exit" nodes - these are nodes, that are no longer being displayed (because "toggled" away or so)...
        node.exit()
            .interrupt().transition().duration(500)
            .style("opacity", 0)
            .remove();

        // Declare the links.
        link = this.vis.selectAll("path.link")
                   .data(links, function (d) {
                       return d.target.id;
                   });

        link
            .enter()
            .insert("path", "g")
            .style("opacity", (first_shot ? 1 : 0))
            .attr("class", "link")
            .attr('d', function (d) {
                if (first_shot)
                {
                    return diagonal({
                        source: {x: 0, y: 0},
                        target: {x: 0, y: 0}
                    });
                }
                else
                {
                    return diagonal({
                        source: d.source,
                        target: d.source
                    });
                }
            });

        link
            .interrupt().transition().duration(750)
            .style("opacity", 1)
            .attr('d', diagonal);

        // Handle "exit" links - these are links, that are no longer being displayed (because "toggled" away or so)...
        link.exit()
            .interrupt().transition().duration(500)
            .style("opacity", 0)
            .remove();

        this.render_nodes(nodeEnter);

        if (Object.isArray(this.options.obj_type_filter))
        {
            this.toggle_obj_type_transparency(this.options.obj_type_filter);
        }
    },

    // The "zooming" function for the tree graph.
    zooming: function () {
        var top       = d3.select('#' + this.options.top_tree + '_g'),
            bottom    = d3.select('#' + this.options.bottom_tree + '_g'),
            translate = d3.event.translate,
            scale     = (this.options.zoom ? d3.event.scale : 1);

        this.hide_tooltip();

        if (top)
        {
            top.attr('transform', 'translate(' + translate + ') scale(' + scale + ')');
        }

        if (bottom)
        {
            bottom.attr('transform', 'translate(' + translate + ') scale(' + scale + ')');
        }
    }
});