/**
 * Add or substract 1 from the value this function gets
 *
 * @param   val
 * @param   direction
 * @param   negate
 * @author  Niclas Potthast
 */
function changeCount (val, direction, negate) {
	if (direction == 'up') {
		return parseInt(val) + 1;
	} else {
		val = parseInt(val);

		if (negate == true) {
			return val - 1;
		} else {
			if (val < 2) {
				return val;
			} else {
				return val - 1;
			}
		}
	}
}

/**
 * This function will check, if the value of the given element is less than 1. If so, the value is set to 1.
 *
 * @param  $el
 */
function checkNeg ($el) {
	if (Object.isElement($el) && parseInt($el.getValue()) < 1) {
		$el.setValue(1);
	}
}

/**
 * This function will check, if the value of the given element is a number. If not, the value is set to 1.
 *
 * @param  $el
 */
function checkNaN ($el) {
	var val;
	if (Object.isElement($el)) {
		val = parseInt($el.getValue().replace(/\D/g, ''));

		if (isNaN(val)) {
			$el.setValue(1);
		} else {
			$el.setValue(val);
		}
	}
}