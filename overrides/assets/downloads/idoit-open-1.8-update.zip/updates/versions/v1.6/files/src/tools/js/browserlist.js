/**
* browserlist.js
* author: Niclas Potthast
* description: toggles objects between 2 classnames
*/
var oldID;

function setSelected(newID) {
	document.getElementById(newID).className = "linkSel";
	//is there already an 'oldID'?
	if(oldID != undefined) {
		document.getElementById(oldID).className = "link";
	}
	//save 'oldID' to toggle its class the next time the function is called
	oldID = newID;
}