var PropertySelector = Class.create();

PropertySelector.prototype = {
	initialize: function (name, options) {
		this.name = name;
		this.options = options;

        this.$selectionList = $(this.name + '_selection_field');
        this.$selectionBox = this.$selectionList.up('div');
        this.$sortCanceler = new Element('img', {src: window.dir_images + 'icons/silk/cross.png', className:'fr mr5 mouse-pointer hide', title:idoit.Translate.get('LC__UNIVERSAL__DESELECT')});

		this.options = Object.extend({
			url: '?call=get_category_data&ajax=1',  // URL for the AJAX calls (methods will be appended further in the code).
			provides: null,                         // Set this, to select properties which provide a certain type (C__PROPERTY__PROVIDES__REPORT, C__PROPERTY__PROVIDES__SEARCH, ...).
			group: true,                            // This option will write all selected properties inside the "category"-group.
			sortable: false,                        // This option will make the selected properties sortable.
			max_items: 38,                          // For the report manager we need a limitation of items.
			dynamic_properties: false,              // Define if the selectable properties shall contain the dynamic ones.
			allow_sorting: false,
			default_sorting: null,
			check_sorting: false,
			report: false,
			custom_fields: false,
			allowed_prop_types: [],
			consider_rights: true,
			hidden_field_name: 'lvls_raw',
			lvl: 1,
			catg_selection: null,
			cats_selection: null,
			catg_custom_selection: null,
			parent_prop: null,
			selector_size: '',                      // Width for chosen 'small', 'normal'
			dialog_width: '',
			complete_selection: null,
			replace_dynamic_properties: false,
			searchable: false,
			obj_type_id: null
		}, options || {});

		if (this.options.catg_selection == null && $(this.name + '_catg_selection')) {
			this.options.catg_selection = $(this.name + '_catg_selection').clone(true);
		}

		if (this.options.cats_selection == null && $(this.name + '_cats_selection')) {
			this.options.cats_selection = $(this.name + '_cats_selection').clone(true);
		}

		if (this.options.complete_selection == null) {
			this.options.complete_selection = this.name + '__COMPLETE';
		}

		// Bind the change-events to the select-fields.
		$(this.name + '_catg_selection').on('change', function () {
			this.load_properties('g');
		}.bind(this));

		$(this.name + '_cats_selection').on('change', function () {
			this.load_properties('s');
		}.bind(this));

		// Search related events.
		if (this.options.searchable) {
			// Event for search button.
			$(this.name + '_search_button').on('click', function () {
				this.search_properties($(this.name + '_search_input').getValue());
			}.bind(this));

			// Event for search input
			$(this.name + '_search_input').on('keypress', function (evt) {
				// Check for length before activating or triggering search.
				if ($(this.name + '_search_input').getValue().length > 2) {
					$(this.name + '_search_button').removeAttribute('disabled');

					// Trigger search on ENTER
					if (evt.keyCode == 13) {
						this.search_properties($(this.name + '_search_input').getValue());
					}
				}
				else {
					// Disable search button
					$(this.name + '_search_button').setAttribute('disabled', 'disabled');
					$(this.name + '_search_input').highlight();
				}

				if (evt.keyCode == 13) {
					evt.preventDefault();
				}
			}.bind(this));

			// Trigger search-evet for displaying the "nothing found" div.
			this.search_properties('');
		}

        if (this.options.allow_sorting) {
            this.$selectionBox.down('div').insert(this.$sortCanceler);

            this.$sortCanceler.on('click', function () {
                var $checked = this.$selectionBox.down(':checked');

                if ($checked) {
                    $checked.setValue(0);

                    this.$sortCanceler.addClassName('hide');
                }
            }.bind(this));

            this.$selectionBox.on('change', 'input', function () {
                this.$sortCanceler.removeClassName('hide');
            }.bind(this));
        }

		// Load the properties initially.
		this.load_properties('g');
		this.load_properties('s');

		// Custom categories only in report query builder.
		if (this.options.custom_fields) {
			if (this.options.catg_custom_selection == null && $(this.name + '_catg_custom_selection')) {
				this.options.catg_custom_selection = $(this.name + '_catg_custom_selection').clone(true);
			}

			$(this.name + '_catg_custom_selection').on('change', function () {
				this.load_properties('g_custom');
			}.bind(this));

			this.load_properties('g_custom');
		}
	},

    /**
     * Method for retrieving the selected categories properties.
     * @param  cat_type
     */
    load_properties:function (cat_type) {
        var cat_const = $(this.name + '_cat' + cat_type + '_selection').value;

        new Ajax.Request(this.options.url + '&func=get_properties_by_database',
            {
                parameters:{
                    'cat_const':cat_const,
                    'cat_type':cat_type,
                    'provide':this.options.provides,
                    'dynamic_properties':this.options.dynamic_properties,
                    'consider_rights':this.options.consider_rights,
                    'replace_dynamic_properties':this.options.replace_dynamic_properties
                },
                method:"post",
                onSuccess:function (transport) {
                    var arr = transport.responseJSON, i,
                        $prop_box = $(this.name + '_cat' + cat_type + '_properties').update('');

                    if (Object.keys(arr).length === 0) {
                        $prop_box.insert(
                            new Element('div', {className:'category-field'}).update(idoit.Translate.get('LC__REPORT__NO_ATTRIBUTES_FOUND'))
                        );
                    } else {
                        for (i in arr) {
                            if (arr.hasOwnProperty(i)) {
                                var $add_button = new Element('span', {className: 'plus'}),
                                    $property = new Element('div',
                                        {
                                            className: 'category-field',
                                            'data-cattype': cat_type,
                                            'data-catconst': cat_const,
                                            'data-propkey': i.split('#')[0],
                                            'data-propid': i.split('#')[1],
                                            'data-proptype': i.split('#')[2],
                                            'data-multi' : i.split('#')[3],
                                            'data-indexed' : i.split('#')[4]
                                        })
                                        .update(new Element('span').update(arr[i] || '<span class="text-grey">(' + idoit.Translate.get('LC__UNIVERSAL__EMPTY') + ')</span>'))
                                        .insert($add_button);

                                if (this.property_already_selected(i.split('#')[1]))
                                {
                                    $add_button.addClassName('hide');
                                }

                                $add_button.on('click', this.add.bindAsEventListener(this));

                                $prop_box.insert($property);
                            }
                        }
                    }
                }.bind(this)
            });
    },

    /**
     * Method for retrieving filtered properties
     * @param property_name
     */
    search_properties: function (property_name) {
	    if (property_name.length > 2) {
		    // Load filtered properties
		    new Ajax.Request(this.options.url + '&func=get_filtered_properties_by_database',
			    {
				    parameters: {
					    filter: property_name,
					    provide: this.options.provides,
					    dynamic_properties: this.options.dynamic_properties,
					    consider_rights: this.options.consider_rights,
					    replace_dynamic_properties: this.options.replace_dynamic_properties,
					    custom_fields: this.options.custom_fields,
					    obj_type_id: this.options.obj_type_id
				    },
				    method: "post",
				    onLoading: function () {
					    // Display ajax loader
					    $(this.name + '_search_button').childElements()[0].toggle();
					    $(this.name + '_search_button').childElements()[1].toggle();
				    }.bind(this),
				    onSuccess: function (transport) {
					    var arr = transport.responseJSON, i,
						    $search_box = $(this.name + '_search_result_container').update(''),
						    $search_count = $(this.name + '_search_count_container');

					    if (Object.keys(arr).length === 0) {
						    $search_count.hide();
						    $search_box.insert(new Element('div', {className: 'category-field'}).update(idoit.Translate.get('LC__REPORT__NO_ATTRIBUTES_FOUND')));
					    } else {
						    for (i in arr) {
							    if (arr.hasOwnProperty(i)) {
								    // Create property entry
								    var $add_button = new Element('span', {className: 'plus'}),
									    $property = new Element('div', {
										    className: 'category-field',
										    'data-cattype': arr[i].cat_type,
										    'data-catconst': arr[i].cat_const,
										    'data-cattitle': arr[i].cat_title,
										    'data-propkey': i.split('#')[0],
										    'data-propid': i.split('#')[1],
										    'data-proptype': i.split('#')[2],
                                            'data-multi': i.split('#')[3]
									    })
										    .update(new Element('span').update(arr[i].title))
										    .insert($add_button);

								    $add_button.on('click', this.add.bindAsEventListener(this));

								    $search_box.insert($property);
							    }
						    }

						    $(this.name + '_search_count').show().update(Object.keys(arr).length);
						    $search_count.show();
					    }
				    }.bind(this),
				    onComplete: function () {
					    // Hide ajax loader
					    $(this.name + '_search_button').childElements()[0].toggle();
					    $(this.name + '_search_button').childElements()[1].toggle();
				    }.bind(this)
			    });
	    } else {
		    // Nothing to show
		    $(this.name + '_search_count').update('0');
		    $(this.name + '_search_result_container').update(
			    new Element('div', {className: 'category-field'}).update(idoit.Translate.get('LC__REPORT__NO_ATTRIBUTES_FOUND'))
		    );
	    }
    },

    /**
     * Method for adding a new property to the selection.
     * @param  ev
     */
    add:function (ev) {
        var $button = ev.findElement('span'),
            el = $button.up('div'),
            cat_type      = el.readAttribute('data-cattype'),
            cat_const     = el.readAttribute('data-catconst'),
            cat_name      = (el.hasAttribute('data-cattitle') ?
                el.readAttribute('data-cattitle') :
                $$('select#' + this.name + '_cat' + cat_type + '_selection option[value="' + $(this.name + '_cat' + cat_type + '_selection').value + '"]')[0].innerHTML),
            property      = el.readAttribute('data-propkey'),
            property_id   = el.readAttribute('data-propid'),
            property_type = el.readAttribute('data-proptype'),
            property_multi = el.readAttribute('data-multi'),
            property_indexed = el.readAttribute('data-indexed'),
            property_name = el.down().innerHTML.replace(/<span class="removeable-addon">(.)*<\/span>/, '');

        if (this.count_items() >= this.options.max_items) {
            $(this.name + '_attr_error').update((idoit.Translate.get('LC__REPORT__FORM__ATTRIBUTE_COUNT_ERROR')).replace('%i', this.options.max_items));

            Effect.Appear(this.name + '_attr_error', {duration:0.5});

            return;
        }

        $button.addClassName('hide');

        // We check if the element has beed added to the selection.
        if (this.property_already_selected(property_id)) {
            return;
        }

        if (this.options.group) {
            // Add the selected property to the category.
            this.add_with_grouping(cat_type, cat_const, cat_name, property, property_name, property_id, property_type, (property_indexed == '1'), property_multi);
        } else {
            // Just add the property to the selection without grouping.
            this.add_without_grouping(cat_type, cat_const, cat_name, property, property_name, property_id, property_type, (property_indexed == '1'), property_multi);
        }

        this.update_hiddenfield();

        if (this.options.sortable) {
            this.make_sortable();
        }

        this.callback_add();
    },

    /**
     * Method for adding a property to it's category-group.
     * @param  cat_type
     * @param  cat_const
     * @param  cat_name
     * @param  property
     * @param  property_name
     * @param  property_id
     * @param  property_type
     * @param  property_sortable
     * @param  property_multi
     */
    add_with_grouping:function (cat_type, cat_const, cat_name, property, property_name, property_id, property_type, property_sortable, property_multi) {
        $(this.name + '_attribute_remover').setStyle({display:'none'});

        var cat_div,
            prop_checked,
            remove_button,
            remove_method = this.remove.bindAsEventListener(this),
            translation = idoit.Translate.get('LC__UNIVERSAL__GLOBAL');

        if (cat_type == 's') {
            translation = idoit.Translate.get('LC__UNIVERSAL__SPECIFIC');
        }

        // First we add the chosen property to the "chosen object"-container.
        cat_div = this.$selectionList.down('div.cat' + cat_type + '-' + cat_const);

        // If the grouping-div does not exist, we create it.
        if (typeof cat_div == 'undefined') {
            cat_div = new Element('div', {className:'selected-field cat' + cat_type + '-' + cat_const}).update(cat_name + ' (' + translation + ')');
            this.$selectionList.insert({bottom:cat_div});
        }

        if(this.options.allow_sorting){
            remove_button = new Element('span', {className:'minus', style:'right:25px'}).observe('click', remove_method);
        } else{
            remove_button = new Element('span', {className:'minus'}).observe('click', remove_method);
        }

        prop_div = new Element('div', {className:'property', 'data-cattype':cat_type, 'data-catconst':cat_const, 'data-propkey':property, 'data-propid':property_id, 'data-proptype':property_type});

        if(this.options.report && property_type == 'object_browser'  && property_multi == 0 /*&& this.options.lvl == 1*/)
        {
            // At first only one level possible
            reference_button = new Element('span', {className:'reference'});
            reference_button.on('click', function(e){
                Element.childElements(e.findElement().up().up().up()).each(function(el){
                    Element.childElements(el).each(function(el1){
                        if(el1.hasClassName('selected-field-focus'))
                        {
                            el1.removeClassName('selected-field-focus');
                        }
                    });
                });
                e.findElement().up().addClassName('selected-field-focus');
                var selector_name = e.findElement().up().readAttribute('data-propid');
                this.build_property_selector(cat_const+'-'+property, this.options.lvl);
            }.bind(this));
            cat_div.insert(prop_div.update(new Element('span').insert(' - ' + property_name))
                .insert(reference_button).insert(remove_button));
        }
        else
        {
            cat_div.insert(prop_div.update(new Element('span').insert(' - ' + property_name))
                .insert(remove_button));
        }

        if (this.options.allow_sorting)
        {
            if (this.options.check_sorting)
            {
                if (property_sortable)
                {
                    this.add_radio_button(cat_div, (this.options.default_sorting == property_id), property_id, false);
                }
                else if (property_sortable == undefined)
                {
                    // Ajax call to check property
                    this.add_radio_button(cat_div, false, property_id, true);
                }
            }
            else
            {
                this.add_radio_button(cat_div, (this.options.default_sorting == property_id), property_id, false);
            }
        }
    },

    /**
     * Method for adding a property to the selection.
     * @param cat_type
     * @param cat_const
     * @param cat_name
     * @param property
     * @param property_name
     * @param property_id
     * @param property_type
     * @param property_sortable
     * @param property_multi
     */
    add_without_grouping:function (cat_type, cat_const, cat_name, property, property_name, property_id, property_type, property_sortable, property_multi) {
        $(this.name + '_attribute_remover').setStyle({display:'none'});

        var remove_method = this.remove.bindAsEventListener(this),
            prop,
            remove_button;

        // Check if the property has already been add.
        if (! this.property_already_selected(property_id)) {
            if(this.options.allow_sorting){
                remove_button = new Element('span', {className:'minus', style:'right:25px'}).observe('click', remove_method);
            } else{
                remove_button = new Element('span', {className:'minus'}).observe('click', remove_method);
            }

            if(this.options.report && property_type == 'object_browser' && property_multi == 0)
            {
                // At first only one level possible
                var reference_button = new Element('span', {className:'reference'});
                reference_button.on('click', function(e){
                    Element.childElements(e.findElement().up().up().up()).each(function(el){
                        Element.childElements(el).each(function(el1){
                            if(el1.hasClassName('selected-field-focus'))
                            {
                                el1.removeClassName('selected-field-focus');
                            }
                        });
                    });
                    e.findElement().up().addClassName('selected-field-focus');
                    var selector_name = e.findElement().up().readAttribute('data-propid');
                    this.build_property_selector(cat_const+'-'+property, this.options.lvl);
                }.bind(this));

                prop = new Element('div', {className: 'selected-field property', 'data-cattype':cat_type, 'data-catconst':cat_const, 'data-propkey':property, 'data-propid':property_id, 'data-proptype': property_type})
                    .update(new Element('span').insert(property_name + ' ('+ cat_name + ')'))
                    .insert(reference_button).insert(remove_button);
            }
            else
            {
                prop = new Element('div', {className: 'selected-field property', 'data-cattype':cat_type, 'data-catconst':cat_const, 'data-propkey':property, 'data-propid':property_id, 'data-proptype': property_type})
                    .update(new Element('span').insert(property_name + ' (' + cat_name + ')'))
                    .insert(remove_button);
            }

            if (this.options.allow_sorting)
            {
                if (this.options.check_sorting)
                {
                    if (property_sortable)
                    {
                        this.add_radio_button(prop, (this.options.default_sorting == property_id), property_id, false);
                    }
                    else if (property_sortable == undefined)
                    {
                        // Ajax call to check property
                        this.add_radio_button(prop, false, property_id, true);
                    }
                }
                else
                {
                    this.add_radio_button(prop, (this.options.default_sorting == property_id), property_id, false);
                }
            }

            this.$selectionList.insert({bottom: prop});
        }
    },

    /**
     * Method for removing a property from the selection.
     * @param  e
     */
    remove:function (e) {
        // Because we remove a property, we can easily remove the error without further checks.
        Effect.Fade(this.name + '_attr_error', {duration:0.5});

        var el = e.findElement().up(),
            parent = el.up(),
            data_prop_id = el.readAttribute('data-propid'),
            data_cat_type = el.readAttribute('data-cattype'),
            data_const = el.readAttribute('data-catconst'),
            data_type = el.readAttribute('data-proptype'),
            data_prop_key = el.readAttribute('data-propkey');

        // Remove the element.
        el.remove();

        var $propertyList = $(this.name + '_cat' + data_cat_type + '_properties');

        if ($propertyList.down('[data-propid="' + data_prop_id + '"]'))
        {
            $propertyList.down('[data-propid="' + data_prop_id + '"]').down('span.plus').removeClassName('hide');
        }

        // We have to remove the hiddenfields, otherwise the report would be corrupted with wrong properties
        if(this.options.report && data_type == 'object_browser'){
            if(this.options.parent_prop != null){
                var parent_prop_arr = this.options.parent_prop.split('--');
                var check_parent_prop = [];
                var check_prop = '';

                if(parent_prop_arr.length >= 1)
                {
                    for(a = 0; a < parent_prop_arr.length; a++)
                    {
                        check_parent_prop.push(parent_prop_arr[a]);
                    }

                    check_prop = check_parent_prop.join('--') + '--' + data_const + '-' + data_prop_key;
                }
                else
                {
                    check_prop = data_const + '-' + data_prop_key;
                }

                if($(check_prop + '__HIDDEN')) {
                    this.remove_hidden_fields(check_prop, true);
                }
            } else if($(data_const + '-' + data_prop_key + '__HIDDEN')) {
                this.remove_hidden_fields(data_const + '-' + data_prop_key, true);
            }
        }

        // If we are grouping properties and the parent element has no children left, we remove it.
        if (this.options.group && parent.down() == null) {
            parent.remove();
        }

        // If we have no selected properties, display the notice.
        if (this.$selectionList.select('.property').length == 0) {
            $(this.name + '_attribute_remover').setStyle({display:'block'});
        }

        this.update_hiddenfield();
        this.callback_remove();
    },

    /**
     * Method to remove the hidden fields of the other levels
     * @param p_data_const
     * @param p_lvl
     * @param p_prop_key
     */
    remove_hidden_fields:function(p_parent_key, p_delete){

        if($(p_parent_key+'__HIDDEN'))
        {
            if($(p_parent_key+'__HIDDEN').value != ''){
                var hidden_field_value = JSON.parse($(p_parent_key+'__HIDDEN').value);

                hidden_field_value.each(function(ele) {
                    if(ele.g){
                        for(var a in ele.g) {
                            if(ele.g.hasOwnProperty(a)) {
                                ele.g[a].each(function(ele2){
                                    this.remove_hidden_fields(p_parent_key + '--' + a + '-' + ele2, true);
                                }.bind(this));
                            }
                        }
                    }
                    if(ele.s) {
                        for(var a in ele.s) {
                            if(ele.s.hasOwnProperty(a)) {
                                ele.s[a].each(function(ele2){
                                    this.remove_hidden_fields(p_parent_key + '--' + a + '-' + ele2, true);
                                }.bind(this));
                            }
                        }
                    }
                    if(ele.g_custom) {
                        for(var a in ele.g_custom) {
                            if(ele.g_custom.hasOwnProperty(a)) {
                                ele.g_custom[a].each(function(ele2){
                                    this.remove_hidden_fields(p_parent_key + '--' + a + '-' + ele2, true);
                                }.bind(this));
                            }
                        }
                    }
                }.bind(this));
                if($(p_parent_key+'__HIDDEN'))
                {
                    if($(p_parent_key+'__HIDDEN').next('td'))
                    {
                        $(p_parent_key+'__HIDDEN').next('td').remove();
                        $(p_parent_key+'__HIDDEN').next('td').remove();
                        $(p_parent_key+'__HIDDEN').next('td').remove();
                    }

                    if(p_delete)
                    {
                        $(p_parent_key+'__HIDDEN').remove();
                        if($(p_parent_key+'__HIDDEN_IDS'))
                        {
                            $(p_parent_key+'__HIDDEN_IDS').remove();
                        }
                    }
                }

                var selection = JSON.parse($(this.options.complete_selection).value);
                var new_selection = {};
                for(a in selection)
                {
                    if(a != p_parent_key)
                    {
                        // delete it from complete selection
                        new_selection[a] = selection[a];
                    }
                }
                $(this.options.complete_selection).value = Object.toJSON(new_selection);
            }
        }
    },

    /**
     * Method for updating the hidden field with the current data.
     */
    update_hiddenfield:function () {
        var property_elements = this.$selectionList.select('.property'),
            selection = [],
            selection_complete = [],
            selection_ids = [];

        if (this.options.group) {
            // We iterate through the groups.
            var c_cat_type = '',
                c_cat_const = '',
                tmp_selection = null,
                tmp_selection_complete = null;

            property_elements.each(function(el) {
                var cat_type = el.readAttribute('data-cattype'),
                    cat_const = el.readAttribute('data-catconst'),
                    prop_key = el.readAttribute('data-propkey'),
                    prop_title = el.down('span').innerHTML,
                    prop_id = el.readAttribute('data-propid');

                if (c_cat_type == cat_type && c_cat_const == cat_const) {
                    tmp_selection[cat_type][cat_const].push(prop_key);
                } else {
                    if (tmp_selection != null) {
                        selection.push(tmp_selection);
                    }

                    tmp_selection = {};
                    tmp_selection[cat_type] = {};
                    tmp_selection[cat_type][cat_const] = [prop_key];

                    tmp_selection_complete = {};
                    tmp_selection_complete[cat_type] = {};
                    tmp_selection_complete[cat_type][cat_const] = [prop_id, prop_key, prop_title];
                }

                c_cat_type = cat_type;
                c_cat_const = cat_const;

                selection_ids.push(prop_id);
            }.bind(this));

            // Also we have to add the last created selection.
            if (tmp_selection != null) {
                selection.push(tmp_selection);
                selection_complete.push(tmp_selection_complete);
            }
        } else {
            // We iterate through the selected properties.
            property_elements.each(function(el) {
                var cat_type = el.readAttribute('data-cattype'),
                    cat_const = el.readAttribute('data-catconst'),
                    prop_key = el.readAttribute('data-propkey'),
                    prop_id = el.readAttribute('data-propid'),
                    prop_title = el.down('span').innerHTML,
                    tmp_selection = {},
                    tmp_selection_complete = {};

                tmp_selection[cat_type] = {};
                tmp_selection[cat_type][cat_const] = [prop_key];

                tmp_selection_complete[cat_type] = {};
                tmp_selection_complete[cat_type][cat_const] = [prop_id, prop_key, prop_title];

                selection.push(tmp_selection);
                selection_ids.push(prop_id);
                selection_complete.push(tmp_selection_complete);
            }.bind(this))
        }

        var selection_complete_ele = $(this.options.complete_selection);

        $(this.name + '__HIDDEN').setValue(Object.toJSON(selection));
        $(this.name + '__HIDDEN_IDS').setValue(Object.toJSON(selection_ids));

        if(selection_complete_ele.value == '')
        {
            var prop_hash = {'root':selection_complete};
        }
        else
        {
            var prop_hash = JSON.parse(selection_complete_ele.value);
            if(this.options.parent_prop == null)
            {
                // Root
                prop_hash['root'] = selection_complete;
            }
            else
            {
                prop_hash[this.options.parent_prop] = selection_complete;
            }
        }
        selection_complete_ele.value = Object.toJSON(prop_hash);
    },

    /**
     * Method for retrieving the current amount of selected items.
     * @return  integer
     */
    count_items:function () {
        return this.$selectionList.select('.property').length;
    },

    /**
     * Method for handling preselection data (only JSON is allowed here).
     * @param  json
     */
    handle_preselection:function(json) {
        if (this.options.group) {
            json.each(function(i) {
                this.add_with_grouping(i.cat_type, i.cat_const, i.cat_title, i.prop_key, i.prop_title, i.prop_id, i.prop_type, i.prop_sortable);
            }.bind(this));
        } else {
            json.each(function(i) {
                this.add_without_grouping(i.cat_type, i.cat_const, i.cat_title, i.prop_key, i.prop_title, i.prop_id, i.prop_type, i.prop_sortable);
            }.bind(this));
        }

        this.update_hiddenfield();

        if (this.options.sortable) {
            this.make_sortable();
        }
    },

    /**
     * Method for handling preselection data for the levels.
     * @param json
     */
    handle_preselection_lvls:function(json) {
        var lvls = $H(json);
        lvls.each(function(el){
            var lvl = parseInt(el.key);
            var content = $H(el.value);
            if($('spacer_lvl_'+lvl))
            {
                var tr_spacer = $('spacer_lvl_'+lvl);
                var next_tr_spacer = new Element('tr', {className:'selector-spacer mt5', style:'min-width:30px', id:'spacer_lvl_'+(lvl+1)});
                tr_spacer.up().insert(next_tr_spacer);

                content.each(function(el2){
                    var hidden_field = new Element('input', {type:'hidden', name:'lvls_raw['+lvl+']['+el2.key+']', id:el2.key+'__HIDDEN'});
                    hidden_field.value = JSON.stringify(el2.value);
                    tr_spacer.insert(hidden_field);
                });
            }

        });
    },

    /**
     * Method for activating the sortable-feature.
     */
    make_sortable:function () {
        Position.includeScrollOffsets = true;
        Sortable.create(this.$selectionList, {
            tag:'div',
            onChange:function () {
                // Somehow the "onUpdate" callback won't work, so we use this.
                this.update_hiddenfield();
            }.bind(this)
        });

        // Add the "move" cursor to the selections.
        if (! this.$selectionList.hasClassName('draggable')) {
            this.$selectionList.addClassName('draggable');
        }

        // IE fix.
        Element.makePositioned(this.$selectionList);
    },

    /**
     * Method for finding out, if an element has already been selected.
     * @param  prop_id
     */
    property_already_selected:function (prop_id) {
        return !! this.$selectionList.select('.property').filter(function(i) {
            return (i.readAttribute('data-propid') == prop_id);
        }).length;
    },

    /**
     * Method which creates the radio button after the remove button (example: for sorting)
     * @param prop
     * @param prop_checked
     * @param property_id
     * @param property_sortable_check
     */
    add_radio_button:function(prop, prop_checked, property_id, property_sortable_check) {
        var $checkbox = new Element('input', {type:'radio', style:'margin-top:2px', name:'default_sorting', value:property_id, checked:prop_checked});

        if(property_sortable_check === false) {
            prop.insert(new Element('span', {style:'float:right'})
                .insert($checkbox));

            if (prop_checked) {
                this.$sortCanceler.removeClassName('hide');
            }

            return prop;
        } else{
            new Ajax.Request(this.options.url + '&func=is_property_sortable',
                {
                    parameters:{
                        prop_id:property_id
                    },
                    method:"post",
                    onSuccess:function (transport) {
                        var check = transport.responseJSON;
                        if(check === true){
                            prop.insert(new Element('span', {style:'float:right'})
                                .insert($checkbox));

                            if (prop_checked) {
                                this.$sortCanceler.removeClassName('hide');
                            }

                            return prop;
                        }
                    }.bind(this)
                });
            return prop;
        }
    },

    build_property_selector:function(p_id, p_lvl, p_data){

        var tr_spacer = $('spacer_lvl_'+p_lvl);

        if(p_lvl == 1)
        {
            var parent_prop = p_id;
        }
        else
        {
            var parent_prop = this.options.parent_prop+'--'+p_id;
        }

        if(typeof tr_spacer.down('td') != 'undefined')
        {
            if(typeof tr_spacer.down('td').next('td') != 'undefined')
            {
                tr_spacer.down('td').remove();
                tr_spacer.down('td').remove();
                tr_spacer.down('td').remove();
                var i = 1;
                while($('spacer_lvl_'+(parseInt(p_lvl)+i))){
                    if(!$('spacer_lvl_'+(parseInt(p_lvl)+i)).down('input'))
                    {
                        $('spacer_lvl_'+(parseInt(p_lvl)+i)).remove();
                    }
                    else
                    {
                        if($('spacer_lvl_'+(parseInt(p_lvl)+i)).down('td'))
                        {
                            $('spacer_lvl_'+(parseInt(p_lvl)+i)).down('td').remove();
                            $('spacer_lvl_'+(parseInt(p_lvl)+i)).down('td').remove();
                            $('spacer_lvl_'+(parseInt(p_lvl)+i)).down('td').remove();
                        }
                    }
                    i++;
                }
            }
        }

        if(!$(parent_prop+'__HIDDEN'))
        {
            tr_spacer.insert(new Element('input', {type:'hidden', id:parent_prop+'__HIDDEN', name:this.options.hidden_field_name + '[' + p_lvl + '][' + parent_prop + ']'}));
        }
        if(!$(parent_prop+'__HIDDEN_IDS'))
        {
            tr_spacer.insert(new Element('input', {type:'hidden', id:parent_prop+'__HIDDEN_IDS', name:this.options.hidden_field_name + '__IDS[' + p_lvl + '][' + parent_prop + ']'}));
        }

        if(typeof tr_spacer.down('td') == 'undefined')
        {
            var selector_left = new Element('td', {className:'vat pt5'});
            var selector_right = new Element('td', {className:'vat pt5'});
        }
        else
        {
            var selector_left = tr_spacer.down('td');
            var selector_right = tr_spacer.down('td').next('td');
        }

        switch(this.options.selector_size)
        {
            case 'small':
                var min_width = '305px';
                break;
            case 'normal':
            default:
                var min_width = '400px';
                break;
        }

        var div_content_left = new Element('div', {className:'border fl mr20', style:'width:'+min_width});
        var ul_headline_left = new Element('ul', {className:'m0 gradient rowser-tabs', id:parent_prop+'_tabs'});

        var li_global = new Element('li').insert(new Element('a', {className:'text-shadow', href:'#'+parent_prop+'_catg_list'}).insert(idoit.Translate.get('LC__UNIVERSAL__GLOBAL')));
        var div_catg = new Element('div', {id:parent_prop+'_catg_list', className:'m10 browser-tab-content'});

        var li_specific = new Element('li').insert(new Element('a', {className:'text-shadow', href:'#'+parent_prop+'_cats_list'}).insert(idoit.Translate.get('LC__UNIVERSAL__SPECIFIC')));
        var div_cats = new Element('div', {id:parent_prop+'_cats_list', className:'m10 browser-tab-content', style:'display:none;'});

        if(this.options.catg_custom_selection !== null)
        {
            var li_custom = new Element('li').insert(new Element('a', {className:'text-shadow', href:'#'+parent_prop+'_catg_custom_list'}).insert(idoit.Translate.get('LC__CMDB__CATG__CUSTOM')));
            var div_custom = new Element('div', {id:parent_prop+'_catg_custom_list', className:'m10 browser-tab-content'});
        }

        var div_error = new Element('div', {id:parent_prop+'_attr_error', className:'box-red m10 p5', style:'display:none;'});

	    if (this.options.catg_custom_selection !== null) {
		    selector_left.insert(div_content_left.insert(ul_headline_left.insert(li_global).insert(li_specific).insert(li_custom)).insert(div_catg).insert(div_cats).insert(div_custom).insert(div_error));
	    } else {
		    selector_left.insert(div_content_left.insert(ul_headline_left.insert(li_global).insert(li_specific)).insert(div_catg).insert(div_cats).insert(div_error));
	    }

        var div_content_right = new Element('div', {className:'border fl', style:'width:'+min_width});
        var div_headline_right = new Element('div', {className:'m0 p10 gradient browser-tabs', style:'height:15px; border-bottom:1px solid #888;'});
        var span_headline_right = new Element('span', {className:'text-shadow'}).insert(new Element('b', {style:'color:#333333;font-size:10px;'}).insert(idoit.Translate.get('LC__REPORT__INFO__CHOSEN_PROPERTIES_TEXT')));
        var div_selection_right = new Element('div', {className:'m10', id:parent_prop+'_selection_field'});
        var div_remover_right = new Element('div', {className:'category-field', id:parent_prop+'_attribute_remover'}).insert(idoit.Translate.get('LC__REPORT__NO_ATTRIBUTES_ADDED'));
        selector_right.insert(div_content_right.insert(div_headline_right.insert(span_headline_right)).insert(div_selection_right.insert(div_remover_right)));

        tr_spacer.insert(selector_left).insert(selector_right);

	    if (!$('spacer_lvl_' + this.options.lvl + 1)) {
		    var remover = new Element('span', {className: 'property-remover'}).observe('click', function () {
			    var delete_all = false, i = 1;

			    $('spacer_lvl_' + p_lvl).down('td').remove();
			    $('spacer_lvl_' + p_lvl).down('td').remove();
			    $('spacer_lvl_' + p_lvl).down('td').remove();

			    this.remove_hidden_fields(parent_prop, true);

			    if (!$('spacer_lvl_' + p_lvl).down('input')) {
				    delete_all = true;
			    }

			    while ($('spacer_lvl_' + (parseInt(p_lvl) + i))) {
				    if (delete_all) {
					    $('spacer_lvl_' + (parseInt(p_lvl) + i)).remove();
				    }
				    else {
					    if ($('spacer_lvl_' + (parseInt(p_lvl) + i)).down('td')) {
						    $('spacer_lvl_' + (parseInt(p_lvl) + i)).down('td').remove();
						    $('spacer_lvl_' + (parseInt(p_lvl) + i)).down('td').remove();
						    $('spacer_lvl_' + (parseInt(p_lvl) + i)).down('td').remove();
					    }
				    }
				    i++;
			    }
		    }.bind(this));
		    var td_remover = new Element('td', {className: 'vat pt5 pl5'}).insert(remover);
		    tr_spacer.insert(td_remover);

		    if (!$('spacer_lvl_' + (parseInt(this.options.lvl) + 1))) {
			    var td_next_spacer = new Element('tr', {id: 'spacer_lvl_' + (parseInt(this.options.lvl) + 1), style: 'min-width:30px', className: 'selector-spacer mt5'});
			    tr_spacer.up().insert(td_next_spacer);
		    }
	    }

        var catg_select = this.options.catg_selection.clone(true);
        catg_select.id = parent_prop+'_catg_selection';
        catg_select.name = parent_prop+'_catg_selection';

        var cats_select = this.options.cats_selection.clone(true);
        cats_select.id = parent_prop+'_cats_selection';
        cats_select.name = parent_prop+'_cats_selection';

        catg_select.selectedIndex = 0;
        cats_select.selectedIndex = 0;

        var div_properties_catg_left = new Element('div', {id:parent_prop+'_catg_properties'});
        var div_properties_cats_left = new Element('div', {id:parent_prop+'_cats_properties'});

        $(parent_prop+'_catg_list').insert(catg_select).insert(div_properties_catg_left);

        new Chosen(catg_select, {
            disable_search_threshold: 10,
            width:                    '100%',
            height:                   '20px',
            search_contains:          true
        });

        $(parent_prop+'_cats_list').insert(cats_select).insert(div_properties_cats_left);

        new Chosen(cats_select, {
            disable_search_threshold: 10,
            width:                    '100%',
            height:                   '20px',
            search_contains:          true
        });

        // Custom categories
        if(this.options.catg_custom_selection !== null)
        {
            var catg_custom_select = this.options.catg_custom_selection.clone(true);
            catg_custom_select.id = parent_prop+'_catg_custom_selection';
            catg_custom_select.name = parent_prop+'_catg_custom_selection';
            catg_custom_select.selectedIndex = 0;
            var div_properties_catg_custom_left = new Element('div', {id:parent_prop+'_catg_custom_properties'});
            $(parent_prop+'_catg_custom_list').insert(catg_custom_select).insert(div_properties_catg_custom_left);

            new Chosen(catg_custom_select, {
                disable_search_threshold: 10,
                width:                    '100%',
                height:                   '20px',
                search_contains:          true
            });
        }

        var new_options = {
            url:this.options.url,
            provides:this.options.provides,
            group:this.options.group,
            sortable:this.options.sortable,
            max_items:this.options.max_items,
            dynamic_properties:this.options.dynamic_properties,
            default_sorting:this.options.default_sorting,
            allow_sorting:this.options.allow_sorting,
            check_sorting:this.options.check_sorting,
            report:this.options.report,
            custom_fields:this.options.custom_fields,
            consider_rights:this.options.consider_rights,
            hidden_field_name:this.options.hidden_field_name,
            lvl:this.options.lvl+1,
            catg_selection:this.options.catg_selection,
            cats_selection:this.options.cats_selection,
            catg_custom_selection:this.options.catg_custom_selection,
            parent_prop:parent_prop,
            selector_size: this.options.selector_size,
            dialog_width: this.options.dialog_width,
            complete_selection: this.options.complete_selection,
            replace_dynamic_properties: this.options.replace_dynamic_properties
        };

        var new_selector = new PropertySelector(parent_prop, new_options);

        if($(parent_prop+'__HIDDEN').value != '')
        {
            new Ajax.Request(this.options.url + '&func=format_preselection',
                {
                    parameters:{
                        'data':$(parent_prop+'__HIDDEN').value
                    },
                    method:"post",
                    onSuccess:function (transport) {
                        new_selector.handle_preselection(transport.responseJSON);
                    }.bind(new_selector)
                });
        }

        window.category_tabs = new Tabs(parent_prop+'_tabs', {
            wrapperClass: 'browser-tabs',
            contentClass: 'browser-tab-content',
            tabClass: 'text-shadow'
        });

    },

    /**
     * Method placeholder for the add button
     */
    callback_add:Prototype.emptyFunction,

    /**
     * Method placeholder for the remove button
     */
    callback_remove:Prototype.emptyFunction
};