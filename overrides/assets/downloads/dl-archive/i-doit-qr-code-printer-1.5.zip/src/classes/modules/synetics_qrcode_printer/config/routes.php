<?php

use idoit\Module\SyneticsQrcodePrinter\Controller\IndexController;
use Symfony\Component\Routing\Loader\Configurator\RoutingConfigurator;

return function (RoutingConfigurator $routes) {
    $routes->add('synetics_qrcode_printer.index', '/synetics_qrcode_printer')
        ->methods(['GET'])
        ->controller([IndexController::class, 'landingPage']);
};
