<?php

/**
 * English translation.
 */
return [
    'LC__QRCODE_PRINTER' => 'QR-Code Printer',
    'LC__QRCODE_PRINTER__DESCRIPTION_HEADLINE' => 'Description',
    'LC__QRCODE_PRINTER__DESCRIPTION' => 'The i-doit QR-Code Printer allows you to print labels comfortably using your label printer. A configuration is provided for you to ensure that the formats match your requirements. If you scan the QR code with a smartphone or a tablet, for example, then you will be forwarded to the overview page of the labelled object.',
    'LC__QRCODE_PRINTER__INFO' => 'This add-on requires a Windows application for full functionality.',
    'LC__QRCODE_PRINTER__LINKS' => 'You can <a class="link-download" href="%s" target="_blank">download</a> it directly, or find a detailed setup instructions in the <a class="link-external" href="https://kb.i-doit.com/en/i-doit-add-ons/i-doit-qr-code-printer.html" target="_blank">Knowledge base</a>.',
];
