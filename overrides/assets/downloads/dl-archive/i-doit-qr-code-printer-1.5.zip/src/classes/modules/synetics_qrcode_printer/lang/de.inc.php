<?php

/**
 * German translation.
 */
return [
    'LC__QRCODE_PRINTER' => 'QR-Code-Drucker',
    'LC__QRCODE_PRINTER__DESCRIPTION_HEADLINE' => 'Beschreibung',
    'LC__QRCODE_PRINTER__DESCRIPTION' => 'Mit dem i-doit QR-Code-Drucker können Sie bequem Etiketten über Ihren Etikettendrucker drucken. Eine Konfiguration steht bereit, damit die Formate Ihren Anforderungen entsprechen. Wenn Sie den QR-Code z.B. mit einem Smartphone oder Tablet scannen, werden Sie zur Übersichtsseite des beschrifteten Objekts weitergeleitet.',
    'LC__QRCODE_PRINTER__INFO' => 'Dieses Add-on benötigt eine Windows-Anwendung für den vollen Funktionsumfang.',
    'LC__QRCODE_PRINTER__LINKS' => 'Sie können sie direkt <a class="link-download" href="%s" target="_blank">herunterladen</a> oder eine ausführliche Einrichtungserklärung in der <a class="link-external" href="https://kb.i-doit.com/de/i-doit-add-ons/i-doit-qr-code-printer.html" target="_blank">Knowledge base</a> finden.',
];
