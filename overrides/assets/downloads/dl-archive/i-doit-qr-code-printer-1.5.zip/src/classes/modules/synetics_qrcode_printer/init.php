<?php
/**
 * i-doit
 *
 * @package     synetics_qrcode_printer add-on
 * @copyright   synetics
 * @license     https://www.i-doit.com/produkte/add-ons
 */

use idoit\Psr4AutoloaderClass;

if (isys_module_manager::instance()->is_active('synetics_qrcode_printer')) {
    Psr4AutoloaderClass::factory()->addNamespace('idoit\Module\SyneticsQrcodePrinter', __DIR__ . '/src/');
}
