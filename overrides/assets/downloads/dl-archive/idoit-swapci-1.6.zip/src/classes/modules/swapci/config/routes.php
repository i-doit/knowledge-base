<?php

use idoit\Module\SwapCi\Controller\SwapController;
use Symfony\Component\Routing\Loader\Configurator\RoutingConfigurator;

return function (RoutingConfigurator $routes) {
    $routes->add('swap-ci.swap', '/swap-ci/swap')
        ->methods(['POST'])
        ->controller([SwapController::class, 'swap']);
};
