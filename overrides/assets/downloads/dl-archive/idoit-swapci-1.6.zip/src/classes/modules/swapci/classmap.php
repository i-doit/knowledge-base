<?php
/**
 * Classmap for "swapci" generated on 2023-08-30
 */

return array (
  'isys_ajax_handler_swapci' => 'src/classes/modules/swapci/handler/ajax/isys_ajax_handler_swapci.class.php',
  'isys_auth_swapci' => 'src/classes/modules/swapci/auth/isys_auth_swapci.class.php',
  'isys_module_swapci' => 'src/classes/modules/swapci/isys_module_swapci.class.php',
  'isys_swapci_dao' => 'src/classes/modules/swapci/dao/isys_swapci_dao.class.php',
  'isys_swapci_reportview_show_objects' => 'src/classes/modules/swapci/reportview/isys_swapci_reportview_show_objects.class.php',
  'isys_swapci_swap' => 'src/classes/modules/swapci/swap/isys_swapci_swap.class.php',
);
