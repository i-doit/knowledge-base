<?php

namespace idoit\Module\Analytics\Controller;

use idoit\Controller\Base;
use isys_application as Application;
use isys_component_tree as Tree;
use isys_controller;
use isys_module as Module;
use isys_register as Register;

/**
 * Class Main
 *
 * @package idoit\Module\Analytics\Controller
 */
class Main extends Base implements isys_controller
{

    /**
     * @param Application $p_application
     *
     * @return null
     */
    public function dao(Application $p_application)
    {
        return null;
    }

    /**
     * @param Register    $p_request
     * @param Application $p_application
     *
     * @return null
     */
    public function handle(Register $p_request, Application $p_application)
    {
        return null;
    }

    /**
     * @param Register    $p_request
     * @param Application $p_application
     * @param Tree        $p_tree
     *
     * @return null
     */
    public function tree(Register $p_request, Application $p_application, Tree $p_tree)
    {
        return null;
    }

    /**
     * Main constructor.
     *
     * @param Module $p_module
     */
    public function __construct(Module $p_module)
    {

    }
}
