##  Copyright and License

Copyright (C) [synetics GmbH](https://i-doit.com/)

i-doit pro has a [proprietary license](https://www.i-doit.com/en/company/documents/) which you may find on our website.

i-doit open is licensed under the [GNU Affero GPL version 3 or later (AGPLv3+)](https://gnu.org/licenses/agpl.html). This is free software: you are free to change and redistribute it. There is NO WARRANTY, to the extent permitted by law.
