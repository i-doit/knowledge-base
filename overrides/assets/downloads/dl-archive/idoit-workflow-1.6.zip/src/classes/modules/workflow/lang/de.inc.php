<?php
/**
 * i-doit
 *
 * "Workflow" Module language file
 *
 * @package        Modules
 * @subpackage     Workflow
 * @author         Viviane Goetzen <vgoetzen@i-doit.com>
 * @copyright      2015 synetics GmbH
 * @version        1.0.0
 * @license        http://www.i-doit.com/license
 */

return [
    'LC_WORKFLOW_DETAIL__COMPLETE'                            => 'Abschließen',
    'LC_WORKFLOW_DETAIL__DESCRIBE'                            => 'Beschreiben',
    'LC_WORKFLOW_DETAIL__EXCEPTIONS'                          => 'Ausnahme(n)',
    'LC_WORKFLOW_DETAIL__MEASURES'                            => 'Maßnahmen',
    'LC_WORKFLOW_DETAIL__SEND_REPORT'                         => 'Bericht senden an',
    'LC_WORKFLOW_DETAIL__WITH_DESCRIPTION'                    => 'Mit Beschreibung',
    'LC_WORKFLOW_DETAIL__WIZARD2'                             => 'Bitte einen Objektnamen für das globale Dateiobjekt wählen',
    'LC_WORKFLOW_EMAIL__NOTIFICATION_SETTINGS'                => 'Benachrichtigungseinstellungen',
    'LC_WORKFLOW_EMAIL__NOTIFY1'                              => 'Empfänger und Autor mit einer E-Mail benachrichtigen, wenn der Workflow folgenden Status hat',
    'LC_WORKFLOW_TREE__EMAIL'                                 => 'E-Mail',
    'LC_WORKFLOW__ACTIVE'                                     => 'Aktiv',
    'LC_WORKFLOW__CHECK'                                      => 'Nach leerem Feld überprüfen',
    'LC_WORKFLOW__CREATION'                                   => 'Workflow erstellen',
    'LC_WORKFLOW__EXCEPTION__NO_OBJECTS'                      => 'Um einen CMDB-Workflow erstellen zu können, müssen Sie mindestens ein Objekt auswählen.',
    'LC_WORKFLOW__KEY'                                        => 'Schlüssel',
    'LC_WORKFLOW__METADATA'                                   => 'Workflow Metadaten',
    'LC_WORKFLOW__NO_DEFINITIONS'                             => 'Dieser Workflow Typ beinhaltet noch keinerlei Definitionen',
    'LC_WORKFLOW__NO_WORKFLOW_TYPE_SELECTED'                  => 'Kein Workflow Typ ausgewählt.',
    'LC_WORKFLOW__PARAMETER'                                  => 'Workflow Parameter',
    'LC_WORKFLOW__TEMPL_PARAMS'                               => 'Template Parameter',
    'LC_WORKFLOW__TYPE'                                       => 'Workflow Typ',
    'LC__AUTH_GUI__WORKFLOWS_CONDITION'                       => 'Workflows',
    'LC__AUTH__SYSTEM_EXCEPTION__MISSING_RIGHT_FOR_WORKFLOWS' => 'Sie verfügen über unzureichende Rechte, um das Workflow Modul zu öffnen.',
    'LC__CMDB__CATG__WORKFLOW'                                => 'Workflows',
    'LC__CMDB__TREE__SYSTEM__SETTINGS_SYSTEM__WORKFLOW'       => 'Workflow',
    'LC__LOGBOOK_ENTRY__WORKFLOW_CREATED'                     => '[{Type}]: [{Name}] wurde angelegt',
    'LC__LOGBOOK__WORKFLOW_HAS_BEEN_ACCEPTED'                 => 'wurde angenommen',
    'LC__LOGBOOK__WORKFLOW_HAS_BEEN_CANCELLED'                => 'wurde abgebrochen',
    'LC__LOGBOOK__WORKFLOW_HAS_BEEN_CONDUCTED'                => 'wurde abgeschlossen',
    'LC__MODULE__WORKFLOW'                                    => 'Workflow',
    'LC__TASK__DETAIL__WORKORDER__NOT_ASSIGNABLE'             => 'Das Annehmen dieses Workflows ist nicht möglich, solange der übergeordnete Workflow nicht abgeschlossen ist.',
    'LC__TASK__DETAIL__WORKORDER__PARENT_WORKFLOW'            => 'Übergeordneter Workflow',
    'LC__WORKFLOWS__ALL'                                      => 'Alle Workflows',
    'LC__WORKFLOWS__CHECKLIST_LIMIT'                          => 'Maximalanzahl Einträge für Filteransicht',
    'LC__WORKFLOWS__COMPONENT_OF_CHECKLIST'                   => 'Dieser Task/Checkliste ist Bestandteil folgender Checkliste oder Task',
    'LC__WORKFLOWS__HAS_CHILD_TASK'                           => 'Dieser Task/Checkliste hat folgende Tasks oder Checklisten zugeordnet',
    'LC__WORKFLOWS__CURRENT_DAY'                              => 'Aktueller Tag',
    'LC__WORKFLOWS__CURRENT_MONTH'                            => 'Aktueller Monat',
    'LC__WORKFLOWS__MY'                                       => 'Meine Workflows',
    'LC__WORKFLOWS__OVERVIEW'                                 => 'Übersicht',
    'LC__WORKFLOWS__SEND_REPORT'                              => 'Bericht senden und Workflow abschließen',
    'LC__WORKFLOWS__STARTING_NOW'                             => 'Beginnend ab',
    'LC__WORKFLOW__ACTION__COMPLETE_ERROR'                    => 'Workflow konnte nicht abgeschlossen werden.<br />Zum Abschließen müssen Sie einer der zugewiesenen Benutzer sein und der Workflow sich in einer der folgenden Status befinden: Offen, Zugewiesen, Beendet.',
    'LC__WORKFLOW__ACTION__TYPE__ACCEPT'                      => 'Angenommen',
    'LC__WORKFLOW__ACTION__TYPE__ACCEPTED'                    => 'Angenommen',
    'LC__WORKFLOW__ACTION__TYPE__ASSIGN'                      => 'Zugewiesen',
    'LC__WORKFLOW__ACTION__TYPE__CANCEL'                      => 'Abgebrochen',
    'LC__WORKFLOW__ACTION__TYPE__COMPLETE'                    => 'Abgeschlossen',
    'LC__WORKFLOW__ACTION__TYPE__NEW'                         => 'Neu',
    'LC__WORKFLOW__ACTION__TYPE__NOTIFICATION'                => 'Benachrichtigt',
    'LC__WORKFLOW__ACTION__TYPE__OPEN'                        => 'Offen',
    'LC__WORKFLOW__ASSIGNED_TASKS'                            => 'Zugewiesene Aufträge',
    'LC__WORKFLOW__CANNOT_DELETE'                             => 'Konnte %TITLE% nicht löschen, da dieser Task Teil einer Checkliste ist.',
    'LC__WORKFLOW__CHECK_CANNOT_DELETE'                       => 'Kann %TITLE% nicht löschen, da bereits Tasks von dieser Checkliste existieren. Löschen Sie zunächst alle Tasks dieser Checkliste.',
    'LC__WORKFLOW__CREATED_TASKS'                             => 'Erstellte Aufträge',
    'LC__WORKFLOW__HIDE_CHECKLISTS_IN_MYDOIT'                 => 'Checklisten im my-doit Bereich ausblenden',
    'LC__WORKFLOW__SELECT_TYPE'                               => 'Wählen Sie bitte den Workflow Typ, den Sie erstellen möchten',
    'LC__WORKFLOW__TEMPLATES'                                 => 'Vorlagen',
    'LC__WORKFLOW__TEMPLATE_PARAMETERS'                       => 'Parameter',
    'LC__WORKFLOW__TYPES'                                     => 'Workflow Typen',
    'isys_workflow_category'                                  => 'Workflow: Kategorien',
];
