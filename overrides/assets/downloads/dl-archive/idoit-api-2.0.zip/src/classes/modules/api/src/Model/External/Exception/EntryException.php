<?php

namespace idoit\Module\Api\Model\External\Exception;

use Exception;

class EntryException extends Exception
{
}