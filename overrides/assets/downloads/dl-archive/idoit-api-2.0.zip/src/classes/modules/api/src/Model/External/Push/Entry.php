<?php

namespace idoit\Module\Api\Model\External\Push;

use idoit\Module\Cmdb\Component\SyncMerger\Config;
use idoit\Module\Cmdb\Component\SyncMerger\Merger;
use isys_cmdb_dao_category;
use isys_import_handler_cmdb;

class Entry
{
    /**
     * @var int
     */
    protected int $importStatus = 1;

    /**
     * @var array
     */
    protected array $data;

    /**
     * @param int   $importStatus
     * @param array $data
     */
    public function __construct(int $importStatus = 1, array $data = [])
    {
        $this->importStatus = $importStatus;
        $this->data = $data;
    }

    /**
     * @return int
     */
    public function getImportStatus(): int
    {
        return $this->importStatus;
    }

    /**
     * @return array
     */
    public function getData(): array
    {
        return $this->data;
    }
}