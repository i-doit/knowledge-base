<?php

/**
 * i-doit
 *
 * @package    i-doit
 * @subpackage API
 * @author     Selcuk Kekec <skekec@i-doit.de>
 * @version    1.10
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */

namespace idoit\Module\Api\Validation\Property;

/**
 * Class AutoText
 *
 * @package idoit\Module\Api\Validation\Property
 */
class AutoText extends Virtual
{
    /**
     * Use parent validation routine
     */
}
