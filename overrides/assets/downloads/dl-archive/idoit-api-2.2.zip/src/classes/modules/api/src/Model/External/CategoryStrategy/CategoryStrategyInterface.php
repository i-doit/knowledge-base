<?php

namespace idoit\Module\Api\Model\External\CategoryStrategy;

use idoit\Module\Api\Model\External\Handler\CiObject;
use isys_cmdb_dao_category;

interface CategoryStrategyInterface
{
    public function isApplicable(string $strategy): bool;

    public function prepare(isys_cmdb_dao_category $dao, CiObject $ciObject, array $entries): array;
}