<?php
/**
 * i-doit
 *
 * "Relocate-CI" Module language file
 *
 * @package     modules
 * @subpackage  relocate_ci
 * @author      Leonard Fischer <lfischer@i-doit.com>
 * @version     1.0.0
 * @copyright   synetics GmbH
 * @license     http://www.i-doit.com/license
 * @since       i-doit 1.4.7
 */

return [
    'LC__ADDON__API'                                                        => 'API',
    'LC__ADDON__API__AUTH_CONFIGURATION'                                    => 'Configuration',
    'LC__ADDON__API__AUTH_CATEGORIES_ATTRIBUTES'                            => 'Attribute documentation',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION'                               => 'Attribute documentation',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES'                   => 'Attributes',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__DATA_TYPE_READ'   => 'Data type (read)',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__DATA_TYPE_WRITE'  => 'Data type (write)',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__DESCRIPTION'      => 'Description',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__KEY'              => 'Key',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__TITLE'            => 'Title',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__TYPE'             => 'Attribute type',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__CATEGORY_INFORMATION'         => 'Category information',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__CONSTANT'                     => 'Constant',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__EXAMPLE'                      => 'Example',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__EXAMPLES'                     => 'Examples',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__EXAMPLES__READ'               => 'cmdb.category.read (Response)',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__EXAMPLES__WRITE'              => 'cmdb.category.set (Request)',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ID'                           => 'ID',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__LOADING_CATEGORIES'           => 'Loading categories...',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__LOADING_CATEGORY_INFORMATION' => 'Loading category information...',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__MULTIVALUE'                   => 'Multivalue',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__PLEASE_SELECT_A_CATEGORY'     => 'Please select a category',
    'LC__ADDON__API__CONFIGURATION'                                         => 'JSON-RPC API',
    'LC__ADDON__API__CONFIGURATION__API_KEY'                                => 'API-Key',
    'LC__ADDON__API__CONFIGURATION__API_KEY__CREATE_NEW'                    => 'Create new API-Key',
    'LC__ADDON__API__CONFIGURATION__ACTIVE'                                 => 'Activate JSON-RPC API',
    'LC__ADDON__API__CONFIGURATION__FORCE_AUTHENTIFICATION'                 => 'Enforce authentification',
    'LC__ADDON__API__CONFIGURATION__FORCE_AUTHENTIFICATION__DESCRIPTION'    => 'By username and password',
    'LC__ADDON__API__CONFIGURATION__STRIP_HTML'                             => 'Strip HTML tags from description fields',
    'LC__ADDON__API__CONFIGURATION__LOG_LEVEL'                              => 'Log Level',
];
