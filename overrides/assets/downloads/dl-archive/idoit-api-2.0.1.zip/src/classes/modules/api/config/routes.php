<?php

use idoit\Module\Api\Controller\AttributeDocumentationController;
use idoit\Module\Api\Controller\PushIdentifierController;
use Symfony\Component\Routing\Loader\Configurator\RoutingConfigurator;

return function (RoutingConfigurator $routes) {
    $routes->add('push-identifier', '/api/push')
        ->methods(['GET'])
        ->controller([PushIdentifierController::class, 'index']);

    $routes->add('api.get-category-list', '/api/get-category-list')
        ->methods(['GET'])
        ->controller([AttributeDocumentationController::class, 'getCategoryList']);

    $routes->add('api.get-category-definition', '/api/get-category-definition')
        ->methods(['GET'])
        ->controller([AttributeDocumentationController::class, 'getCategoryDefinition']);
};
