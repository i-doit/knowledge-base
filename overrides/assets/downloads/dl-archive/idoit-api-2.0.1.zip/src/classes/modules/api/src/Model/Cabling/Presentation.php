<?php

namespace idoit\Module\Api\Model\Cabling;

class Presentation
{
    /**
     * @var string
     */
    private string $content = '';

    /**
     * @param string $content
     */
    public function __construct(string $content) {
        $this->content = $content;
    }

    /**
     * @return string
     */
    public function flatten()
    {
        return $this->content;
    }
}
