<?php

namespace idoit\Module\Api\Endpoint\v2\Cmdb\External;

use idoit\Api\EndpointDefinition;
use idoit\Api\JsonRpcResponse;
use idoit\Api\Parameter\Parameter;
use idoit\Api\Parameter\RequiredParameter;
use idoit\Module\Api\Endpoint\v2\Cmdb\AbstractCmdbEndpoint;
use idoit\Module\Api\Model\External\Config;
use idoit\Module\Api\Model\External\Logger;
use idoit\Module\Api\Model\External\Push as PushModel;
use idoit\Module\Cmdb\Component\CategoryLogger\CmdbLogger;
use Symfony\Component\HttpFoundation\Request;

/**
 * CMDB category externla push
 *
 * @see       API-484
 * @package   idoit\Api
 * @copyright synetics GmbH
 * @license   http://www.i-doit.com/license
 */
class Push extends AbstractCmdbEndpoint
{
    public function getDefinition(): EndpointDefinition
    {
        return new EndpointDefinition('cmdb.external.push.v2', 'Push an object and its category entries at ones based on your external identifier', [
            new RequiredParameter('extType', Parameter::TYPE_STRING, 'First part of external identifier used to identify the data source',
                fn($e) => is_string($e) && strlen($e) > 0),
            new RequiredParameter('extId', Parameter::TYPE_STRING, 'Second part of external identifier used to identifiy the asset',
                fn($e) => is_string($e) && strlen($e) > 0),
            new RequiredParameter('title', Parameter::TYPE_STRING, 'Object title of asset which should be created if not exist', fn($e) => is_string($e) && strlen($e) > 0),
            new RequiredParameter('class', Parameter::TYPE_STRING, 'Object type of asset which should be created if not exist', fn($e) => is_string($e) && defined($e)),
            new RequiredParameter('data', Parameter::TYPE_ARRAY, 'Category data for asset', fn($e) => is_array($e)),
        ]);
    }

    public function request(Request $request): JsonRpcResponse
    {
        try {
            $config = new Config($request->get('extType'), $request->get('extId'), $request->get('title'), $request->get('class'), $request->get('data'));
            $success = (new PushModel($config))->prepare()
                ->sync();

            CmdbLogger::instance()
                ->writeCmdbLog(defined_or_default('C__LOGBOOK_SOURCE__API_PUSH', 0));

            return new JsonRpcResponse([
                'messages' => Logger::instance()
                    ->getRecords(),
                'success'  => true
            ]);
        } catch (\Exception $e) {
            return new JsonRpcResponse(['messages' => $e->getMessage(), 'success' => false], 400);
        }
    }
}
