<?php
/**
 * Classmap for "packager" generated on 2023-08-29
 */

return array (
  'isys_auth_packager' => 'src/classes/modules/packager/auth/isys_auth_packager.class.php',
  'isys_module_packager' => 'src/classes/modules/packager/isys_module_packager.class.php',
  'isys_module_packager_autoload' => 'src/classes/modules/packager/isys_module_packager_autoload.class.php',
  'isys_module_tpl' => 'src/classes/modules/packager/templates/code/isys_module_tpl.php',
);
