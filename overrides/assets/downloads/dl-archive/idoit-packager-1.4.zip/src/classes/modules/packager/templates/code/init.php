<?php
/**
 * i-doit
 *
 * Add-on <identifier> init.php
 *
 * @package     <identifier> add-on
 * @copyright   <manufacturer>
 * @license     <website>
 */

use idoit\Psr4AutoloaderClass;

if (isys_module_manager::instance()->is_active('<identifier>')) {
    Psr4AutoloaderClass::factory()->addNamespace('idoit\Module\UpperCaseIdentifier', __DIR__ . '/src/');
}
