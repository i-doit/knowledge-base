<?php
/**
 * i-doit
 *
 * "Relocate-CI" Module language file
 *
 * @package     modules
 * @subpackage  relocate_ci
 * @author      Leonard Fischer <lfischer@i-doit.com>
 * @version     1.0.3
 * @copyright   synetics GmbH
 * @license     http://www.i-doit.com/license
 * @since       i-doit 1.5.0
 */

return [
    'LC__MODULE__RELOCATE_CI'                                                           => 'CI-Umzug',
    'LC__MODULE__RELOCATE_CI__RELOCATE_GUI'                                             => 'Objekte umziehen',
    'LC__MODULE__RELOCATE_CI__RELOCATE_GUI_NAVBAR_BUTTON'                               => 'Umzug starten',
    'LC__MODULE__RELOCATE_CI__RELOCATE_GUI_DESCRIPTION'                                 => 'Verwenden Sie Ihre Maus um die gewünschten Objekte vom linken in den rechten Baum zu ziehen. Bei Arbeitsplätzen kann in einem Popup außerdem ausgewählt werden, welche zugewiesenen Objekte mit-umgezogen werden sollen.',
    'LC__MODULE__RELOCATE_CI__RELOCATE_GUI_SELECTION'                                   => 'Verschiebe ausgewähltes Objekt <span class="source"></span><br />nach <span class="destination"></span>.',
    'LC__MODULE__RELOCATE_CI__RELOCATE_GUI_SELECTIONS'                                  => 'Verschiebe ausgewählte Objeke <span class="source"></span><br />nach <span class="destination"></span>.',
    'LC__MODULE__RELOCATE_CI__LOGBOOK_GUI'                                              => 'Logbuch',
    'LC__MODULE__RELOCATE_CI__LOGBOOK_GUI__DETAILS'                                     => 'Details',
    'LC__MODULE__RELOCATE_CI__SELECTION_BROWSER'                                        => 'Auswahl Popup',
    'LC__MODULE__RELOCATE_CI__RESULT'                                                   => 'Ergebnis',
    'LC__MODULE__RELOCATE_CI__RESULT_DETAILLED_INFO'                                    => 'Detaillierte Informationen',
    'LC__MODULE__RELOCATE_CI__SUCCESSFULLY_RELOCATED_OBJECT'                            => 'Das Objekt "%s" wurde erfolgreich umgezogen!',
    'LC__MODULE__RELOCATE_CI__SUCCESSFULLY_RELOCATED_OBJECTS'                           => 'Die Objekte wurden erfolgreich umgezogen!',
    'LC__MODULE__RELOCATE_CI__POPUP_MULTIPLE_TYPES'                                     => 'Verschiedene',
    'LC__MODULE__RELOCATE_CI__POPUP_MULTIPLE_OBJECTS'                                   => 'Mehrere Objekte',
    'LC__MODULE__RELOCATE_CI__POPUP_ALL_OBJECTS_WILL_BE_RELOCATED'                      => 'Es werden alle Objekte umgezogen',
    'LC__MODULE__RELOCATE_CI__POPUP_RELOCATE_BUTTON'                                    => 'Umzug durchführen',
    'LC__MODULE__RELOCATE_CI__POPUP_CLOSE_AND_RELOAD'                                   => 'Popup schließen und Seite neu laden',
    'LC__MODULE__RELOCATE_CI__POPUP_ERROR_OCCURRED'                                     => 'Es ist ein Fehler aufgetreten',
    'LC__MODULE__RELOCATE_CI__LOCATION_LOGICAL'                                         => 'Logisch platziert',
    'LC__MODULE__RELOCATE_CI__LOCATION_PHYSICAL'                                        => 'Physisch platziert',
    'LC__MODULE__RELOCATE_CI__OBJ_DOES_NOT_EXIST'                                       => 'Objekt existiert nicht mehr',
    'LC__MODULE__RELOCATE_CI__INVALID_DATA_GIVEN'                                       => 'Die übergebenen Daten sind im falschen Format!',
    'LC__MODULE__RELOCATE_CI__YOU_ARE_TRYING_TO_MOVE_AN_OBJECT_TO_ITS_CURRENT_LOCATION' => 'Das ausgewählte Objekt befindet sich bereits am ausgewählten Standort!',
    'LC__MODULE__RELOCATE_CI__YOU_CANNOT_MOVE_AN_OBJECT_TO_ITSELF'                      => 'Sie können ein Objekt nicht in sich selbst verschieben!',
    'LC__MODULE__RELOCATE_CI__YOU_CANNOT_MOVE_AN_OBJECT_UNDERNEATH_ITSELF'              => 'Sie können ein Objekt nicht unter sich selbst verschieben - dies würde eine Rekursion verursachen!',
    'LC__MODULE__RELOCATE_CI__YOU_NEED_TO_SELECT_AT_LEAST_TWO_OBJECTS'                  => 'Sie müssen je Baum ein Objekt auswählen!',
    'LC__MODULE__RELOCATE_CI__YOU_ARE_NOT_ALLOWED_TO_OPEN_THE_LOGBOOK'                  => 'Es ist Ihnen nicht erlaubt das Logbuch zu durchsuchen.',
    'LC__MODULE__RELOCATE_CI__YOU_ARE_NOT_ALLOWED_TO_VIEW_THE_RELOCATION_GUI'           => 'Es ist Ihnen nicht erlaubt diese Funktion einzusehen.',
    'LC__MODULE__RELOCATE_CI__YOU_ARE_NOT_ALLOWED_TO_EXECUTE_THE_RELOCATION'            => 'Es ist Ihnen nicht erlaubt Objekte umzuziehen.',
    'LC__MODULE__RELOCATE_CI__LOG__RELOCATING_OBJ_TO_DESTINATION'                       => 'Ziehe Objekt "%s" nach "%s".',
    'LC__MODULE__RELOCATE_CI__LOG__FOUND_CHILDREN_WHICH_SHALL_NOT_BE_RELOCATED'         => 'Es wurden Unterobjekte gefunden, die nicht umziehen sollen... Es wird nach einem <em>Platzhalter</em> Objekt gesucht.',
    'LC__MODULE__RELOCATE_CI__LOG__PARENT_CAN_NOT_INHERIT_DUMMY'                        => 'Das übergeordnete Objekt ("%s") kann kein <em>Platzhalter</em> Arbeitsplatz beinhalten, ein anderer Standort wird gesucht.',
    'LC__MODULE__RELOCATE_CI__LOG__NO_PARENT_FOR_WORKSTATION'                           => 'i-doit konnte keinen Standort finden, der ein <em>Platzhalter</em> Arbeitsplatz beinhalten kann. Es wird unterhalb von "%s" erstellt...',
    'LC__MODULE__RELOCATE_CI__LOG__SEARCHING_FOR_DUMMY'                                 => 'Suche nach einem <em>Platzhalter</em> Arbeitsplatz in "%s"...',
    'LC__MODULE__RELOCATE_CI__LOG__FIND_NEW_PHYSICAL_LOCATION'                          => 'Es wird versucht einen neuen physischen Standort für "%s" zu finden',
    'LC__MODULE__RELOCATE_CI__LOG__ATTEMPTING_RECURSIVE_LOGS'                           => 'Versuche Logbucheinträge in alle positionierten Objekte der %s umgezogenen Objekte zu schreiben.',
    'LC__MODULE__RELOCATE_CI__LOG__WRITING_RECURSIVE_LOG'                               => 'Schreibe Logbucheintrag zu #%s.',
    'LC__MODULE__RELOCATE_CI__LOGBOOK__PHYSICAL_LOCATION_CHANGED'                       => 'Der physische Standort von "%s" wurde auf "%s" gewechselt.',
    'LC__MODULE__RELOCATE_CI__LOGBOOK__LOGICAL_LOCATION_CHANGED'                        => 'Der logische Standort von "%s" wurde auf "%s" gewechselt.',
    'LC__MODULE__RELOCATE_CI__SETTING__RESET_LOGICAL_AFTER_PHYSICAL_RELOCATION'         => 'Nach einem physikalischen Umzug soll der logische Standort entfernt werden.',
    'LC__MODULE__RELOCATE_CI__SETTING__UPDATE_PHYSICAL_AFTER_LOGICAL_RELOCATION'        => 'Nach einem logischen Umzug soll der physische Standort aktualisiert werden.',
    'LC__MODULE__RELOCATE_CI__SETTING__WRITE_LOGBOOK_CHANGES_TO_CHILDREN'               => 'Schreibe Logbucheinträge in alle positionierten Objekte eines umgezogenen Objekts.',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__PARENT_CI_LOCATION_CHANGED'               => 'Das CI wurde zusammen mit dem übergeordneten CI ("%s") nach "%s" verschoben.',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__CI_LOCATION_CHANGED'                      => 'Das CI wurde von "%s" nach "%s" verschoben.',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__PERSON_LOCATION_CHANGED'                  => 'Die Person wurde von "%s" nach "%s" verschoben.',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__PARENT_PERSON_LOCATION_CHANGED'           => 'Das CI wurde mit der übergeordneten Person "%s" von "%s" nach "%s" verschoben.',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__WORKSTATION_LOCATION_CHANGED'             => 'Der Arbeitsplatz wurde von "%s" nach "%s" verschoben.',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__WORKSTATION_COMBINED_CHANGE'              => 'Der Arbeitsplatz wurde von "%s" nach "%s" verschoben.',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__PARENT_WORKSTATION_LOCATION_CHANGED'      => 'Das CI wurde mit dem übergeordneten Arbeitsplatz "%s" von "%s" nach "%s" verschoben.',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__PHYSICAL_LOCATION_CHANGED_IN_CMDB'        => 'Das Objekt wurde physikalisch von "%s" nach "%s" verschoben (CMDB).',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__LOGICAL_LOCATION_CHANGED_IN_CMDB'         => 'Das Objekt wurde logisch von "%s" nach "%s" verschoben (CMDB).',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__PHYSICAL_LOCATION_CHANGED_IN_ADDON'       => 'Das Objekt wurde physikalisch von "%s" nach "%s" verschoben (Add-on).',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__LOGICAL_LOCATION_CHANGED_IN_ADDON'        => 'Das Objekt wurde logisch von "%s" nach "%s" verschoben (Add-on).',
    'LC__MODULE__RELOCATE_CI__PHYSICAL_LOCATION_COULD_NOT_BE_FOUND'                     => 'Es konnte kein Standort zum physikalischen positionieren der untergeordneten Objekte gefunden werden.',
    'LC__LOGBOOK_EVENT__RELOCATE_CI__MOVE_PERSON'                                       => 'Die Person "%s" wurde nach "%s" verschoben.',
    'LC__LOGBOOK_SOURCE__RELOCATE_CI'                                                   => 'CI-Umzug',
    'LC__CATG__RELOCATE_CI'                                                             => 'Umzüge',
    'LC__CATG__VIRTUAL_RELOCATE_CI'                                                     => 'Umzüge',
    'LC__CATG__VIRTUAL_RELOCATE_CI__HEADER'                                             => 'Dokumentierte Umzüge dieses CIs',
    'LC__CATG__VIRTUAL_RELOCATE_CI__NO_LOGS'                                            => 'Es existieren aktuell keine Umzugsspezifischen Logbucheinträge!',
    'LC__CATG__VIRTUAL_RELOCATE_CI__NO_CI_LOGS'                                         => 'Zu diesem CI wurden keine Umzugsspezifischen Logbucheinträge gefunden.',
    'LC__RELOCATE_CI__NICE_LOGBOOK_INFO'                                                => ':time: Objekt ":objName" (Typ ":objType") ist von ":from" nach ":to" umgezogen',
];
