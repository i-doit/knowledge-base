<?php
/**
 * i-doit
 *
 * "Relocate-CI" Module language file
 *
 * @package     modules
 * @subpackage  relocate_ci
 * @author      Leonard Fischer <lfischer@i-doit.com>
 * @version     1.0.3
 * @copyright   synetics GmbH
 * @license     http://www.i-doit.com/license
 * @since       i-doit 1.5.0
 */

return [
    'LC__MODULE__RELOCATE_CI'                                                           => 'Relocate-CI',
    'LC__MODULE__RELOCATE_CI__RELOCATE_GUI'                                             => 'Relocate CIs',
    'LC__MODULE__RELOCATE_CI__RELOCATE_GUI_NAVBAR_BUTTON'                               => 'Start relocation',
    'LC__MODULE__RELOCATE_CI__RELOCATE_GUI_DESCRIPTION'                                 => 'Use your mouse to drag the desired object from the left to the right tree. When relocating workstations or people, you can select which child-objects to relocate inside a popup window.',
    'LC__MODULE__RELOCATE_CI__RELOCATE_GUI_SELECTION'                                   => 'Relocate selected object <span class="source"></span><br />to <span class="destination"></span>.',
    'LC__MODULE__RELOCATE_CI__RELOCATE_GUI_SELECTIONS'                                  => 'Relocate selected objects <span class="source"></span><br />to <span class="destination"></span>.',
    'LC__MODULE__RELOCATE_CI__LOGBOOK_GUI'                                              => 'Logbook',
    'LC__MODULE__RELOCATE_CI__LOGBOOK_GUI__DETAILS'                                     => 'Details',
    'LC__MODULE__RELOCATE_CI__SELECTION_BROWSER'                                        => 'Selection popup',
    'LC__MODULE__RELOCATE_CI__RESULT'                                                   => 'Result',
    'LC__MODULE__RELOCATE_CI__RESULT_DETAILLED_INFO'                                    => 'Detailled information',
    'LC__MODULE__RELOCATE_CI__SUCCESSFULLY_RELOCATED_OBJECT'                            => 'Successfully relocated the object "%s"!',
    'LC__MODULE__RELOCATE_CI__SUCCESSFULLY_RELOCATED_OBJECTS'                           => 'Successfully relocated the objects!',
    'LC__MODULE__RELOCATE_CI__POPUP_MULTIPLE_TYPES'                                     => 'Various',
    'LC__MODULE__RELOCATE_CI__POPUP_MULTIPLE_OBJECTS'                                   => 'Multiple objects',
    'LC__MODULE__RELOCATE_CI__POPUP_ALL_OBJECTS_WILL_BE_RELOCATED'                      => 'All objects will be relocated',
    'LC__MODULE__RELOCATE_CI__POPUP_RELOCATE_BUTTON'                                    => 'Perform relocation',
    'LC__MODULE__RELOCATE_CI__POPUP_CLOSE_AND_RELOAD'                                   => 'Close popup and reload',
    'LC__MODULE__RELOCATE_CI__POPUP_ERROR_OCCURRED'                                     => 'A error occured',
    'LC__MODULE__RELOCATE_CI__LOCATION_LOGICAL'                                         => 'Logically assigned',
    'LC__MODULE__RELOCATE_CI__LOCATION_PHYSICAL'                                        => 'Physically assigned',
    'LC__MODULE__RELOCATE_CI__OBJ_DOES_NOT_EXIST'                                       => 'object no longer exists',
    'LC__MODULE__RELOCATE_CI__INVALID_DATA_GIVEN'                                       => 'The given data has the wrong format!',
    'LC__MODULE__RELOCATE_CI__YOU_ARE_TRYING_TO_MOVE_AN_OBJECT_TO_ITS_CURRENT_LOCATION' => 'The selected object is already located under the chosen location!',
    'LC__MODULE__RELOCATE_CI__YOU_CANNOT_MOVE_AN_OBJECT_TO_ITSELF'                      => 'You can not relocate an object underneath itself!',
    'LC__MODULE__RELOCATE_CI__YOU_CANNOT_MOVE_AN_OBJECT_UNDERNEATH_ITSELF'              => 'You can not relocate an object underneath itself! This would cause a recursion!',
    'LC__MODULE__RELOCATE_CI__YOU_NEED_TO_SELECT_AT_LEAST_TWO_OBJECTS'                  => 'You need to select one object in each tree!',
    'LC__MODULE__RELOCATE_CI__YOU_ARE_NOT_ALLOWED_TO_OPEN_THE_LOGBOOK'                  => 'You are not allowed to view the logbook.',
    'LC__MODULE__RELOCATE_CI__YOU_ARE_NOT_ALLOWED_TO_VIEW_THE_RELOCATION_GUI'           => 'You are not allowed to use the relocation feature.',
    'LC__MODULE__RELOCATE_CI__YOU_ARE_NOT_ALLOWED_TO_EXECUTE_THE_RELOCATION'            => 'You are not allowed to execute the relocation feature.',
    'LC__MODULE__RELOCATE_CI__LOG__RELOCATING_OBJ_TO_DESTINATION'                       => 'Relocating the object "%s" underneath "%s".',
    'LC__MODULE__RELOCATE_CI__LOG__FOUND_CHILDREN_WHICH_SHALL_NOT_BE_RELOCATED'         => 'Found children which shall not be relocated... Looking for a <em>dummy</em> workstation.',
    'LC__MODULE__RELOCATE_CI__LOG__PARENT_CAN_NOT_INHERIT_DUMMY'                        => 'The parent object ("%s") can not inherit a <em>dummy</em> workstation, searching for other destinations.',
    'LC__MODULE__RELOCATE_CI__LOG__NO_PARENT_FOR_WORKSTATION'                           => 'i-doit could not find a fitting location which can inherit a <em>dummy</em> workstation. It will be created at "%s"...',
    'LC__MODULE__RELOCATE_CI__LOG__SEARCHING_FOR_DUMMY'                                 => 'Looking for a <em>dummy</em> workstation in "%s"...',
    'LC__MODULE__RELOCATE_CI__LOG__FIND_NEW_PHYSICAL_LOCATION'                          => 'Trying to find a new physical location for "%s"',
    'LC__MODULE__RELOCATE_CI__LOG__ATTEMPTING_RECURSIVE_LOGS'                           => 'Attempting to write logbook entries in all children of the %s relocated objects.',
    'LC__MODULE__RELOCATE_CI__LOG__WRITING_RECURSIVE_LOG'                               => 'Writing logbook entry to #%s.',
    'LC__MODULE__RELOCATE_CI__LOGBOOK__PHYSICAL_LOCATION_CHANGED'                       => 'The physical location was changed from "%s" to "%s".',
    'LC__MODULE__RELOCATE_CI__LOGBOOK__LOGICAL_LOCATION_CHANGED'                        => 'The logical location was changed from "%s" to "%s".',
    'LC__MODULE__RELOCATE_CI__SETTING__RESET_LOGICAL_AFTER_PHYSICAL_RELOCATION'         => 'Remove the logical location after a object has been relocated physically.',
    'LC__MODULE__RELOCATE_CI__SETTING__UPDATE_PHYSICAL_AFTER_LOGICAL_RELOCATION'        => 'Update the physical location after a object has been relocated logically.',
    'LC__MODULE__RELOCATE_CI__SETTING__WRITE_LOGBOOK_CHANGES_TO_CHILDREN'               => 'Write logbook entries to all children of a relocated object.',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__PARENT_CI_LOCATION_CHANGED'               => 'The CI and its superior CI ("%s") have been moved to "%s".',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__CI_LOCATION_CHANGED'                      => 'The CI has been moved from "%s" to "%s".',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__PERSON_LOCATION_CHANGED'                  => 'The person has been moved from "%s" to "%s".',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__PARENT_PERSON_LOCATION_CHANGED'           => 'The CI and its superior person "%s" have been moved from "%s" to "%s".',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__WORKSTATION_LOCATION_CHANGED'             => 'The workstation has been moved from "%s" to "%s".',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__WORKSTATION_COMBINED_CHANGE'              => 'The workstation has been moved from "%s" to "%s".',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__PARENT_WORKSTATION_LOCATION_CHANGED'      => 'The CI and its superior workstation "%s" have been moved from "%s" to "%s".',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__PHYSICAL_LOCATION_CHANGED_IN_CMDB'        => 'The object has moved physically from "%s" to "%s" (CMDB).',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__LOGICAL_LOCATION_CHANGED_IN_CMDB'         => 'The object has moved logically from "%s" to "%s" (CMDB).',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__PHYSICAL_LOCATION_CHANGED_IN_ADDON'       => 'The object has moved physically from "%s" to "%s" (Add-on).',
    'LC__MODULE__RELOCATE_CI__SIMPLE_LOGBOOK__LOGICAL_LOCATION_CHANGED_IN_ADDON'        => 'The object has moved logically from "%s" to "%s" (Add-on).',
    'LC__MODULE__RELOCATE_CI__PHYSICAL_LOCATION_COULD_NOT_BE_FOUND'                     => 'Could not find a physical location to move the child objects.',
    'LC__LOGBOOK_EVENT__RELOCATE_CI__MOVE_PERSON'                                       => 'The person "%s" has been moved to "%s".',
    'LC__LOGBOOK_SOURCE__RELOCATE_CI'                                                   => 'Relocate-CI',
    'LC__CATG__RELOCATE_CI'                                                             => 'Relocations',
    'LC__CATG__VIRTUAL_RELOCATE_CI'                                                     => 'Relocations',
    'LC__CATG__VIRTUAL_RELOCATE_CI__HEADER'                                             => 'Documented relocations of this CI',
    'LC__CATG__VIRTUAL_RELOCATE_CI__NO_LOGS'                                            => 'No relocation-specific logs could be found!',
    'LC__CATG__VIRTUAL_RELOCATE_CI__NO_CI_LOGS'                                         => 'No relocation-specific information could be found on this CI.',
    'LC__RELOCATE_CI__NICE_LOGBOOK_INFO'                                                => ':time: Object ":objName" (type ":objType") changed location from ":from" to ":to"',
];
