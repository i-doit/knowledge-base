<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\ActionType\IdoitCommand\Argument;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;

interface ArgumentConverter
{
    public function convert(Command $command, InputArgument $argument): ?IdoitCliArgument;

    public function supports(Command $command, InputArgument $argument): bool;
}