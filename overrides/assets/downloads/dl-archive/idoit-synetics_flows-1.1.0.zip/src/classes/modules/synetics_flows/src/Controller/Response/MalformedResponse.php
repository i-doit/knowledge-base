<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Controller\Response;

use idoit\Module\SyneticsFlows\Validation\ValidationMessage;
use Symfony\Component\HttpFoundation\JsonResponse;

class MalformedResponse extends JsonResponse
{
    /**
     * @param ValidationMessage[] $errors
     */
    public function __construct(array $errors)
    {
        parent::__construct(['errors' => $errors], empty($errors) ? 200 : 400);
    }
}