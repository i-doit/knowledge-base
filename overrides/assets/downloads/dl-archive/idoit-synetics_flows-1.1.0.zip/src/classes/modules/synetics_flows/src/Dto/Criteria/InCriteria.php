<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Dto\Criteria;

class InCriteria extends ArrayCriteria
{
    protected const COMPARISON_OPERATOR = '=';
}
