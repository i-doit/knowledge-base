<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Dto\Criteria;

class AndCriteria extends AggregateCriteria
{
    public function getOperator(): string
    {
        return 'AND';
    }
}