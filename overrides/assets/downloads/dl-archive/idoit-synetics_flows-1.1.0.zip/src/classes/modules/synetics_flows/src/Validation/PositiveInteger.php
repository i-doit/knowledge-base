<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Validation;

use Attribute;

#[Attribute(Attribute::TARGET_PROPERTY)]
class PositiveInteger extends Validator
{
    public function validate(mixed $value): array
    {
        if (!$value || $value <= 0) {
            return ['LC__MODULE__SYNETICS_FLOWS__POSITIV_INT'];
        }

        return [];
    }
}
