<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\ExecutionResult;

class CliExecutionResult extends ExecutionResult
{
    public function __construct(private string $output)
    {
    }

    public function getOutput(): string
    {
        return $this->output;
    }

    public function __toString(): string
    {
        return "Command performed";
    }
}