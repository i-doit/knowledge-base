<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\ActionType\IdoitCommand\Option;

class SingleObjectOption extends IdoitCliOption
{
    /**
     * @param string $name
     * @param string $description
     * @param bool $required
     * @param array|null $defaultValue
     */
    public function __construct(string $name, string $description, bool $required, private ?array $defaultValue)
    {
        parent::__construct($name, $description, $required);
    }

    /**
     * @return array|null
     */
    public function getDefaultValue(): ?array
    {
        return $this->defaultValue;
    }
}