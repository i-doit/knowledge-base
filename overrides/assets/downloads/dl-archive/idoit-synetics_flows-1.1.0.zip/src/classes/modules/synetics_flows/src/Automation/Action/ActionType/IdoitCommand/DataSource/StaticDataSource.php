<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\ActionType\IdoitCommand\DataSource;

use idoit\Module\SyneticsFlows\Automation\Action\ActionType\IdoitCommand\Option\SelectOptionValue;

class StaticDataSource implements DataSource
{
    /**
     * @param SelectOptionValue[] $values
     */
    public function __construct(private array $values)
    {
    }

    public function getValues(array $parameters): array
    {
        return $this->values;
    }
}