<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\ActionType\IdoitCommand\Option;

class StringArrayOption extends IdoitCliOption
{
    public function __construct(string $name, string $description, bool $required, private ?array $defaultValue)
    {
        parent::__construct($name, $description, $required);
    }

    public function getDefaultValue(): ?array
    {
        return $this->defaultValue;
    }
}