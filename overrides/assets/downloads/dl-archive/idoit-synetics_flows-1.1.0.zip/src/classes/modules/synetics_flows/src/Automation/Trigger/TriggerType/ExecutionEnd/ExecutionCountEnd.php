<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Trigger\TriggerType\ExecutionEnd;

use idoit\Module\SyneticsFlows\Validation\PositiveInteger;

class ExecutionCountEnd extends ExecutionEnd
{
    public function __construct(
        #[PositiveInteger]
        private ?int $value = null
    )
    {
    }

    public function getValue(): ?int
    {
        return $this->value;
    }
}