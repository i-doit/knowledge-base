<?php

namespace idoit\Module\Api\Model\External\Exception;

use Exception;

class StrategyException extends Exception
{

}