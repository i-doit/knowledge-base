<?php

/**
 * i-doit APi
 *
 * @package    i-doit
 * @subpackage API
 * @author     Dennis Stücken <dstuecken@synetics.de>
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */
class isys_api_model_idoit_logout implements isys_api_model_interface
{

    /**
     * Documentation missing
     *
     * @param array $p_params
     *
     * @return array
     */
    public function read($p_params)
    {
        if (isys_application::instance()->container->get('session')->logout())
        {
            return [
                'message' => 'Logout successful',
                'result'  => true
            ];
        }
        else
        {
            return [
                'message' => 'Logout unsuccessful',
                'result'  => false
            ];
        }
    } // function

    /**
     * Constructor
     */
    public function __construct()
    {

    } // function

    /**
     * Allow logging out after request processing finished
     *
     * @return boolean
     */
    public function allowLogout()
    {
        return false;
    }
} // class
