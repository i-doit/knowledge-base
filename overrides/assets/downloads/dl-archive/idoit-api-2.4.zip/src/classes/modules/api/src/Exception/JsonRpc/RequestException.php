<?php

/**
 * i-doit
 *
 * @package    i-doit
 * @subpackage API
 * @author     Selcuk Kekec <skekec@i-doit.de>
 * @version    1.10
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */

namespace idoit\Module\Api\Exception\JsonRpc;

/**
 * Class RequestException
 *
 * @package idoit\Module\Api\Exception\JsonRpc
 */
class RequestException extends AbstractJsonRpcException
{
    public const CODE = -32600;

    public function getErrorCode(): int
    {
        return self::CODE;
    }

    public function getErrorTopic(): string
    {
        return 'Invalid request';
    }
}
