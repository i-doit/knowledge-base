<?php

/**
 * i-doit
 *
 * @package    i-doit
 * @subpackage API
 * @author     Selcuk Kekec <skekec@i-doit.de>
 * @version    1.10
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */

namespace idoit\Module\Api\Exception\JsonRpc;

/**
 * Class ParseException
 *
 * @package idoit\Module\Api\Exception\JsonRpc
 */
class ParseException extends AbstractJsonRpcException
{
    public const CODE = -32700;

    public function getErrorCode(): int
    {
        return self::CODE;
    }

    public function getErrorTopic(): string
    {
        return 'Parse error';
    }
}
