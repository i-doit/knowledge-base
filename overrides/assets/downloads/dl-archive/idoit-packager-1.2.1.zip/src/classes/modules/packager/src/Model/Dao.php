<?php

namespace idoit\Module\Packager\Model;

use idoit\Model\Dao\Base;

/**
 * Class Dao
 *
 * @package   idoit\Module\Packager\Model
 * @copyright synetics GmbH
 * @license   http://www.i-doit.com/license
 */
class Dao extends Base
{
}
