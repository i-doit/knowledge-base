<?php

/**
 * Class isys_module_packager_autoload
 *
 * @copyright synetics GmbH
 * @license   http://www.i-doit.com/license
 */
class isys_module_packager_autoload extends isys_module_manager_autoload
{
    /**
     * Module specific autoloader.
     *
     * @param string $className
     *
     * @return bool
     */
    public static function init($className)
    {
        $addOnPath = '/src/classes/modules/packager/';
        $classMap = [
            'isys_auth_packager' => 'auth/isys_auth_packager.class.php',
        ];

        if (isset($classMap[$className]) && parent::include_file($addOnPath . $classMap[$className])) {
            isys_cache::keyvalue()->ns('autoload')->set($className, $addOnPath . $classMap[$className]);

            return true;
        }

        return false;
    }
}
