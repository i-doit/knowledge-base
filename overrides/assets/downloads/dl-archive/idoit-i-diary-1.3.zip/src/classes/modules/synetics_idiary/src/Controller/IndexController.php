<?php

namespace idoit\Module\SyneticsIDiary\Controller;

use Exception;
use idoit\Response\IdoitResponse;
use isys_application;
use isys_module_manager;
use isys_module_synetics_idiary;
use Symfony\Component\HttpFoundation\Request;

/**
 * i-diary index controller.
 *
 * @package   api
 * @copyright synetics GmbH
 * @license   http://www.i-doit.com/license
 */
class IndexController
{
    /**
     * @param Request $request
     * @return IdoitResponse
     * @throws Exception
     */
    public function landingPage(Request $request): IdoitResponse
    {
        $app = isys_application::instance();
        $container = $app->container;
        $addonPath = isys_module_synetics_idiary::getPath();
        $addonWwwPath = isys_module_synetics_idiary::getWwwPath();

        // Necessary to fill the breadcrumb.
        if (defined('C__MODULE__SYNETICS_IDIARY') && $container->has('moduleManager')) {
            /** @var isys_module_manager $moduleManager */
            $moduleManager = $container->get('moduleManager');

            $app->module = $moduleManager->load(C__MODULE__SYNETICS_IDIARY);
        }

        $container->get('template')
            ->assign('exeDownloadUrl', $addonWwwPath . 'assets/files/i-diary_1.3.zip')
            ->assign('addonIcon', $addonWwwPath . 'assets/img/icon.svg')
            ->assign('cssPath', $addonPath . 'assets/css/landingpage.css');

        $response = new IdoitResponse($addonPath . 'templates/landingpage.tpl');
        $response->showBreadcrumb(true);
        $response->showNavbar(false);

        return $response;
    }
}
