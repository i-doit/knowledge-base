<?php

use idoit\Module\SyneticsIDiary\Controller\IndexController;
use Symfony\Component\Routing\Loader\Configurator\RoutingConfigurator;

return function (RoutingConfigurator $routes) {
    $routes->add('synetics_idiary.index', '/synetics_idiary')
        ->methods(['GET'])
        ->controller([IndexController::class, 'landingPage']);
};
