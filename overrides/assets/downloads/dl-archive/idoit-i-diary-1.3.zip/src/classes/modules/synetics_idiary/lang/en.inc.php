<?php

/**
 * English translation.
 */
return [
    'LC__IDIARY' => 'i-diary',
    'LC__IDIARY__DESCRIPTION_HEADLINE' => 'Description',
    'LC__IDIARY__DESCRIPTION' => 'i-diary is an application for Microsoft Windows, which works as an add-on for i-doit. With the help of the add-on, system administrators are able to get an overview of the changes that have occurred on the server.<br /><br />This will be possible by using the application “diary” directly on a Windows server, without having to log in to i-doit and search for the information.',
    'LC__IDIARY__INFO' => 'This add-on requires a Windows application for full functionality.',
    'LC__IDIARY__LINKS' => 'You can <a class="link-download" href="%s" target="_blank">download</a> it directly, or find a detailed setup instructions in the <a class="link-external" href="https://kb.i-doit.com/en/i-doit-add-ons/i-diary/index.html" target="_blank">Knowledge base</a>.',
];
