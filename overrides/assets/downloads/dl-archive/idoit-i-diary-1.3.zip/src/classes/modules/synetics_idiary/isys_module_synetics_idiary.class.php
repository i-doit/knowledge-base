<?php

use idoit\AddOn\ActivatableInterface;
use idoit\AddOn\InstallableInterface;
use idoit\AddOn\RoutingAwareInterface;
use isys_cmdb_dao as CmdbDao;
use Symfony\Component\Config\FileLocator;
use Symfony\Component\Routing\Loader\PhpFileLoader;

/**
 * i-doit
 *
 * Add-on synetics_idiary module class.
 *
 * @package   synetics_idiary
 * @copyright synetics
 * @license   https://www.i-doit.com/produkte/add-ons
 */
class isys_module_synetics_idiary extends isys_module implements InstallableInterface, ActivatableInterface, RoutingAwareInterface
{
    // Define, if this module shall be displayed in the named menus.
    const DISPLAY_IN_MAIN_MENU   = true;
    const DISPLAY_IN_SYSTEM_MENU = false;
    const MAIN_MENU_REWRITE_LINK = true;

    /**
     * @return void
     */
    public function start()
    {
    }

    /**
     * Initializes the module.
     *
     * @param isys_module_request $p_req
     */
    public function init(isys_module_request $p_req)
    {
    }

    /**
     * Checks if a add-on is installed.
     *
     * @return int|bool
     */
    public static function isInstalled()
    {
        return isys_module_manager::instance()->is_installed('synetics_idiary');
    }

    /**
     * Basic installation process for all mandators.
     *
     * @param isys_component_database $tenantDatabase
     * @param isys_component_database $systemDatabase
     * @param int                     $moduleId
     * @param string                  $type
     * @param int                     $tenantId
     *
     * @return bool
     * @throws isys_exception_dao
     * @throws isys_exception_database
     */
    public static function install($tenantDatabase, $systemDatabase, $moduleId, $type, $tenantId)
    {
        $dao = CmdbDao::instance($tenantDatabase);

        $categoryConstant = 'C__CATG__CUSTOM_FIELDS_DIARY';
        $objectTypeAssignments = [
            'C__OBJTYPE__CLIENT',
            'C__OBJTYPE__SERVER',
            'C__OBJTYPE__VIRTUAL_SERVER',
            'C__OBJTYPE__GENERIC_TEMPLATE'
        ];

        foreach ($objectTypeAssignments as $objectType) {
            $checkSql = "SELECT isys_obj_type_2_isysgui_catg_custom__id
                    FROM isys_obj_type_2_isysgui_catg_custom
                    INNER JOIN isys_obj_type ON isys_obj_type__id = isys_obj_type_2_isysgui_catg_custom__isys_obj_type__id
                    INNER JOIN isysgui_catg_custom ON isysgui_catg_custom__id = isys_obj_type_2_isysgui_catg_custom__isysgui_catg_custom__id
                    WHERE isys_obj_type__const = '{$objectType}'
                    AND isysgui_catg_custom__const = '{$categoryConstant}'
                    LIMIT 1;";

            // Only do the assignment, if it does not exist yet.
            if (\count($dao->retrieve($checkSql)) === 0) {
                // Retrieve the object type ID.
                $objectTypeId = (int)$dao
                    ->retrieve("SELECT isys_obj_type__id AS id FROM isys_obj_type WHERE isys_obj_type__const = '{$objectType}' LIMIT 1;")
                    ->get_row_value('id');

                if ($objectTypeId === 0) {
                    continue;
                }

                // Retrieve the category ID.
                $customCategoryId = (int)$dao
                    ->retrieve("SELECT isysgui_catg_custom__id AS id FROM isysgui_catg_custom WHERE isysgui_catg_custom__const = '{$categoryConstant}' LIMIT 1;")
                    ->get_row_value('id');

                if ($customCategoryId === 0) {
                    continue;
                }

                $assignSql = "INSERT INTO isys_obj_type_2_isysgui_catg_custom
                        SET isys_obj_type_2_isysgui_catg_custom__isys_obj_type__id = {$objectTypeId},
                        isys_obj_type_2_isysgui_catg_custom__isysgui_catg_custom__id = {$customCategoryId};";

                $dao->update($assignSql) && $dao->apply_update();
            }
        }

        return true;
    }

    /**
     * Uninstall add-on for all mandators.
     *
     * @param isys_component_database $tenantDatabase
     *
     * @return bool
     */
    public static function uninstall($tenantDatabase)
    {
        return true;
    }

    /**
     * Checks if a add-on is active.
     *
     * @return int|bool
     */
    public static function isActive()
    {
        return isys_module_manager::instance()->is_installed('synetics_idiary', true);
    }

    /**
     * Method that is called after clicking "activate" in admin center for specific mandator.
     *
     * @param isys_component_database $tenantDatabase
     *
     * @return bool
     */
    public static function activate($tenantDatabase)
    {
        return true;
    }

    /**
     * Method that is called after clicking "deactivate" in admin center for specific mandator.
     *
     * @param isys_component_database $tenantDatabase
     *
     * @return bool
     */
    public static function deactivate($tenantDatabase)
    {
        return true;
    }

    public static function registerRouting(): void
    {
        isys_application::instance()->container->get('routes')
            ->addCollection((new PhpFileLoader(new FileLocator(__DIR__)))->load('config/routes.php'));
    }
}
