<?php
/**
 * i-doit
 *
 * Add-on idoit_i_diary init.php
 *
 * @package     idoit_i_diary add-on
 * @copyright   idoit
 * @license     
 */

use idoit\Psr4AutoloaderClass;

if (isys_module_manager::instance()->is_active('idoit_i_diary')) {
    Psr4AutoloaderClass::factory()->addNamespace('idoit\Module\Idoit_i_diary', __DIR__ . '/src/');
}
