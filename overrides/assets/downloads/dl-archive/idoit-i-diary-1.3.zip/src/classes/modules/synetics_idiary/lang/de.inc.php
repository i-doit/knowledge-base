<?php

/**
 * German translation.
 */
return [
    'LC__IDIARY' => 'i-diary',
    'LC__IDIARY__DESCRIPTION_HEADLINE' => 'Beschreibung',
    'LC__IDIARY__DESCRIPTION' => 'i-diary ist eine Anwendung für Microsoft Windows und funktioniert als Add-on für i-doit. Mit Hilfe des Add-ons können Systemadministratoren sich einen Überblick über die auf dem Server vorgenommenen Änderungen verschaffen.<br /><br />Dies ist möglich, indem die Anwendung "diary" direkt auf einem Windows-Server genutzt wird – ohne sich in i-doit einloggen oder nach Informationen suchen zu müssen.',
    'LC__IDIARY__INFO' => 'Dieses Add-on benötigt eine Windows-Anwendung für den vollen Funktionsumfang.',
    'LC__IDIARY__LINKS' => 'Sie können sie direkt <a class="link-download" href="%s" target="_blank">herunterladen</a> oder eine ausführliche Einrichtungserklärung in der <a class="link-external" href="https://kb.i-doit.com/de/i-doit-add-ons/i-diary.html" target="_blank">Knowledge base</a> finden.',
];
