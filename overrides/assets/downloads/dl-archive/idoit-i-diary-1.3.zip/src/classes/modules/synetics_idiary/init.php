<?php
/**
 * i-doit
 *
 * @package     synetics_idiary add-on
 * @copyright   synetics
 * @license     https://www.i-doit.com/produkte/add-ons
 */

use idoit\Psr4AutoloaderClass;

if (isys_module_manager::instance()->is_active('synetics_idiary')) {
    Psr4AutoloaderClass::factory()->addNamespace('idoit\Module\SyneticsIDiary', __DIR__ . '/src/');
}
