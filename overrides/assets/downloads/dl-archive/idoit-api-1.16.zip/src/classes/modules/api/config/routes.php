<?php

use idoit\Module\Api\Controller\AttributeDocumentation;
use Symfony\Component\Routing\Loader\Configurator\RoutingConfigurator;

return function (RoutingConfigurator $routes) {
    $routes->add('api.get-category-list', '/api/get-category-list')
        ->methods(['GET'])
        ->controller([AttributeDocumentation::class, 'getCategoryList']);

    $routes->add('api.get-category-definition', '/api/get-category-definition')
        ->methods(['GET'])
        ->controller([AttributeDocumentation::class, 'getCategoryDefinition']);
};
