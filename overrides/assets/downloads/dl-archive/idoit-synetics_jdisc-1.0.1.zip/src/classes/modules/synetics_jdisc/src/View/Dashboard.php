<?php

namespace idoit\Module\SyneticsJdisc\View;

use isys_module_synetics_jdisc;

class Dashboard extends AbstractView
{
    /**
     * @return static
     * @throws \Exception
     */
    public static function factory(): static
    {
        $instance = new static();
        $instance->template->assign('content_title', $instance->language->get('LC__JDISC__TREE__DASHBOARD'));
        return $instance;
    }

    /**
     * @return \Symfony\Component\HttpFoundation\Response
     * @throws \Exception
     */
    public function render(): \Symfony\Component\HttpFoundation\Response
    {
        return self::getResponse()
            ->setTemplate('contentbottomcontent', isys_module_synetics_jdisc::getPath() . 'templates/dashboard.tpl');
    }
}
