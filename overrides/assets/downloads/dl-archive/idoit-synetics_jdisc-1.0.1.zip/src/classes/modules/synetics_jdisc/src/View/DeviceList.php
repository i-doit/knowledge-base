<?php

namespace idoit\Module\SyneticsJdisc\View;

use isys_module_synetics_jdisc;

class DeviceList extends AbstractView
{
    public static function factory(): static
    {
        $instance = new static();
        $instance->template->assign('content_title', $instance->language->get('LC__JDISC__TREE__DEVICE_LIST'));
        return $instance;
    }

    public function render(): \Symfony\Component\HttpFoundation\Response
    {
        return self::getResponse()
            ->setTemplate('contentbottomcontent', isys_module_synetics_jdisc::getPath() . 'templates/device-list.tpl');
    }
}
