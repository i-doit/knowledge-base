<?php

namespace idoit\Module\SyneticsJdisc\Graphql\Type;

class DiscoveryJobReferenceType extends AbstractType implements TypeInterface
{
    /**
     * @return string
     */
    public static function getType(): string
    {
        return parent::$isRequired ? 'DiscoveryJobReference!' : 'DiscoveryJobReference';
    }

    /**
     * @return array
     */
    public function getFormattedValue(): array
    {
        return ['jobId' => $this->getValue()];
    }
}
