<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsJdisc\Enum;

enum SyncStatus: int
{
    case ANY      = -1;
    case UNSYNCED = 0;
    case SYNCED   = 1;
}
