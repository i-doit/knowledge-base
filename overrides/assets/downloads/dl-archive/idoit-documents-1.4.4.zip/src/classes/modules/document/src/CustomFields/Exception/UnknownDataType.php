<?php

namespace idoit\Module\Document\CustomFields\Exception;

class UnknownDataType extends \Exception
{

}
