CKEDITOR.plugins.setLang('idoit', 'en',
    {
        placeholder: {
            placeholder:               'Placeholder',
            mainObjectPlaceholder:     'Master object',
            externalObjectPlaceholder: 'External object',
            reportPlaceholder:         'Report',
            templatePlaceholder:       'Template',
            imagesPlaceholder:         'Images',
            floorplanPlaceholder:      'Floorplan',
            pageBreakPlaceholder:      'Page break',
            /* ------------------------------------------ */
            category:                  'Category: ',
            property:                  'Category property: ',
            entry:                     'Category entry(s): ',
            report:                    'Report: ',
            templateVar:               'Template variable: ',
            /* ------------------------------------------ */
            "first-image":             'First image',
            "all-images":              'All images',
            "last-image":              'Last image'
        }
    }
);