<?php
/**
 * Classmap for "relocate_ci" generated on 2023-08-30
 */

return array (
  'isys_ajax_handler_relocate_ci' => 'src/classes/modules/relocate_ci/handler/ajax/isys_ajax_handler_relocate_ci.class.php',
  'isys_auth_relocate_ci' => 'src/classes/modules/relocate_ci/auth/isys_auth_relocate_ci.class.php',
  'isys_cmdb_dao_category_g_virtual_relocate_ci' => 'src/classes/modules/relocate_ci/cmdb/dao/category/global/isys_cmdb_dao_category_g_virtual_relocate_ci.class.php',
  'isys_cmdb_ui_category_g_virtual_relocate_ci' => 'src/classes/modules/relocate_ci/cmdb/ui/global/isys_cmdb_ui_category_g_virtual_relocate_ci.class.php',
  'isys_module_relocate_ci' => 'src/classes/modules/relocate_ci/isys_module_relocate_ci.class.php',
  'isys_module_relocate_ci_autoload' => 'src/classes/modules/relocate_ci/isys_module_relocate_ci_autoload.class.php',
  'isys_popup_relocate_ci_selection' => 'src/classes/modules/relocate_ci/popup/isys_popup_relocate_ci_selection.class.php',
  'isys_relocate_ci_dao' => 'src/classes/modules/relocate_ci/dao/isys_relocate_ci_dao.class.php',
);
