<?php

use idoit\Module\Cabling\Controller\PreferencesController;
use Symfony\Component\Routing\Loader\Configurator\RoutingConfigurator;

return function (RoutingConfigurator $routes) {
    $routes->add('cabling.save-visualization-preferences', '/cabling/ajax/save-visualization-preferences')
        ->methods(['POST'])
        ->controller([PreferencesController::class, 'save']);
};
