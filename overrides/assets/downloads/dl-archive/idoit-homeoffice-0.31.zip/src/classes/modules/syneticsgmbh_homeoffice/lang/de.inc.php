<?php
/**
 * German language set for the Homeoffice Add-on
 *
 * @name		i-doit Homeoffice Add-on custom language file german
 * @copyright	synetics GmbH
 * @version		1.0
 */

return [
    'Dauer'        	                          	=> 'Dauer',
    'Zeitraum von'                           		=> 'Zeitraum von',
    'Zeitraum bis'                           		=> 'Zeitraum bis',
    'Erreichbarkeit'               			=> 'Erreichbarkeit',
    'Homeoffice Regelung unterzeichnet'                 => 'Homeoffice Regelung unterzeichnet',
    'Homeoffice Zeitraum'                               => 'Homeoffice Zeitraum',
    'Internetzugang'                                    => 'Internetzugang',
    'Ausstattung / Zubehör'                             => 'Ausstattung / Zubehör',
    'Zugriff über'                                      => 'Zugriff über',
    'URL-Intern'                                      	=> 'URL-Intern',
    'URL-Extern'                        		=> 'URL-Extern',
    'VPN-Netzwerk'               			=> 'VPN-Netzwerk',
    'VPN-Authentifizierung'                             => 'VPN-Authentifizierung',
    'Zertifikat'                                   	=> 'Zertifikat',
    'Ja'                                     		=> 'Ja',
    'Nein'                                    		=> 'Nein',
    'Nicht vorhanden'                               	=> 'Nicht vorhanden',
    'Festnetz'                                   	=> 'Festnetz',
    'Mobil'                                   		=> 'Mobil',
    'Keine'                                   		=> 'Keine',
    'Maus'                                   		=> 'Maus',
    'Tastatur'                                   	=> 'Tastatur',
    'Applikationszugriff'                               => 'Applikationszugriff',
    'Homeoffice'                                   	=> 'Homeoffice',
    'Homeoffice-VPN'                                   	=> 'Homeoffice-VPN',
    'Mobile Terms & Conditions'                         => 'Tarifdetails',
    'Mobile phone contract'				=> 'Mobilfunkverträge',
    'Telephone Flatrate / Minutes'			=> 'Telefon Flatrate / Inklusivminuten',    
    'SMS Flat / Texts'					=> 'SMS Flatrate / Frei SMS',    
    'Data volume'					=> 'Datenvolumen',
];
?>