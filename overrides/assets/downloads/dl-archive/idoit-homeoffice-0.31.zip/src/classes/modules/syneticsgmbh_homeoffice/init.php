<?php
/**
 * i-doit
 *
 * Add-on syneticsgmbh_homeoffice init.php
 *
 * @package     syneticsgmbh_homeoffice add-on
 * @copyright   synetics GmbH
 * @license     https://www.i-doit.com
 */

use idoit\Psr4AutoloaderClass;

if (isys_module_manager::instance()->is_active('syneticsgmbh_homeoffice')) {
    Psr4AutoloaderClass::factory()->addNamespace('idoit\Module\Syneticsgmbh_homeoffice', __DIR__ . '/src/');
}
