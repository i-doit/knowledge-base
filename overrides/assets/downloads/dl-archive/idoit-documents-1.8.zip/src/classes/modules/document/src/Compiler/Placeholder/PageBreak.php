<?php

namespace idoit\Module\Document\Compiler\Placeholder;

/**
 * i-doit "Page Break" placeholder compiler.
 *
 * @package     document
 * @author      Leonard Fischer <lfischer@i-doit.com>
 * @copyright   synetics GmbH
 * @license     http://www.i-doit.com/license
 * @since       1.2.1
 */
class PageBreak extends \isys_document_compiler_placeholder
{
    /**
     * Returns the compiled placeholder
     *
     * @return string
     */
    protected function get()
    {
        return '<div class="break-after" pagebreak="true"></div>';
    }

    /**
     * Pre-Compilation.
     *
     * @return mixed
     */
    protected function pre()
    {
        ;
    }

    /**
     * Post-Compilation.
     *
     * @return mixed
     */
    protected function post()
    {
        ;
    }
}
