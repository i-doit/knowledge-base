<?php

use idoit\Module\Document\CustomFields\Repository\CustomFieldsRepository;

/**
 * i-doit
 * Popup class for creating template variable placeholder.
 *
 * @package     i-doit
 * @subpackage  Popups
 * @author      Leonard Fischer <lfischer@i-doit.com>
 * @version     1.0
 * @copyright   synetics GmbH
 * @license     http://www.i-doit.com/license
 */
class isys_popup_document_placeholder_template_vars extends isys_component_popup
{
    /**
     * Handle request
     *
     * @param  isys_module_request $p_modreq
     *
     * @return void
     */
    public function &handle_module_request(isys_module_request $p_modreq)
    {
        $this->template
            ->assign('customFields', (new CustomFieldsRepository)->getCustomFieldsForTemplate($_POST['template_id']))
            ->display(isys_module_document::getPath() . 'templates/popup/placeholder_template_vars.tpl');

        die();
    }
}
