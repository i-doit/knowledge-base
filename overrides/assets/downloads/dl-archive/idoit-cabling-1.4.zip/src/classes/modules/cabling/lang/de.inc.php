<?php
/**
 * i-doit
 *
 * Cabling Add-on language file
 *
 * @package    Modules
 * @subpackage Cabling
 * @author     Leonard Fischer <lfischer@i-doit.com>
 * @copyright  2017 synetics GmbH
 * @version    1.0
 * @license    http://www.i-doit.com/license
 */

return [
    'LC__MODULE__CABLING'                                                 => 'Verkabelungsansicht',
    'LC__MODULE__CABLING__OPEN_IN_ADDON'                                  => 'In der Verkabelungsansicht öffnen',
    'LC__MODULE__CABLING__LOADING_PLEASE_WAIT'                            => 'Lade Verkabelung, bitte warten...',
    'LC__MODULE__CABLING__PLEASE_SELECT_AT_LEAST_ONCE_CONNECTOR'          => 'Bitte wählen Sie mindestens einen Anschluss aus',
    'LC__MODULE__CABLING__CONNECTOR_TYPES_CHANGED'                        => 'Die Anschlussart wurde geändert',
    'LC__MODULE__CABLING__LOGBOOK__CONNECTOR_TYPES_CHANGED'               => 'Die Anschlussart von Anschluss "%s" wurde geändert',
    'LC__MODULE__CABLING__VIS__EXPORT'                                    => 'Export',
    'LC__MODULE__CABLING__VIS__EXPORT_TITLE'                              => 'Verkabelung exportieren',
    'LC__MODULE__CABLING__VIS__EXPORT_TYPE'                               => 'Export Typ',
    'LC__MODULE__CABLING__VIS__EXPORT_TYPE__SVG'                          => 'SVG Grafik',
    'LC__MODULE__CABLING__VIS__EXPORT_TYPE__PNG'                          => 'PNG Grafik',
    'LC__MODULE__CABLING__VIS__EXPORT_TYPE__HTML'                         => 'HTML Datei',
    'LC__MODULE__CABLING__VIS__EXPORT_TYPE__CSV'                          => 'CSV Datei',
    'LC__MODULE__CABLING__VIS__EXPORT_TYPE__PDF'                          => 'PDF Dokument',
    'LC__MODULE__CABLING__VIS__EXPORT_TYPE__GRAPHML'                      => 'GraphML Datei',
    'LC__MODULE__CABLING__VIS__EXPORT_CONNECTORS'                         => 'Zu exportierende Verbindungen',
    'LC__MODULE__CABLING__VIS__EXPORT__NO_OBJECT_SELECTED'                => 'Bitte wählen Sie zunächst ein Objekt aus!',
    'LC__MODULE__CABLING__VIS__EXPORT__ERROR_SVG_NOT_SUPPORTED'           => 'Der SVG-Export steht in Ihrem Browser nicht zur Verfügung.',
    'LC__MODULE__CABLING__VIS__EXPORT__ERROR_BROWSER_MAY_BE_INCOMPATIBLE' => 'Fehler beim exportieren. Eventuell ist Ihr Browser nicht kompatibel.',
    'LC__MODULE__CABLING__VIS__EXPORT__ERROR_VIS_NOT_LOADED'              => 'Konnte nicht exportieren: Die Visualisierung ist nicht geladen.',
    'LC__MODULE__CABLING__VIS__PRINT'                                     => 'Drucken',
    'LC__MODULE__CABLING__VIS__DISPLAY_WIRING'                            => 'Interne Verschaltung darstellen',
    'LC__MODULE__CABLING__VIS__ONLY_DISPLAY_CONNECTED'                    => 'Nur verbundene Anschlüsse darstellen',
    'LC__MODULE__CABLING__VIS__DISPLAY_CABLE_NAMES'                       => 'Kabelnamen darstellen',
    'LC__MODULE__CABLING__VIS__FUNCTION__SET_AS_ROOT'                     => 'Als Root setzen',
    'LC__MODULE__CABLING__VIS__EDIT_CONNECTOR_TYPES'                      => 'Anschlusstypen bearbeiten',
    'LC__MODULE__CABLING__VIS__CHANGE_SELECTED_CONNECTORS_TO'             => 'Alle <strong>:count ausgewählten Anschlüsse</strong> ändern zu:',
    'LC__MODULE__CABLING__VIS__CHANGE_SELECTED_CONNECTORS_CANCEL'         => 'Markierung(en) aufheben',
    'LC__MODULE__CABLING__PDF__CABLING_PATH'                              => 'Verkabelungsstrecke',
    'LC__MODULE__CABLING__PDF__CABLING_PATH_OF'                           => 'Verkabelungsstrecken von %s Objekt "%s"',
    'LC__MODULE__CABLING__PDF__CMDB_STATUS'                               => 'CMDB-Status',
    'LC__MODULE__CABLING__PDF__LOCATION_PATH'                             => 'Standortpfad',
    'LC__MODULE__CABLING__PDF__CONNECTOR_TYPE'                            => 'Anschlusstyp',
    'LC__MODULE__CABLING__PDF__DIRECTION_INPUT'                           => 'Eingang',
    'LC__MODULE__CABLING__PDF__DIRECTION_OUTPUT'                          => 'Ausgang',
    'LC__MODULE__CABLING__AUTH__VISUALIZATION'                            => 'Verkabelungsansicht',
];