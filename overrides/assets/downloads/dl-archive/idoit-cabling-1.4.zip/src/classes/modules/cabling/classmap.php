<?php
/**
 * Classmap for "cabling" generated on 2023-08-25
 */

return array (
  'isys_auth_cabling' => 'src/classes/modules/cabling/src/Auth/isys_auth_cabling.class.php',
  'isys_module_cabling' => 'src/classes/modules/cabling/isys_module_cabling.class.php',
  'isys_module_cabling_autoload' => 'src/classes/modules/cabling/isys_module_cabling_autoload.class.php',
  'isys_module_cabling_install' => 'src/classes/modules/cabling/install/isys_module_cabling_install.class.php',
  'isys_popup_cabling_export' => 'src/classes/modules/cabling/src/Popup/isys_popup_cabling_export.class.php',
);
