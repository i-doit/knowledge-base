<?php
/**
 * i-doit
 *
 * Installer
 * Step 1
 * System check
 *
 * @package    i-doit
 * @subpackage General
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */
?>