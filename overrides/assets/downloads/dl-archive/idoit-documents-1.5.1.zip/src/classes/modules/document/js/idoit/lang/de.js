CKEDITOR.plugins.setLang('idoit', 'de',
    {
        placeholder: {
            placeholder:               'Platzhalter',
            mainObjectPlaceholder:     'Hauptobjekt',
            externalObjectPlaceholder: 'Externes Objekt',
            reportPlaceholder:         'Report',
            templatePlaceholder:       'Template',
            imagesPlaceholder:         'Bilder',
            floorplanPlaceholder:      'Raumplan',
            pageBreakPlaceholder:      'Seitenumbruch',
            /* ------------------------------------------ */
            category:                  'Kategorie: ',
            property:                  'Kategorieeigenschaft: ',
            entry:                     'Kategorieeinträge: ',
            report:                    'Report: ',
            templateVar:               'Templatevariable: ',
            /* ------------------------------------------ */
            "first-image":             'Erstes Bild',
            "all-images":              'Alle Bilder',
            "last-image":              'Letztes Bild'
        }
    }
);