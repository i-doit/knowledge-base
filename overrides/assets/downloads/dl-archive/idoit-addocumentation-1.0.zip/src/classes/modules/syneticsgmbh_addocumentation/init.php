<?php
/**
 * i-doit
 *
 * Add-on syneticsgmbh_addocumentation init.php
 *
 * @package     syneticsgmbh_addocumentation add-on
 * @copyright   synetics GmbH
 * @license     https://i-doit.com
 */

use idoit\Psr4AutoloaderClass;

if (isys_module_manager::instance()->is_active('syneticsgmbh_addocumentation')) {
    Psr4AutoloaderClass::factory()->addNamespace('idoit\Module\Syneticsgmbh_addocumentation', __DIR__ . '/src/');
}
