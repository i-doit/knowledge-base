<?php

namespace idoit\Module\Api\Model\External\Exception;

use Exception;

class CategoryException extends Exception
{

}