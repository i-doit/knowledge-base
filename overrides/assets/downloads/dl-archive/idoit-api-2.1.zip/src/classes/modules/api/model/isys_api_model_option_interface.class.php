<?php

interface isys_api_model_option_interface
{
    /**
     * @return array
     */
    public static function getAllowedOptions(): array;
}
