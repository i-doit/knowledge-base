<?php

/**
 * i-doit
 *
 * @package    i-doit
 * @subpackage API
 * @author     Selcuk Kekec <skekec@i-doit.de>
 * @version    1.10
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */

/**
 * Class isys_model_console_commands
 */
class isys_api_model_console_commands extends isys_api_model_console
{
    /**
     * List commands
     *
     * @param array $params
     *
     * @return array
     * @throws Exception
     */
    public function listCommands(array $params = [])
    {
        return $this->run('list', $params['options'], $params['arguments']);
    }

    /**
     * Help
     *
     * @param array $params
     *
     * @return array
     * @throws Exception
     */
    public function help(array $params = [])
    {
        return $this->run('help', $params['options'], $params['arguments']);
    }
}
