## How to develop with this Add-on

1. Clone the i-doit project into your development workspace with [git clone git@bitbucket.org:synetics/i-doit.git]().
2. Clone this project [git clone git@bitbucket.org:synetics/forms-addon.git]() into your development workspace
3. Go to the i-doit project into the following folder `src/classes/modules` create a symbolic link to the forms add-on project
4. Now you have the add-on in i-doit and you just need to install it. Here a link how to install i-doit [https://kb.i-doit.com/display/en/Installation](https://kb.i-doit.com/display/en/Installation)
5. Go to `react` folder of the add-on and run `npm install` and `npm run build` to build the frontend application
6. During development, you can run `npm start` to rebuild the application on changes in code
