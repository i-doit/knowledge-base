<?php

namespace idoit\Module\Forms\Model\CategoryTypes\Virtual\Ip;

use idoit\Module\Forms\Model\CategoryTypes\Virtual\VirtualCategory;
use isys_cmdb_dao_category_g_ip;

class Ipv6 extends Ip implements VirtualCategory
{
    /**
     * @var string
     */
    protected $categoryTitle = 'LC__MODULE__FORMS__CATEGORY__IPV6';

    /**
     * @var string
     */
    protected $m_category_const = 'C__CATG__IP__IPV6';

    /**
     * @return string[]
     */
    public function getRemovedProperties(): array
    {
        return [
            'ipv4_address',
            'ipv4_assignment',
            'zone'
        ];
    }
}
