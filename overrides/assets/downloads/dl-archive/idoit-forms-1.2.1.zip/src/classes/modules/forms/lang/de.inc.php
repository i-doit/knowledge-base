<?php
/**
 * i-doit
 *
 * "Forms" Module language file
 *
 * @package        Modules
 * @subpackage     Forms
 * @version        0.1
 */

return [
    'LC__LOGBOOK_SOURCE__FORMS'                        => 'Add-on: Forms',
    'LC__MODULE__FORMS'                                => 'Forms',
    'LC__MODULE__FORMS__FORMS'                         => 'Forms',
    'LC__MODULE__FORMS__AUTH__MISSING_FORMS_RIGHT'     => 'Ihnen fehlt das %s Recht für das Forms Add-on. Bitte überprüfen Sie Ihre Rechte',
    'LC__MODULE__FORMS__AUTH__NOT_CONFIGURED'          => 'i-doit kann keine Verbindung zum Server herstellen. Bitte überprüfen Sie Ihre Konfiguration unter Tenant Settings -> Forms Add-on',
    'LC__MODULE__FORMS__CATEGORY__IPV4'                => 'Hostadresse (IPv4)',
    'LC__MODULE__FORMS__CATEGORY__IPV6'                => 'Hostadresse (IPv6)',
    'LC__MODULE__FORMS__NOT_LICENSED'                  => 'Das Forms Add-on ist aktuell nicht lizenziert. Bitte aktualisieren Sie Ihren Lizenzschlüssel.',
    'LC__MODULE__FORMS__SETTINGS_API_URL'              => 'Forms Server',
    'LC__MODULE__FORMS__SETTINGS_API_URL_DESCRIPTION'  => 'URL des Forms-Servers',
    'LC__MODULE__FORMS__SETTINGS_API_NAME'             => 'Benutzername',
    'LC__MODULE__FORMS__SETTINGS_API_NAME_DESCRIPTION' => 'Benutzername zur Autorisierung auf Forms Server',
    'LC__MODULE__FORMS__SETTINGS_API_KEY'              => 'API Schlüssel',
    'LC__MODULE__FORMS__SETTINGS_API_KEY_DESCRIPTION'  => 'API-Schlüssel zur Autorisierung auf Forms Server',
];
