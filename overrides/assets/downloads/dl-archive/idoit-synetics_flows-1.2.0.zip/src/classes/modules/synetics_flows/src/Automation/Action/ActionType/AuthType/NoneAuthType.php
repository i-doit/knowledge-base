<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\ActionType\AuthType;

class NoneAuthType extends AuthType
{
    public function prepareHeaders(): array
    {
        return [];
    }
}