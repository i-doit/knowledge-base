<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Dto;

use idoit\Module\SyneticsFlows\Validation\Required;

class ValueItem extends KeyValueItem
{
    public function __construct(
        ?string $key,
        #[Required]
        private ?string $value,
    )
    {
        parent::__construct($key);
    }

    public function getValue(): ?string
    {
        return $this->value;
    }
}