<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\ActionType\CmdbChange;

use idoit\Module\SyneticsFlows\Validation\Required;

class ObjectIdsScope extends CmdbScope
{
    public function __construct(
        #[Required]
        private array $ids = []
    )
    {
    }

    public function getIds(): array
    {
        return $this->ids;
    }
}