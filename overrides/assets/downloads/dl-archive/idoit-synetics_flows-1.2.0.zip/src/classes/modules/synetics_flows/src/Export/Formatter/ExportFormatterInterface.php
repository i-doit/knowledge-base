<?php

namespace idoit\Module\SyneticsFlows\Export\Formatter;

interface ExportFormatterInterface
{
    /**
     * @param array $automations
     *
     * @return string
     */
    public function format(array $automations): string;

    /**
     * @param string $format
     *
     * @return bool
     */
    public function support(string $format): bool;
}