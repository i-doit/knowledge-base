<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\ActionType\IdoitCommand\Option;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputOption;

interface OptionConverter
{
    public function convert(Command $command, InputOption $option): ?IdoitCliOption;

    public function supports(Command $command, InputOption $option): bool;
}