<?php

namespace idoit\Module\SyneticsFlows\Controller\Response;

use Symfony\Component\HttpFoundation\JsonResponse;

class AttributeDataIdNotFoundResponse extends JsonResponse
{
    /**
     * @param string $id
     */
    public function __construct(string $id)
    {
        parent::__construct(['error' => "{$id} is not valid. Please ensure that it contains the category constant and attribute like for example 'C__CATG__MODEL.manufacturer'."], 404);
    }
}
