<?php

namespace idoit\Module\SyneticsFlows\Controller\Response;

class CiObjectArrayResult extends ArrayResult
{
    public function __construct(
        array $results,
        ?int $total,
        private ?array $groups,
        private ?array $groupsAll,
    )
    {
        parent::__construct($results, $total);
    }

    public function getGroups(): ?array
    {
        return $this->groups;
    }
}
