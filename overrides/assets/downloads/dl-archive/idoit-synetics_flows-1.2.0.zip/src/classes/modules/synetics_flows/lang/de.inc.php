<?php

return [
    'LC__MODULE__SYNETICS_FLOWS__FLOWS'                              => 'Flows',
    'LC__MODULE__SYNETICS_FLOWS__MANAGE_FLOWS'                       => 'Flows verwalten',
    'LC__MODULE__SYNETICS_FLOWS__AUTH__MISSING_SYNETICS_FLOWS_RIGHT' => 'Ihnen fehlt das %s Recht für das Flows Add-on. Bitte überprüfen Sie Ihre Rechte',
    'LC__MODULE__SYNETICS_FLOWS__NOT_LICENSED'                       => 'Das Flows Add-on ist aktuell nicht lizenziert. Bitte aktualisieren Sie Ihren Lizenzschlüssel.',
    // Validation errors.
    'LC__MODULE__SYNETICS_FLOWS__VALUE_REQUIRED'                     => 'Der Wert ist erforderlich.',
    'LC__MODULE__SYNETICS_FLOWS__TRIGGER_REQUIRED'                   => 'Der Trigger ist erforderlich. Füge einen trigger dem Flow hinzu.',
    'LC__MODULE__SYNETICS_FLOWS__ACTION_REQUIRED'                    => 'Die Aktion ist erforderlich. Füge eine Aktion dem Flow hinzu.',
    'LC__MODULE__SYNETICS_FLOWS__ATTRIBUTE_INVALID_ERROR'            => 'Attribut ist nicht gültig. Bitte stellen Sie sicher, dass es die Kategorienkonstante und das Attribut enthält, zum Beispiel \'C__CATG__MODEL.manufacturer\'.',
    // Type specific validation errors
    'LC__MODULE__SYNETICS_FLOWS__INVALID_URL'                        => 'Eine valide URL muss eingegeben werden.',
    'LC__MODULE__SYNETICS_FLOWS__INVALID_EMAIL'                      => 'Eine valide E-Mail-Adresse muss eingegeben werden.',
    'LC__MODULE__SYNETICS_FLOWS__AT_LEAST_ONE_TIME'                  => 'Mindestens eine Zeitspanne muss angegeben werden.',
    'LC__MODULE__SYNETICS_FLOWS__FROM_BEFORE_TO_TIME'                => '"Von" muss vor "bis" liegen.',
    'LC__MODULE__SYNETICS_FLOWS__TO_AFTER_FROM_TIME'                 => '"Bis" muss nach "von" liegen.',
    'LC__MODULE__SYNETICS_FLOWS__START_BEFORE_END_DATE'              => '"Start" muss vor "Ende" liegen.',
    'LC__MODULE__SYNETICS_FLOWS__END_AFTER_START_DATE'               => '"Ende" muss nach "Start" liegen.',
    'LC__MODULE__SYNETICS_FLOWS__BEFORE_TO'                          => 'Der Wert muss vor "bis" liegen.',
    'LC__MODULE__SYNETICS_FLOWS__AFTER_FROM'                         => 'Der Wert muss nach "von" liegen.',
    'LC__MODULE__SYNETICS_FLOWS__VALUE_ON_OF'                        => 'Wert sollte einer der folgenden sein:',
    'LC__MODULE__SYNETICS_FLOWS__POSITIV_INT'                        => 'Wert muss positive Zahl sein',
    'LC__MODULE__SYNETICS_FLOWS__FLOWS_STARTED' => 'Flows %s gestartet',
    'LC__MODULE__SYNETICS_FLOWS__FLOW_STARTED' => 'Flow %s gestartet',
    'LC__MODULE__SYNETICS_FLOWS__FLOW_NOT_STARTED' => 'Flow %s konnte nicht gestartet werden',
    'LC__MODULE__SYNETICS_FLOWS__FLOWS_NOT_STARTED' => 'Flows %s konnten nicht gestartet werden',
    'LC__MODULE__SYNETICS_FLOWS__SHOW_ALL_FLOWS' => 'Alle Flows zeigen',
    'LC__MODULE__SYNETICS_FLOWS__TRIGGER_FLOW' => 'Startet Flow %s',
];
