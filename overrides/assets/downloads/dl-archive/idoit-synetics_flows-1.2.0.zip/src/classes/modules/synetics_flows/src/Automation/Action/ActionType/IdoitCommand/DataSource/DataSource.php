<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\ActionType\IdoitCommand\DataSource;

use idoit\Module\SyneticsFlows\Automation\Action\ActionType\IdoitCommand\Option\SelectOptionValue;

interface DataSource
{
    /**
     * @param array $parameters
     *
     * @return SelectOptionValue[]
     */
    public function getValues(array $parameters): array;
}