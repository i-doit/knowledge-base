<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\ActionType\IdoitCommand\Option\SearchIndex;

use idoit\Module\SyneticsFlows\Automation\Action\ActionType\IdoitCommand\Option\DynamicStringMultiSelectOption;
use Symfony\Component\Console\Input\InputInterface;

class SearchIndexCategoryOption extends DynamicStringMultiSelectOption
{
    public function apply(InputInterface $input, mixed $value): void
    {
        if (is_array($value)) {
            $input->setOption($this->name, $value);
        }
    }
}
