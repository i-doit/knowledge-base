<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Validation;

use Attribute;

#[Attribute(Attribute::TARGET_METHOD)]
class ValidationCallback extends Validator
{
    public function validate(mixed $value): array
    {
        return [];
    }
}