<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Trigger\Condition;

use idoit\Module\SyneticsFlows\Dto\Criteria;
use idoit\Module\SyneticsFlows\Validation\Required;

class CmdbCondition extends Condition
{
    public function __construct(
        #[Required]
        private ?Criteria $criteria = null)
    {
    }

    public function getCriteria(): ?Criteria
    {
        return $this->criteria;
    }
}