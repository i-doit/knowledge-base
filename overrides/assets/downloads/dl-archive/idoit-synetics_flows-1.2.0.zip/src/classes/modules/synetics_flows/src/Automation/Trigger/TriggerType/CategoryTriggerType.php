<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Trigger\TriggerType;

use idoit\Module\SyneticsFlows\Serialization\Discriminator;

#[Discriminator([
    'category-created' => CategoryCreatedTriggerType::class,
    'category-updated' => CategoryAttributeTriggerType::class,
    'entry-ranked' => EntryRankedTriggerType::class,
], 'event')]
abstract class CategoryTriggerType extends TriggerType
{

}