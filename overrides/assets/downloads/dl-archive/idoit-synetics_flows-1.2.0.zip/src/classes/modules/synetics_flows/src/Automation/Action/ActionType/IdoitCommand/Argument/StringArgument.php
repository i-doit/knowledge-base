<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\ActionType\IdoitCommand\Argument;

class StringArgument extends IdoitCliArgument
{
    public function __construct(string $name, string $description, bool $required, private ?string $defaultValue = null)
    {
        parent::__construct($name, $description, $required);
    }

    public function getDefaultValue(): ?string
    {
        return $this->defaultValue;
    }
}