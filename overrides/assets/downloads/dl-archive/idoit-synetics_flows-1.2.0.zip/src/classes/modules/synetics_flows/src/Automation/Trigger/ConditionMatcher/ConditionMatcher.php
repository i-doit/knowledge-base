<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Trigger\ConditionMatcher;

use idoit\Module\SyneticsFlows\Automation\Trigger\Condition\Condition;
use idoit\Module\SyneticsFlows\Automation\Trigger\Invocation\Invocation;

interface ConditionMatcher
{
    public function isMatched(Condition $condition, Invocation $invocation): bool;

    public function supports(Condition $condition, Invocation $invocation): bool;
}