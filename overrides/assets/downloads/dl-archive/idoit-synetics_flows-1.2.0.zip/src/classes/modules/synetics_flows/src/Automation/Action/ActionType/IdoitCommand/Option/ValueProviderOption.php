<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\ActionType\IdoitCommand\Option;

interface ValueProviderOption
{
    public function getValues(array $parameters): array;
}