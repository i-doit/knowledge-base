<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Dto\Criteria;

class NotEqCriteria extends ValueCriteria
{
    protected const COMPARISON_OPERATOR = '!=';
}
