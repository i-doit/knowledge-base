<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Serialization;

trait SerializableTrait
{
    function jsonSerialize(): array
    {
        return Serializer::toJson($this);
    }
}