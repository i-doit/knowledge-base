<?php

namespace idoit\Module\SyneticsFlows\Model\Dto;

class LocationObjectAttributeData extends ObjectAttributeData
{
    public string $type = 'location';

    public function __construct(
        string $id,
        string $title,
        string $objectType,
        protected string $status,
        protected ?string $parentId
    )
    {
        parent::__construct($id, $title, $objectType, $status);
    }

    public function getParentId(): ?string
    {
        return $this->parentId;
    }
}
