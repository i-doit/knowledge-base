<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\ActionType\IdoitCommand\Option;

class BooleanOption extends IdoitCliOption
{
    public function __construct(string $name, string $description, bool $required, private ?bool $defaultValue = null)
    {
        parent::__construct($name, $description, $required);
    }

    public function isDefaultValue(): ?bool
    {
        return $this->defaultValue;
    }
}