<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\ConnectSignal;

class DumpConnect
{
    public function __invoke(): void
    {
        //file_put_contents('/tmp/dump.log', json_encode(func_get_args(), JSON_PRETTY_PRINT) . "\n", FILE_APPEND);
    }
}
