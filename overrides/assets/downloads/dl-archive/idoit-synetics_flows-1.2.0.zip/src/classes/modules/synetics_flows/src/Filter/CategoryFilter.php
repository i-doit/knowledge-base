<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Filter;

use idoit\Module\Multiedit\Component\Filter\CategoryFilter as BaseCategoryFilter;
use idoit\Module\SyneticsFlows\Serialization\StringArrayFormat;

class CategoryFilter extends BaseCategoryFilter
{
    /**
     * @var string[]
     */
    #[StringArrayFormat]
    protected array $objectTypeIds = [];

    public function getObjectTypeIds(): array
    {
        return $this->objectTypeIds;
    }
}
