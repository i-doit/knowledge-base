(function () {
    var $tree_content = $('tree_content');
    
    if ($tree_content) {
        $tree_content.on('cmdbObjectTree:retrieved', function () {
            var $tree_config = $('tree_config'),
                $lorry = $('relocate-ci-lorry');
            
            if (!$lorry && $tree_config) {
                $lorry = new Element('a', {
                    href: window.www_dir + 'relocate_ci',
                    id: 'relocate-ci-lorry',
                    className: 'fr btn btn-secondary mr5 mt5',
                    title: '[{isys type="lang" ident="LC__MODULE__RELOCATE_CI__RELOCATE_GUI"}]',
                    'data-tooltip': 1
                })
                    .update(new Element('img', {
                        src: window.dir_images + 'axialis/transportation/delivery.svg',
                        className: 'greyscale',
                        alt: ''
                    }));
                
                $tree_config.insert({after: $lorry});
            }
        });
        
        $tree_content.fire('cmdbObjectTree:retrieved');
    }
})();
