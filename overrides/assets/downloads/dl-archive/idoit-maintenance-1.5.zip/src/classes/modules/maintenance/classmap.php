<?php
/**
 * Classmap for "maintenance" generated on 2024-05-10
 */

return [
  'idoit\\Module\\Maintenance\\Console\\Command\\MaintenanceNotificationCommand' => 'src/classes/modules/maintenance/src/Console/Command/MaintenanceNotificationCommand.php',
  'isys_ajax_handler_maintenance' => 'src/classes/modules/maintenance/handler/ajax/isys_ajax_handler_maintenance.class.php',
  'isys_cmdb_dao_category_g_virtual_maintenance' => 'src/classes/modules/maintenance/cmdb/dao/isys_cmdb_dao_category_g_virtual_maintenance.class.php',
  'isys_cmdb_ui_category_g_virtual_maintenance' => 'src/classes/modules/maintenance/cmdb/ui/isys_cmdb_ui_category_g_virtual_maintenance.class.php',
  'isys_maintenance_auth' => 'src/classes/modules/maintenance/auth/isys_maintenance_auth.class.php',
  'isys_maintenance_dao' => 'src/classes/modules/maintenance/dao/isys_maintenance_dao.class.php',
  'isys_maintenance_reportview_maintenance_export' => 'src/classes/modules/maintenance/reportview/isys_maintenance_reportview_maintenance_export.class.php',
  'isys_maintenance_reportview_pdf' => 'src/classes/modules/maintenance/reportview/isys_maintenance_reportview_pdf.class.php',
  'isys_module_maintenance' => 'src/classes/modules/maintenance/isys_module_maintenance.class.php',
  'isys_popup_maintenance_finish' => 'src/classes/modules/maintenance/popup/isys_popup_maintenance_finish.class.php',
];
