<?php
/**
 * Classmap for "analytics" generated on 2023-08-22
 */

return array (
  'isys_analytics_dao' => 'src/classes/modules/analytics/dao/isys_analytics_dao.class.php',
  'isys_analytics_dao_dataquality' => 'src/classes/modules/analytics/dao/isys_analytics_dao_dataquality.class.php',
  'isys_analytics_reports' => 'src/classes/modules/analytics/reports/isys_analytics_reports.class.php',
  'isys_analytics_reports_dataquality' => 'src/classes/modules/analytics/reports/isys_analytics_reports_dataquality.class.php',
  'isys_analytics_reports_impact_simulation' => 'src/classes/modules/analytics/reports/isys_analytics_reports_impact_simulation.class.php',
  'isys_analytics_reports_livestatus' => 'src/classes/modules/analytics/reports/isys_analytics_reports_livestatus.class.php',
  'isys_analytics_reports_obj_catalog' => 'src/classes/modules/analytics/reports/isys_analytics_reports_obj_catalog.class.php',
  'isys_analytics_reports_servicecosts' => 'src/classes/modules/analytics/reports/isys_analytics_reports_servicecosts.class.php',
  'isys_api_model_analysis' => 'src/classes/modules/analytics/api/isys_api_model_analysis.class.php',
  'isys_api_model_analysis_dataquality' => 'src/classes/modules/analytics/api/isys_api_model_analysis_dataquality.class.php',
  'isys_auth_analytics' => 'src/classes/modules/analytics/auth/isys_auth_analytics.class.php',
  'isys_module_analytics' => 'src/classes/modules/analytics/isys_module_analytics.class.php',
  'isys_module_analytics_autoload' => 'src/classes/modules/analytics/isys_module_analytics_autoload.class.php',
  'isys_module_analytics_install' => 'src/classes/modules/analytics/install/isys_module_analytics_install.class.php',
  'isys_popup_analytics_dataquality_profiles' => 'src/classes/modules/analytics/popups/isys_popup_analytics_dataquality_profiles.class.php',
  'isys_tree_visitor_analytics' => 'src/classes/modules/analytics/tree_visitor/isys_tree_visitor_analytics.class.php',
  'isys_tree_visitor_level' => 'src/classes/modules/analytics/tree_visitor/isys_tree_visitor_level.class.php',
);
