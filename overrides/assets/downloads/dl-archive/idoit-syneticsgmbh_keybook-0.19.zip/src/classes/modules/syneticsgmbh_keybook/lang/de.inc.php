<?php
/**
 * English language set for the Key book Add-on
 *
 * @name		Key book Add-on 
 * @copyright		synetics GmbH
 * @version		1.0
 */
return [
/** Objekttypen */					
'Keys' 			=>		 'Schlüssel',
/** Kategorien */                    	
'Key issuance'  	=>		'Schlüsselausgabe',
'Number of keys'  	=>		'Anzahl der Schlüssel',
'Keys (owned)'  	=>		'Schlüssel (im Besitz)',
'Access Building/Room'	=>		'Zutritt (Schlüssel)',
'Access (Keys)'		=>		'Zutritt (Schlüssel)',
/** Kategorie Bezeichnungen */
'Key issuance on'  	=>		'Schlüsselausgabe am',
'Key number'  		=>		'Schlüsselnummer',
'Key issuance to'  	=>		'Schlüsselausgabe an',
'Key issued by'  	=>		'Schlüsselausgabe durch',
'Stored Keys'  		=>		'Eingelagerte Schlüssel',
'Access to buildings/rooms'	=>	'Zutritt zu Gebäuden und Räumen',
'Access Building/Room'		=>	'Zutritt (Schlüssel)',	
/** Reports */
'Key management'  	=>		'Schlüsselverwaltung',
'Key book'  		=>		'Schlüsselbuch',
'Var: Received keys'  	=>		'Var: Empfangene Schlüssel',
'Var: Stored keys'  	=>		'Var: Eingelagerte Schlüssel',
'Var: Access to Buildings/Rooms'  =>	'Var: Zutritt zur Infrastruktur',
'This report displays all the keys of the person in the "Received keys" category in the People object type.'	=>		'Dieser Report zeigt im Objekttypen Personen in der Kategorie "Empfangene Schlüssel" alle Schlüssel der Person an.',
];
?>				
