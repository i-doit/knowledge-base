<?php
/**
 * German language set for the Key book Add-on
 *
 * @name		Key book Add-on 
 * @copyright		synetics GmbH
 * @version		1.0
 */
return [
/** Objekttypen */
'Schlüssel' 			=>		'Keys',
'Schlüsselkasten' 			=>	'Key box',
/** Kategorien */                    	
'Schlüsselausgabe'  		=>		'Key issuance',
'Anzahl der Schlüssel'  	=>		'Number of keys',
'Schlüssel (im Besitz)'  	=>		'Keys (owned)',
'Zutritt'		  	=>		'Access Building/Room',
'Zutritt (Schlüssel)'		  	=>	'Access (Keys)',
/** Kategorie Bezeichnungen */
'Schlüsselausgabe am'  		=>		'Key issuance on',
'Schlüsselnummer'  		=>		'Key number',
'Schlüsselausgabe an'  		=>		'Key issuance to',                   	
'Schlüsselausgabe durch'  	=>		'Key issued by',
'Gelagert in'  			=>		'Stored at',
'Eingelagerte Schlüssel'  	=>		'Stored keys',
'Zutritt zu Gebäuden und Räumen'=>		'Access to buildings/rooms',
/** Reports */
'Schlüsselverwaltung'  		=>		'Key management',
'Schlüsselbuch'  		=>		'Key book',
'Var: Empfangene Schlüssel'  	=>		'Var: Received keys',#
'Var: Eingelagerte Schlüssel'  	=>		'Var: Stored keys',
'Var: Zutritt zur Infrastruktur'  	=>	'Var: Access to Buildings/Rooms',
'Dieser Report zeigt im Objekttypen Personen in der Kategorie "Empfangene Schlüssel" alle Schlüssel der Person an.' => 'This report displays all the keys of the person in the "Received keys" category in the People object type.',
];
?>				
