<?php
/**
 * i-doit
 *
 * Add-on syneticsgmbh_keybook init.php
 *
 * @package     syneticsgmbh_keybook add-on
 * @copyright   synetics GmbH
 * @license     https://i-doit.com
 */

use idoit\Psr4AutoloaderClass;

if (isys_module_manager::instance()->is_active('syneticsgmbh_keybook')) {
    Psr4AutoloaderClass::factory()->addNamespace('idoit\Module\Syneticsgmbh_keybook', __DIR__ . '/src/');
}
