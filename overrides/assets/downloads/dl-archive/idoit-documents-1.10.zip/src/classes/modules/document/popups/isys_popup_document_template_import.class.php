<?php

use idoit\Component\Logger;

/**
 * i-doit
 * Popup class for importing document templates.
 *
 * @package     i-doit
 * @subpackage  Popups
 * @author      Leonard Fischer <lfischer@i-doit.com>
 * @version     1.0
 * @copyright   synetics GmbH
 * @license     http://www.i-doit.com/license
 */
class isys_popup_document_template_import extends isys_component_popup
{
    /**
     * Method for handling the popup request.
     *
     * @param   isys_module_request $p_modreq
     *
     * @return  void
     * @author  Leonard Fischer <lfischer@i-doit.com>
     */
    public function &handle_module_request(isys_module_request $p_modreq)
    {
        $this->template
            ->activate_editmode()
            ->assign('chapterID', $_GET['chapterID'])
            ->assign('auth', 1)
            ->assign('loggerIcons', Logger::getLevelIcons())
            ->display(isys_module_document::getPath() . 'templates/popup/template_import.tpl');

        die;
    }
}
