<?php
/**
 * i-doit
 *
 * Add-on syneticsgmbh_idoit init.php
 *
 * @package     syneticsgmbh_idoit add-on
 * @copyright   synetics GmbH
 * @license     
 */

use idoit\Psr4AutoloaderClass;

if (isys_module_manager::instance()->is_active('syneticsgmbh_idoit')) {
    Psr4AutoloaderClass::factory()->addNamespace('idoit\Module\Syneticsgmbh_idoit', __DIR__ . '/src/');
}
