<?php
/**
 * i-doit
 *
 * "Relocate-CI" Module language file
 *
 * @package     modules
 * @subpackage  relocate_ci
 * @author      Leonard Fischer <lfischer@i-doit.com>
 * @version     1.0.0
 * @copyright   synetics GmbH
 * @license     http://www.i-doit.com/license
 * @since       i-doit 1.4.7
 */

return [
    'LC__ADDON__API'                                                        => 'API',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION'                               => 'Attribut Dokumentation',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES'                   => 'Attribute',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__DATA_TYPE_READ'   => 'Datentyp (lesen)',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__DATA_TYPE_WRITE'  => 'Datentyp (schreiben)',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__DESCRIPTION'      => 'Beschreibung',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__KEY'              => 'Key',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__TITLE'            => 'Bezeichnung',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__TYPE'             => 'Attribut-Typ',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__CATEGORY_INFORMATION'         => 'Kategorie-Informationen',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__CONSTANT'                     => 'Konstante',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__EXAMPLE'                      => 'Beispiel',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__EXAMPLES'                     => 'Beispiele',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__EXAMPLES__READ'               => 'cmdb.category.read (Antwort)',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__EXAMPLES__WRITE'              => 'cmdb.category.set (Anfrage)',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ID'                           => 'ID',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__LOADING_CATEGORIES'           => 'Lade Kategorien...',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__LOADING_CATEGORY_INFORMATION' => 'Lade Kategorie-Informationen...',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__MULTIVALUE'                   => 'Multivalue',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__PLEASE_SELECT_A_CATEGORY'     => 'Bitte wählen Sie eine Kategorie',
    'LC__ADDON__API__CONFIGURATION'                                         => 'JSON-RPC API',
    'LC__ADDON__API__CONFIGURATION__API_KEY'                                => 'API-Key',
    'LC__ADDON__API__CONFIGURATION__API_KEY__CREATE_NEW'                    => 'Neuen API-Key erzeugen',
    'LC__ADDON__API__CONFIGURATION__ACTIVE'                                 => 'JSON-RPC API aktivieren',
    'LC__ADDON__API__CONFIGURATION__FORCE_AUTHENTIFICATION'                 => 'Erzwinge Authentifizierung',
    'LC__ADDON__API__CONFIGURATION__FORCE_AUTHENTIFICATION__DESCRIPTION'    => 'Durch Benutzername und Passwort',
    'LC__ADDON__API__CONFIGURATION__STRIP_HTML'                             => 'Entfernen von HTML-Tags aus Beschreibungsfeldern',
    'LC__ADDON__API__CONFIGURATION__LOG_LEVEL'                              => 'Log Level',
];
