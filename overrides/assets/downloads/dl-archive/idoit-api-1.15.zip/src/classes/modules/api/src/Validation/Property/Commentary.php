<?php

/**
 * i-doit
 *
 * @package    i-doit
 * @subpackage API
 * @author     Selcuk Kekec <skekec@i-doit.de>
 * @version    1.10
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */

namespace idoit\Module\Api\Validation\Property;

/**
 * Class Commentary
 *
 * @package idoit\Module\Api\Validation\Property
 */
class Commentary extends TextArea
{

    /**
     * Get maximum string length
     *
     * @return int
     */
    public function getMaximumLength()
    {
        return 65534;
    }
}
