<?php
/**
 * i-doit
 *
 * Add-on gw_gw init.php
 *
 * @package     gw_gw add-on
 * @copyright   GW
 * @license     
 */

use idoit\Psr4AutoloaderClass;

if (isys_module_manager::instance()->is_active('gw_gw')) {
    Psr4AutoloaderClass::factory()->addNamespace('idoit\Module\Gw_gw', __DIR__ . '/src/');
}
