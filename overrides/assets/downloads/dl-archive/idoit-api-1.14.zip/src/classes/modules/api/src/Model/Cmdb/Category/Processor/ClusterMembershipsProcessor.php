<?php

namespace idoit\Module\Api\Model\Cmdb\Category\Processor;

use idoit\Module\Api\Model\Cmdb\Category\Processor\Provider\SyncModifier;

class ClusterMembershipsProcessor extends AbstractCategoryProcessor implements SyncModifier
{

    /**
     * @param array $syncData
     *
     * @return array
     */
    public function modifySyncData(array $syncData) {
        $connected_object = $syncData['properties']['connected_object'][C__DATA__VALUE];
        if (is_array($connected_object) && key_exists(0, $connected_object)) {
            $syncData['properties']['connected_object'][C__DATA__VALUE] = $connected_object[0];
        }
        return $syncData;
    }
}