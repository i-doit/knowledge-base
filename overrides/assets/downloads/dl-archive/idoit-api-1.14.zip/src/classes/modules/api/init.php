<?php
/**
 * i-doit
 *
 * Module initializer
 *
 * @package     API
 * @subpackage  Modules
 * @author      Leonard Fischer <lfischer@i-doit.com>
 * @copyright   synetics GmbH
 * @license     http://www.i-doit.com/license
 */


// Adding the PSR-4 autoloader for category processors
\idoit\Psr4AutoloaderClass::factory()->addNamespace('idoit\Module\Api', __DIR__ . '/src/');


if (include_once('isys_module_api_autoload.class.php')) {
    spl_autoload_register('isys_module_api_autoload::init');
}

// Get component registry
if ($registry = isys_application::instance()->container->get('components.registry')) {
    // Register api provided react components
    $registry->register('idoit.addon.api', 'src/classes/modules/api/react/dist/index.min.js');
}