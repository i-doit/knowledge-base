<?php

/**
 * i-doit
 * Class isys_api_model_console_tenant
 *
 * @package    i-doit
 * @subpackage API
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */
class isys_api_model_console_tenant extends isys_api_model_console
{
    /**
     * List tenants.
     *
     * @param array $params
     *
     * @return array
     * @throws Exception
     */
    public function listTenants(array $params = [])
    {
        return $this->run('tenant-list', $params['options'], $params['arguments']);
    }
}