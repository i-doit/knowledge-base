#!/usr/bin/env php
<?php

use idoit\Console\Command\AbstractCommand;
use idoit\Console\IdoitConsoleApplication;
use idoit\Psr4AutoloaderClass;
use Symfony\Component\EventDispatcher\EventDispatcher;

require __DIR__.'/vendor/autoload.php';

if (file_exists(__DIR__ . "/src/config.inc.php"))
{
    error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT & ~E_WARNING);
    $g_absdir = dirname(__FILE__);

    require __DIR__ . "/src/config.inc.php";
    require __DIR__ . '/src/bootstrap.inc.php';


    try
    {
        $application = new IdoitConsoleApplication();
        $application->useEventDispatcher();

        $application->run();
    }
    catch (Exception $e)
    {
        die($e->getMessage());
    }
}
