#   i-doit

[i-doit](https://i-doit.com) is a software application for IT documentation and a CMDB (Configuration Management Database). This application is very useful to collect all your knowledge about the IT infrastructure you are dealing with.


##  Usage

This is a Web application which runs on a typical LAMP stack (GNU/Linux operating system, Apache Webserver, MariaDB/MySQL, PHP). Please refer to the [i-doit Knowledge Base](https://kb.i-doit.com/display/en/) for both basic and advanced usage.


##  Installation

Based on your environment there are several ways to install i-doit. You find straight-forward guidelines in the i-doit knowledge base. Follow these steps:

*   [Install i-doit](https://kb.i-doit.com/display/en/Installation) based on our [system requirements](https://kb.i-doit.com/display/en/System+Requirements)
*   [Deploy cronjobs](https://kb.i-doit.com/display/en/Cronjobs+Setup)
*   [Add your license (pro only)](https://kb.i-doit.com/display/en/Install+License)
*   [Run backups periodically](https://kb.i-doit.com/display/en/Backup+and+Recovery) (and do not forget to test your recovery routines)
*   [Open i-doit in your Web browser for the first time](https://kb.i-doit.com/display/en/Initial+Login)
*   [Harden your installation for security reasons](https://kb.i-doit.com/display/en/Security+and+Protection)


##  Update

Please [keep your installation up-to-date](https://kb.i-doit.com/display/en/Update) for security updates, bug fixes and – of course – new features.


##  Changelog and Release Notes

Read more about [what has changed in this and previous releases](https://kb.i-doit.com/display/en/Changelogs) in the i-doit Knowledge Base.

Each major release comes with specific [release notes](https://kb.i-doit.com/display/en/Release+Notes) you should read carefully.


##  Configuration

Right after setup it is very vital to design your IT documentation/CMDB so it fits to your needs. There are some useful articles in our Knowledge Base about how to configure i-doit, for example:

*   [Learn more about IT Documentation](https://kb.i-doit.com/display/en/Structure+of+the+IT+Documentation)
*   [Make your own CMDB design](https://kb.i-doit.com/display/en/Assignment+of+Categories+to+Object+Types)
*   [Install add-ons](https://kb.i-doit.com/display/en/Add-ons)
*   [Authenticate against LDAP/Active Directory (AD)](https://kb.i-doit.com/pages/viewpage.action?pageId=37355601)
*   [Use the i-doit API](https://kb.i-doit.com/pages/viewpage.action?pageId=37355644)


##  Support

synetics and its partners provide a wide range of professional services around i-doit. Please check our website [how we can help you](https://www.i-doit.com/en/support/) to build an useful and sustainable IT documentation/CMDB.


##  Contribution

Are you interested in contributing to i-doit? Join our developer program!


##  Useful Resources

*   [Website i-doit pro](https://i-doit.com/)
*   [Website i-doit open](https://i-doit.org/)
*   [i-doit Knowledge Base (English)](https://kb.i-doit.com/display/en/)
*   [i-doit Knowledge Base (German)](https://kb.i-doit.com/display/de/)
*   [i-doit Help Center](https://help.i-doit.com)
*   [i-doit Customer Portal](https://login.i-doit.com)
*   [i-doit Forums](https://forum.i-doit.org/)
*   [i-doit pro Online Demo](https://demo.i-doit.com/)
*   [i-doit open Online Demo](https://demo.i-doit.org/)


##  Copyright and License

Copyright (C) 2017 [synetics GmbH](https://i-doit.com/)

i-doit pro has a [proprietary license](https://www.i-doit.com/en/company/documents/) which you may find on our website.

i-doit open is licensed under the [GNU Affero GPL version 3 or later (AGPLv3+)](https://gnu.org/licenses/agpl.html). This is free software: you are free to change and redistribute it. There is NO WARRANTY, to the extent permitted by law.
