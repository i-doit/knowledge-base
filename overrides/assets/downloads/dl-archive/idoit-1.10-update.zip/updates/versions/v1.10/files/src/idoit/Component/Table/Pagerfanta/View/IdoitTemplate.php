<?php
/**
 * i-doit - Documentation and CMDB solution for IT environments
 *
 * This file is part of the i-doit framework. Modify at your own risk.
 *
 * Please visit http://www.i-doit.com/license for a full copyright and license information.
 *
 * @version     1.10
 * @package     i-doit
 * @author      synetics GmbH
 * @copyright   synetics GmbH
 * @url         http://www.i-doit.com
 * @license     http://www.i-doit.com/license
 */
namespace idoit\Component\Table\Pagerfanta\View;

use Pagerfanta\View\Template\DefaultTemplate;

/**
 * Pagerfanta Template
 *
 * @package     idoit\Component
 * @author      Dennis Stücken <dstuecken@i-doit.com>
 * @copyright   synetics GmbH
 * @license     http://www.i-doit.com/license
 */
class IdoitTemplate extends DefaultTemplate
{
    /**
     * @param $results
     *
     * @return string
     */
    public function results($current, $max)
    {
        return '<span class="results">' . $current . '<span class="separator">/</span>' . $max . '</span>';
    }
}