
## 1.5

### Fixed

-   Fix the configuration of the Text margin