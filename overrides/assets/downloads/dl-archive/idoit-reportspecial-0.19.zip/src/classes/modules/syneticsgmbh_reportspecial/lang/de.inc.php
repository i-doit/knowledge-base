<?php
/**
 * English language set for the Reporting Special Add-on
 *
 * @name		i-doit Reporting Special Add-on custom language file english
 * @copyright	synetics GmbH
 * @version		1.0
 */

return [
'RS: Server: Show all servers that use a specific operating system (e.g. Microsoft Server 2019)' 	=> 'RS: Server: Alle Server anzeigen die ein bestimmtes Betriebssystem (z.B. Microsoft Server 2019) nutzen',                       
'RS: Server: All servers that are part of a network'  							=> 'RS: Server: Alle Server die Teil eines Netzes sind',                           		
'RS: Server: All servers that are part of a service'  							=> 'RS: Server: Alle Server die Teil eines Services sind',                               	
'RS: Server: All servers with an AMD processor'    							=> 'RS: Server: Alle Server mit AMD-Prozessor',               			
'RS: Server: All servers with an AMD processor'   							=> 'RS: Server: Alle Server mit Intel-Prozessor',               	 
'RS: Server: All virtual machines with virtualization host' 						=> 'RS: Server: Alle virtuellen Maschinen mit virtualisierungs Host',
'RS: Server: Software installed on all servers' 							=> 'RS: Server: Installierte Software auf allen Servern',
'RS: Server: Software installed on all servers below a certain location' 				=> 'RS: Server: Installierte Software auf allen Servern unterhalb eines bestimmten Standortes',
'RS: Server: Lists all servers that are in a specific rack' 						=> 'RS: Server: Listet alle Server auf die sich in einem bestimmten Rack befinden',
'RS: Server: Operating system patch level' 								=> 'RS: Server: Patchlevel Betriebssysteme',
'RS: Clients: All clients with a certain memory size' 							=> 'RS: Clients: Alle Clients mit einer bestimmten Arbeitsspeichergr&ouml;&szlig;e',
'RS: Clients: All clients with a specific CPU' 								=> 'RS: Clients: Alle Clients mit einer bestimmten CPU',
'RS: Clients: All clients below a location' 								=> 'RS: Clients: Alle Clients unterhalb eines Standorts',
'RS: Clients: All mobile phones, model, IMEI and users' 						=> 'RS: Clients: Alle Mobiltelefone, Modell, IMEI und Benutzer',
'RS: Clients: Accounting data, guarantee and inventory'  						=> 'RS: Clients: Buchhaltungsdaten, Garantie und Inventar',                      
'RS: Clients: Change management' 									=> 'RS: Clients: Change Management',                              		
'RS: Clients: Client overview' 										=> 'RS: Clients: Client &Uuml;bersicht',
'RS: Clients: Devices + users phone &amp; email' 							=> 'RS: Clients: Ger&auml;te + Benutzer Telefon &amp; E-Mail ',
'RS: Clients: Installed software' 									=> 'RS: Clients: Installierte Software',
'RS: Clients: Logbook' 											=> 'RS: Clients: Logbuch',
'RS: Clients: Technical data' 										=> 'RS: Clients: Technische Daten', 
'RS: Services: Lists all services of a specific person for whom you have been designated as the service manager.' => 'RS: Services: Listet alle Services einer bestimmten Person auf f&uuml;r die Sie als Serviceverantwortlicher (Service Manager) festgelegt wurde.',
'RS: Services: SLA' 											=> 'RS: Services: SLA',
'RS: Services: Overview of all services and their components' 						=> 'RS: Services: Übersicht aller Services und deren Komponenten',                                   
'RS: Services: Overview of the services' 								=> 'RS: Services: Übersicht der Services',                               
'RS: Printer: All printers of a certain model, type, location and status'				=> 'RS: Drucker: Alle Drucker eines bestimmten Modells , Typ, Standort und Status',                                   	
'RS: Printer: All printers with model, type, location and status' 					=> 'RS: Drucker: Alle Drucker mit Modell, Typ, Standort und Status',                       	
'RS: Printer: All printers below one location' 								=> 'RS: Drucker: Alle Drucker unterhalb eines Standorts',
'RS: Monitor: All monitors of a specific model or manufacturer' 					=> 'RS: Monitor: Alle Monitore eines bestimmten Modells oder Herstellers',
'RS: Operating system: Shows all devices that use a specific operating system (variant &amp; version)' 	=> 'RS: Betriebssystem: Zeigt alle Ger&auml;te an die ein bestimmtes Betriebssystem (Variante &amp; Version) nutzen', 
'RS: Licenses: Lists all licenses that expire by a defined date.' 					=> 'RS: Lizenzen: Listet alle Lizenzen auf die bis zu einem definierten Datum ablaufen.',                         
'RS: Licenses: Overview of all used and free licenses' 							=> 'RS: Lizenzen: Übersicht aller verwendeten und freien Lizenzen',                         
'RS: Accounting: All assets that were procured from a particular supplier' 				=> 'RS: Buchhaltung: Alle Assets die bei einem bestimmtem Lieferanten beschafft wurden',                           	
'RS: DHCP: All devices that obtain an IP address via DHCP' 						=> 'RS: DHCP: Alle Ger&auml;te die eine IP-Adresse &uuml;ber DHCP beziehen',                          
'RS: NAS: Capacity and RAID' 										=> 'RS: NAS: Kapazit&auml;t und RAID',
'RS: Network: Overview of all Layer 3 networks' 							=> 'RS: Netzwerk: Übersicht aller Layer-3 Netze',
'RS: Patch field: All patch fields with connections' 							=> 'RS: Patchfeld: Alle Patchfelder mit Verbindungen',                           		
'RS: PDU: All sockets in a building' 									=> 'RS: PDU: Alle Steckdosen eines Geb&auml;udes',                           	
'RS: Staff: All employees who belong to a department' 							=> 'RS: Personal: Alle Mitarbeiter einer Abteilung',                           	
'RS: Staff: All employees with all assigned end devices' 						=> 'RS: Personal: Alle Mitarbeiter mit allen zugewiesenen Endger&auml;ten',
'RS: Rack: Lists all devices on a specific rack' 							=> 'RS: Rack: Listet alle Ger&auml;te auf die sich in einem bestimmten Rack befinden',                           
'RS: Other: All workstations below one location' 							=> 'RS: Sonstige: Alle Arbeitsplatzger&auml;te unterhalb eines Standortes',                           		
'RS: Status: Listet alle Ger&auml;te auf die sich im Status "Bestellt" oder "Geliefert" befinden'  	=> 'RS: Status: Lists all devices that are in the "Ordered" or "Delivered" status',                           
'RS: Status: Lists all devices that are in the "Defective", "Maintenance" or "Out of service" status'  	=> 'RS: Status: Listet alle Ger&auml;te auf die sich im Status "Defekt", "Wartung" oder "Au&szlig;er Betrieb" befinden',  
'RS: Status: Lists all devices that were last changed' 							=> 'RS: Status: Listet alle Ger&auml;te auf die zuletzt ge&auml;ndert wurden',                           		
'RS: Switch: Overview of all switches' 									=> 'RS: Switch: Übersicht aller Switche',                          
'RS: Responsibilities: Lists all devices for which a specific person or organization has been defined as a contractual partner.'  =>  'RS: Verantwortlichkeiten: Alle Ger&auml;te f&uuml;r die eine bestimmte Person als Administrator verantwortlich ist.', 
'RS: Responsibilities: All devices for which a specific person is responsible as an administrator.'   	=> 'RS: Verantwortlichkeiten: Listet alle Ger&auml;te auf f&uuml;r die eine bestimmte Person oder Organisation als Vertragspartner festgelegt wurde.',
'RS: WAP: All wireless access points of a specific model and location'  				=> 'RS: WAP: Alle Wireless Access Points eines bestimmten Modell und Standort',                     	
'RS: WAP: All wireless access points of a specific location' 						=> 'RS: WAP: Alle Wireless Access Points eines bestimmten Standorts', 
'Report Manager Special: Other'                           			=> 'Report Manager Special: Sonstiges', 
'Report Manager Special: Periphery'                           			=> 'Report Manager Special: Peripherie',                          		
];
?>