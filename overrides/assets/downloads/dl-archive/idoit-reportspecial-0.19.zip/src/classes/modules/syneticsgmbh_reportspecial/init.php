<?php
/**
 * i-doit
 *
 * Add-on syneticsgmbh_reportspecial init.php
 *
 * @package     syneticsgmbh_reportspecial add-on
 * @copyright   synetics GmbH
 * @license     https://i-doit.com
 */

use idoit\Psr4AutoloaderClass;

if (isys_module_manager::instance()->is_active('syneticsgmbh_reportspecial')) {
    Psr4AutoloaderClass::factory()->addNamespace('idoit\Module\Syneticsgmbh_reportspecial', __DIR__ . '/src/');
}
