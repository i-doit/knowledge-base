<?php

namespace idoit\Module\Forms\Model;

use idoit\Model\Dao\Base;

class Dao extends Base
{

}