<?php

namespace idoit\Module\Forms\Processor;

use idoit\Module\Forms\Processor;
use isys_cmdb_dao;
use isys_format_json;

/**
 * Class Deactivate
 *
 * @package   idoit\Module\Forms\Processor
 * @copyright synetics
 * @license   
 */
class Deactivate extends Processor
{
    /**
     * @return mixed|void
     * @throws \idoit\Exception\JsonException
     * @throws \isys_exception_dao
     */
    public function process()
    {
        // Do nothing
    }
}
