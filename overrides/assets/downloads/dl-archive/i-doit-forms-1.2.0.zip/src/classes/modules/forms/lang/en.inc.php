<?php
/**
 * i-doit
 *
 * "Forms" Module language file
 *
 * @package        Modules
 * @subpackage     Forms
 * @version        0.1
 */

return [
    'LC__LOGBOOK_SOURCE__FORMS'                        => 'Add-on: Forms',
    'LC__MODULE__FORMS'                                => 'Forms',
    'LC__MODULE__FORMS__FORMS'                         => 'Forms',
    'LC__MODULE__FORMS__AUTH__MISSING_FORMS_RIGHT'     => 'You are missing the %s right for the Forms Add-on. Please, check your rights',
    'LC__MODULE__FORMS__AUTH__NOT_CONFIGURED'          => 'i-doit cannot connect to the Forms Server. Please, check your configuration in Tenant Settings -> Forms Add-on',
    'LC__MODULE__FORMS__CATEGORY__IPV4'                => 'Hostaddress (IPv4)',
    'LC__MODULE__FORMS__CATEGORY__IPV6'                => 'Hostaddress (IPv6)',
    'LC__MODULE__FORMS__NOT_LICENSED'                  => 'Forms add-on is currently not licensed. Please update your license key.',
    'LC__MODULE__FORMS__SETTINGS_API_URL'              => 'Forms Server',
    'LC__MODULE__FORMS__SETTINGS_API_URL_DESCRIPTION'  => 'Url of the Forms Server',
    'LC__MODULE__FORMS__SETTINGS_API_NAME'             => 'User name',
    'LC__MODULE__FORMS__SETTINGS_API_NAME_DESCRIPTION' => 'User name to authorize on Forms Server',
    'LC__MODULE__FORMS__SETTINGS_API_KEY'              => 'API Key',
    'LC__MODULE__FORMS__SETTINGS_API_KEY_DESCRIPTION'  => 'API Key to authorize on Forms Server',
];
