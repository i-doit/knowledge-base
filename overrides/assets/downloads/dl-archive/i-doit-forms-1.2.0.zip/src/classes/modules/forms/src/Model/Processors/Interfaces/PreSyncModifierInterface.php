<?php

namespace idoit\Module\Forms\Model\Processors\Interfaces;

interface PreSyncModifierInterface
{
    /**
     * @param array $data
     * @param int $objectId
     *
     * @return array
     */
    public function preSyncModify(array $data, int $objectId): array;
}
