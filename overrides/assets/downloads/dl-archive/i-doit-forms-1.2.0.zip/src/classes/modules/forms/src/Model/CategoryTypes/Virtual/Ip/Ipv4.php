<?php

namespace idoit\Module\Forms\Model\CategoryTypes\Virtual\Ip;

use idoit\Module\Forms\Model\CategoryTypes\Virtual\VirtualCategory;

class Ipv4 extends Ip implements VirtualCategory
{
    /**
     * @var string
     */
    protected $categoryTitle = 'LC__MODULE__FORMS__CATEGORY__IPV4';

    /**
     * @var string
     */
    protected $m_category_const = 'C__CATG__IP__IPV4';

    /**
     * @return string[]
     */
    public function getRemovedProperties(): array
    {
        return [
            'ipv6_address',
            'ipv6_assignment',
            'ipv6_scope'
        ];
    }
}
