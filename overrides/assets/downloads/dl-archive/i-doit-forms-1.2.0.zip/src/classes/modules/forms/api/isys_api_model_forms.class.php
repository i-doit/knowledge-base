<?php

class isys_api_model_forms extends isys_api_model
{
    /**
     * @param string $p_method
     * @param array  $p_params
     *
     * @return $this|isys_api_model
     */
    public function route($p_method, $p_params)
    {
        assert('is_string($p_method)');
        assert('is_array($p_params)');

        return $this;
    }
}