<?php

namespace idoit\Module\Forms\Processor;

use idoit\Module\Forms\Processor;
use isys_cmdb_dao;

/**
 * Class Activate
 *
 * @package   idoit\Module\Forms\Processor
 * @copyright synetics
 * @license   
 */
class Activate extends Processor
{
    /**
     * @return void
     * @throws \idoit\Exception\JsonException
     * @throws \isys_exception_dao
     */
    public function process()
    {
        // Do nothing
    }
}
