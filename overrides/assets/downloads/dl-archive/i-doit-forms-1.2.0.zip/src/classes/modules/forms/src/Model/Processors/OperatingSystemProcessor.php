<?php

namespace idoit\Module\Forms\Model\Processors;

class OperatingSystemProcessor extends ApplicationProcessor
{
    /**
     * @var string
     */
    protected static $categoryConst = 'C__CATG__OPERATING_SYSTEM';
}
