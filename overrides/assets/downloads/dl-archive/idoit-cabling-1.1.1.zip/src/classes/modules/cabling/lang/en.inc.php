<?php
/**
 * i-doit
 *
 * Cabling Add-on language file
 *
 * @package    Modules
 * @subpackage Cabling
 * @author     Leonard Fischer <lfischer@i-doit.com>
 * @copyright  2017 synetics GmbH
 * @version    1.0
 * @license    http://www.i-doit.com/license
 */

return [
    'LC__MODULE__CABLING'                                                 => 'Cabling view',
    'LC__MODULE__CABLING__OPEN_IN_ADDON'                                  => 'Open in cabling view',
    'LC__MODULE__CABLING__LOADING_PLEASE_WAIT'                            => 'Loading cabling, please wait...',
    'LC__MODULE__CABLING__PLEASE_SELECT_AT_LEAST_ONCE_CONNECTOR'          => 'Please select at least one connector',
    'LC__MODULE__CABLING__CONNECTOR_TYPES_CHANGED'                        => 'The connector type has been changed',
    'LC__MODULE__CABLING__LOGBOOK__CONNECTOR_TYPES_CHANGED'               => 'The connector type from connector "%s" has been changed',
    'LC__MODULE__CABLING__VIS__EXPORT'                                    => 'Export',
    'LC__MODULE__CABLING__VIS__EXPORT_TITLE'                              => 'Export cabling',
    'LC__MODULE__CABLING__VIS__EXPORT_TYPE'                               => 'Export type',
    'LC__MODULE__CABLING__VIS__EXPORT_TYPE__SVG'                          => 'SVG image',
    'LC__MODULE__CABLING__VIS__EXPORT_TYPE__PNG'                          => 'PNG image',
    'LC__MODULE__CABLING__VIS__EXPORT_TYPE__HTML'                         => 'HTML file',
    'LC__MODULE__CABLING__VIS__EXPORT_TYPE__CSV'                          => 'CSV file',
    'LC__MODULE__CABLING__VIS__EXPORT_TYPE__PDF'                          => 'PDF document',
    'LC__MODULE__CABLING__VIS__EXPORT_TYPE__GRAPHML'                      => 'GraphML file',
    'LC__MODULE__CABLING__VIS__EXPORT_CONNECTORS'                         => 'Connectors to be exported',
    'LC__MODULE__CABLING__VIS__EXPORT__NO_OBJECT_SELECTED'                => 'Please select an object first!',
    'LC__MODULE__CABLING__VIS__EXPORT__ERROR_SVG_NOT_SUPPORTED'           => 'The SVG export is not supported by your browser.',
    'LC__MODULE__CABLING__VIS__EXPORT__ERROR_BROWSER_MAY_BE_INCOMPATIBLE' => 'Error while exporting data. Your browser may be incompatible.',
    'LC__MODULE__CABLING__VIS__EXPORT__ERROR_VIS_NOT_LOADED'              => 'Could not export: the visualization has not loaded.',
    'LC__MODULE__CABLING__VIS__PRINT'                                     => 'Print',
    'LC__MODULE__CABLING__VIS__DISPLAY_WIRING'                            => 'Display internal wiring',
    'LC__MODULE__CABLING__VIS__ONLY_DISPLAY_CONNECTED'                    => 'Only display connected connectors',
    'LC__MODULE__CABLING__VIS__DISPLAY_CABLE_NAMES'                       => 'Display cable names',
    'LC__MODULE__CABLING__VIS__FUNCTION__SET_AS_ROOT'                     => 'Set as root',
    'LC__MODULE__CABLING__VIS__EDIT_CONNECTOR_TYPES'                      => 'Edit connector types',
    'LC__MODULE__CABLING__VIS__CHANGE_SELECTED_CONNECTORS_TO'             => 'Change all <strong>:count selected connectors</strong> to:',
    'LC__MODULE__CABLING__VIS__CHANGE_SELECTED_CONNECTORS_CANCEL'         => 'Reset selection(s)',
    'LC__MODULE__CABLING__PDF__CABLING_PATH'                              => 'Cabling path',
    'LC__MODULE__CABLING__PDF__CABLING_PATH_OF'                           => 'Cabling paths of %s object "%s"',
    'LC__MODULE__CABLING__PDF__CMDB_STATUS'                               => 'CMDB-Status',
    'LC__MODULE__CABLING__PDF__LOCATION_PATH'                             => 'Location path',
    'LC__MODULE__CABLING__PDF__CONNECTOR_TYPE'                            => 'Connector type',
    'LC__MODULE__CABLING__PDF__DIRECTION_INPUT'                           => 'Input',
    'LC__MODULE__CABLING__PDF__DIRECTION_OUTPUT'                          => 'Output',
    'LC__MODULE__CABLING__AUTH__VISUALIZATION'                            => 'Cabling view',
];