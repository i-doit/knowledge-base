<?php

/**
 * i-doit
 *
 * Cabling add-on initializer
 *
 * @package     Modules
 * @subpackage  Cabling
 * @author      Leonard Fischer <lfischer@i-doit.com>
 * @version     1.0
 * @copyright   synetics GmbH
 * @license     http://www.i-doit.com/license
 */

if (isys_module_manager::instance()->is_active('cabling')) {
    \idoit\Psr4AutoloaderClass::factory()->addNamespace('idoit\Module\Cabling', __DIR__ . '/src/');

    include_once __DIR__ . '/isys_module_cabling_autoload.class.php';

    spl_autoload_register('isys_module_cabling_autoload::init');
}
