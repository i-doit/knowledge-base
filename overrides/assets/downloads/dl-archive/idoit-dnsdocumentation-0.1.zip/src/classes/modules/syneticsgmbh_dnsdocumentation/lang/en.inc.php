<?php
/**
 * English language set for the DNS add-on
 *
 * @name		i-doit DNS Add-on custom language file english
 * @copyright	synetics GmbH
 * @version		1.0
 */

return [
    'DNS Zone'                                  => 'DNS Zone',
    'DNS Server'                                => 'DNS Server',
    'DNS Records'                               => 'DNS Records',
    'Authoritative Nameservers'               	=> 'Authoritative Nameservers',
    'DNS Server Objekt'                         => 'DNS Server Objects',
    'Rolle'                                     => 'Role',
    'TTL'                                       => 'Time to live',
    'CLASS'                                     => 'Class',
    'TYPE'                                      => 'Type',
    'DATA'                                      => 'Data',
    'Primary Nameserver'                        => 'Primary Nameserver',
    'Administrator E-Mailadresse'               => 'Administrators E-Mailaddress',
    'SERIAL'                                    => 'Serial',
    'REFRESH'                                   => 'Refresh',
    'RETRY'                                     => 'Retry',
    'EXPIRE'                                    => 'Expire',
    'MINIMUM'                                   => 'Minimum',
];
?>