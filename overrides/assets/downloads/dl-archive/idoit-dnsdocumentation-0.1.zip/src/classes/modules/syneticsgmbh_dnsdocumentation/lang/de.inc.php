<?php
/**
 * Deutsches Sprachset für das DNS Add-on
 
 * @name		i-doit DNS Add-on custom language file german
 * @copyright	synetics GmbH
 * @version		1.0
 */

return [
    'DNS Zone'                                  => 'DNS Zone',
    'DNS Server'                                => 'DNS Server',
    'DNS Records'                               => 'DNS Records',
    'Authoritative Nameservers'               	=> 'Autorisierende Namensserver',
    'DNS Server Objekt'                         => 'DNS Server Objekt',
    'Rolle'                                     => 'Rolle',
    'TTL'                                       => 'Time to live',
    'CLASS'                                     => 'Class',
    'TYPE'                                      => 'Type',
    'DATA'                                      => 'Data',
    'Primary Nameserver'                        => 'Primärer Namensserver',
    'Administrator E-Mailadresse'               => 'Administrator E-Mailadresse',
    'SERIAL'                                    => 'Serial',
    'REFRESH'                                   => 'Refresh',
    'RETRY'                                     => 'Retry',
    'EXPIRE'                                    => 'Expire',
    'MINIMUM'                                   => 'Minimum',
];
?>