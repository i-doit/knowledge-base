<?php
/**
 * init.php
 *
 * @copyright synetics GmbH
 * @license   http://www.i-doit.com/license
 */

use idoit\Psr4AutoloaderClass;

if (isys_module_manager::instance()->is_active('packager')) {
    Psr4AutoloaderClass::factory()->addNamespace('idoit\Module\Packager', __DIR__ . '/src/');

    include_once __DIR__ . '/isys_module_packager_autoload.class.php';

    spl_autoload_register('isys_module_packager_autoload::init');
}
