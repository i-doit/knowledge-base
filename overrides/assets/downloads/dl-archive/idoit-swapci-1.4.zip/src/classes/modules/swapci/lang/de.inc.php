<?php
/**
 * i-doit
 *
 * "Swap CI" Module language file
 *
 * @package        swapci
 * @subpackage     Language
 * @author         Leonard Fischer <lfischer@i-doit.com>
 * @copyright      2016 synetics GmbH
 * @version        1.2.3
 * @license        http://www.i-doit.com/license
 */

return [
    'LC__MODULE__SWAPCI'                                                   => 'Gerätetausch',
    'LC__MODULE__SWAPCI_EXCEPTION__MISSING_OBJ'                            => 'Bitte wählen Sie zwei Objekte aus, die miteinander getauscht werden sollen.',
    'LC__MODULE__SWAPCI_EXCEPTION__UNKNOWN_OBJ_TYPE'                       => 'Der übergebene Objekt-Typ ist unbekannt: "%s".',
    'LC__MODULE__SWAPCI_LOGBOOK__PURGED_BY_SWAPCI'                         => '%s Datensätze wurden durch "Gerätetausch" entfernt.',
    'LC__MODULE__SWAPCI_LOGBOOK__CMDB_STATUS_SWAPPED_BY_SWAPCI'            => 'CMDB-Status wurde durch "Gerätetausch" auf "%s" gesetzt.',
    'LC__MODULE__SWAPCI_LOGBOOK__OBJECT_SWAPPED_WITH_OBJECT'               => 'Das Objekt "%s" wurde durch "Gerätetausch" mit "%s" getauscht.',
    'LC__MODULE__SWAPCI_LOGBOOK__SWAPPED_BY_SWAPCI'                        => '%s Datensätze wurden durch "Gerätetausch" von Objekt "%s" (#%d) getausch.',
    'LC__MODULE__SWAPCI_LOGBOOK__SWAPPED_AWAY_BY_SWAPCI'                   => '%s Datensätze wurden durch "Gerätetausch" nach Objekt "%s" (#%d) getausch.',
    'LC__MODULE__SWAPCI_LOGBOOK__SWAPPED_SYSID_BY_SWAPCI'                  => 'Die SYS-ID wurde durch den "Gerätetausch" mit Objekt "%s" (#%d) getausch.',
    'LC__MODULE__SWAPCI_LOGBOOK__NEW_SYSID_BY_SWAPCI'                      => 'Diesem Objekt wurde durch den "Gerätetausch" eine neue SYS-ID zugewiesen.',
    'LC__MODULE__SWAPCI_RELATION__SWAPPED_BY_SWAPCI'                       => 'Beziehung wurde durch "Gerätetausch" von Objekt "%s" (#%d) nach Objekt "%s" (#%d) getausch.',
    'LC__MODULE__SWAPCI__CONFIG'                                           => 'Konfiguration',
    'LC__MODULE__SWAPCI__CONFIG_TITLE'                                     => 'Gerätetausch konfiguration',
    'LC__MODULE__SWAPCI__CONFIG_AVAILAVLE_OBJ_TYPES'                       => 'Auswählbare Objekt-Typen',
    'LC__MODULE__SWAPCI__CONFIG_AVAILAVLE_OBJ_TYPES_DESCRIPTION'           => 'Hier können Sie auswählen welche Objekt-Typen im Gerätetausch verfügbar sein sollen und welche Kategorien standardmäßig ausgewählt sind.',
    'LC__MODULE__SWAPCI__CONFIG_CONSIDER_STATUS'                           => '"Tausch" Status berücksichtigen?',
    'LC__MODULE__SWAPCI__CONFIG_CONSIDER_STATUS_DESCRIPTION'               => 'Das getauschte Gerät erhält den Status "Getauscht", das Tauschgerät bekommt "In Betrieb"',
    'LC__MODULE__SWAPCI__CONFIG_STORE_STATUS'                              => 'CMDB Status für Tauschgeräte',
    'LC__MODULE__SWAPCI__CONFIG_STORE_STATUS_DESCRIPTION'                  => 'Es werden nur Tauschgeräte mit dem folgenden CMDB Status angeboten',
    'LC__MODULE__SWAPCI__CONFIG_ARCHIVE_SWAPPED_OBJ'                       => 'Getauschte Geräte archivieren?',
    'LC__MODULE__SWAPCI__CONFIG_KEEP_SWAPPED_CATS_DATA'                    => 'Kategoriedaten getauschter Objekte beibehalten?',
    'LC__MODULE__SWAPCI__CONFIG_SWAP_SYSID'                                => 'SYS-ID ebenfalls tauschen?',
    'LC__MODULE__SWAPCI__GUI'                                              => 'Objekte tauschen',
    'LC__MODULE__SWAPCI__GUI_TITLE'                                        => 'Willkommen im "Gerätetausch" Modul',
    'LC__MODULE__SWAPCI__GUI_ERROR_OBJECTS_ARE_IDENTICAL'                  => 'Achtung! Das Tausch- und Lager-Objekt ist das gleiche.',
    'LC__MODULE__SWAPCI__GUI_ERROR_OBJ_TYPE_MISMATCH'                      => 'Achtung! Die beiden ausgewählten Objekte entsprechen NICHT dem gleichen Typ.',
    'LC__MODULE__SWAPCI__GUI_OBJECT_TO_SWAP'                               => 'Zu tauschendes Objekt',
    'LC__MODULE__SWAPCI__GUI_STORED_OBJECT'                                => 'Lagerndes Objekt',
    'LC__MODULE__SWAPCI__GUI_START_SWAPPING'                               => 'Gerätetausch starten',
    'LC__MODULE__SWAPCI__GUI_CATEGORIES_TO_SWAP'                           => 'Zu übernehmende Kategorien',
    'LC__MODULE__SWAPCI__GUI_CATEGORIES_TO_SWAP_DESCRIPTION'               => 'Aus dem zu tauschenden Objekt sollen folgende Kategorien übernommen werden (Alle anderen Kategorieinhalte werden aus dem neuen Objekt beigesteuert).',
    'LC__MODULE__SWAPCI__GUI_DEBUG_MESSAGES'                               => 'Debug meldungen',
    'LC__MODULE__SWAPCI__GUI_CHANGE_OBJECTS'                               => 'Umstellen',
    'LC__MODULE__SWAPCI__GUI_FINISHED'                                     => 'Der Tausch wurde vollzogen! Für mehr Informationen bitte den Log öffnen',
    'LC__MODULE__SWAPCI__GUI_FINISHED_WITH_ERROR'                          => 'Der Tauschvorgang hat einen Fehler verursacht - Bitte den Log prüfen!',
    'LC__MODULE__SWAPCI__GUI_BY_WORKPLACE'                                 => 'Tausch nach Arbeitsplatzsystemen',
    'LC__MODULE__SWAPCI__GUI_BY_WORKPLACE__OBJ_TYPE_SELECTION'             => 'Objekt-Typ auswahl',
    'LC__MODULE__SWAPCI__GUI_BY_WORKPLACE__TREE_TITLE'                     => 'Arbeitsplätze, die Objekte vom Typ "<span>-</span>" beinhalten',
    'LC__MODULE__SWAPCI__GUI_BY_WORKPLACE__SWAP_BUTTON'                    => 'Ausgewählte Objekte tauschen',
    'LC__MODULE__SWAPCI__GUI_BY_WORKPLACE__TOGGLE_TREE'                    => 'Arbeitsplätze auf- / zuklappen',
    'LC__MODULE__SWAPCI__REPORT'                                           => 'Tausch-Report',
    'LC__MODULE__SWAPCI__REPORT_DESCRIPTION'                               => 'This report displays all swapped objects.',
    'LC__MODULE__SWAPCI__REPORT_TITLE'                                     => 'Gerätetausch Report View',
    'LC__MODULE__SWAPCI__REPORT_NO_OBJECTS'                                => 'Keine getauschten Objekte.',
    'LC__MODULE__SWAPCI__REPORT_DATETIME'                                  => 'Datum und Uhrzeit',
    'LC__MODULE__SWAPCI__REPORT_OLD_OBJECT_NAME'                           => 'Ausgetauschtes Gerät',
    'LC__MODULE__SWAPCI__REPORT_NEW_OBJECT_NAME'                           => 'Neu verbautes Gerät',
    'LC__MODULE__SWAPCI__REPORT_OBJ_TYPE'                                  => 'Objekt Typ',
    'LC__MODULE__SWAPCI__REPORT_LOG'                                       => 'Log',
    'LC__MODULE__SWAPCI__REPORT_PERSON'                                    => 'Person',
    'LC__MODULE__SWAPCI__REPORT_SHOW_LOG'                                  => 'Log öffnen',
    'LC__MODULE__SWAPCI__REPORT_HIDE_LOG'                                  => 'Log schließen',
    'LC__MODULE__SWAPCI__REPORT_OBJECT_NO_LONGER_EXISTS'                   => 'Objekt existiert nicht mehr',
    'LC__CMDB_STATUS__SWAPPED'                                             => 'Ausgetauscht',
    'LC__MODULE__SWAPCI__NAVBAR__SWAP'                                     => 'Tauschen',
    'LC__MODULE__SWAPCI__NAVBAR__SWAP_OBJECTS_TOOLTIP'                     => 'Tauscht die markierten Objekte',
    'LC__MODULE__SWAPCI__NAVBAR__SWAP_OBJECT_TOOLTIP'                      => 'Tauscht das aktuelle Objekt',
    'LC__AUTH_GUI__SWAP_GUI'                                               => 'Objekte tauschen',
    'LC__AUTH_GUI__SWAP_GUI_BY_WORKPLACE'                                  => 'Tausch nach Arbeitsplatzsystem',
    'LC__AUTH_GUI__SWAP_CONFIG'                                            => 'Gerätetausch Konfiguration',
    'LC__AUTH_GUI__SWAP_IN_LIST'                                           => 'Gerätetausch-Knopf in Objektliste',
    'LC__AUTH_GUI__SWAP_IN_OBJ'                                            => 'Gerätetausch-Knopf in Objekten',
    'LC__AUTH__SWAPCI_EXCEPTION__MISSING_RIGHT_FOR_SWAP_GUI'               => 'Es ist Ihnen nicht erlaubt die "%s" Aktion in der Gerätetausch Oberfläche auszuführen.',
    'LC__AUTH__SWAPCI_EXCEPTION__MISSING_RIGHT_FOR_SWAP_GUI_BY_WORKPLACES' => 'Es ist Ihnen nicht erlaubt die "%s" Aktion in der Gerätetausch Oberfläche für Arbeitsplätze auszuführen.',
    'LC__AUTH__SWAPCI_EXCEPTION__MISSING_RIGHT_FOR_SWAP_CONFIG'            => 'Es ist Ihnen nicht erlaubt die "%s" Aktion in der Gerätetausch Konfiguration auszuführen.',
    'LC__AUTH__SWAPCI_EXCEPTION__MISSING_RIGHT_FOR_SWAP_BUTTON'            => 'Es ist Ihnen nicht erlaubt den "Tauschen" Button zu benutzen.',
];