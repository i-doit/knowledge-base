<?php
/**
 * i-doit
 *
 * "Swap CI" Module language file
 *
 * @package        swapci
 * @subpackage     Language
 * @author         Leonard Fischer <lfischer@i-doit.com>
 * @copyright      2016 synetics GmbH
 * @version        1.2.3
 * @license        http://www.i-doit.com/license
 */

return [
    'LC__MODULE__SWAPCI'                                                   => 'Replacement',
    'LC__MODULE__SWAPCI_EXCEPTION__MISSING_OBJ'                            => 'Please choose two objects which shall be swapped.',
    'LC__MODULE__SWAPCI_EXCEPTION__UNKNOWN_OBJ_TYPE'                       => 'The given objekt-type is unknown: "%s".',
    'LC__MODULE__SWAPCI_LOGBOOK__PURGED_BY_SWAPCI'                         => '%s rows were purged by "Swap objects" module.',
    'LC__MODULE__SWAPCI_LOGBOOK__CMDB_STATUS_SWAPPED_BY_SWAPCI'            => 'CMDB-Status has been changed to "%s" by "Swap objects".',
    'LC__MODULE__SWAPCI_LOGBOOK__OBJECT_SWAPPED_WITH_OBJECT'               => 'The object "%s" has been swappeb by "Swap objects" with "%s".',
    'LC__MODULE__SWAPCI_LOGBOOK__SWAPPED_BY_SWAPCI'                        => '%s rows were swapped by "Swap objects" module from object "%s" (#%d).',
    'LC__MODULE__SWAPCI_LOGBOOK__SWAPPED_AWAY_BY_SWAPCI'                   => '%s rows were swapped by "Swap objects" module to object "%s" (#%d).',
    'LC__MODULE__SWAPCI_LOGBOOK__SWAPPED_SYSID_BY_SWAPCI'                  => 'The SYS-ID was swapped with object "%s" (#%d) by the "Swap objects" module.',
    'LC__MODULE__SWAPCI_LOGBOOK__NEW_SYSID_BY_SWAPCI'                      => 'The "Swap objects" module assigned a new SYS-ID to this object.',
    'LC__MODULE__SWAPCI_RELATION__SWAPPED_BY_SWAPCI'                       => 'Relation was swapped from object "%s" (#%d) to object "%s" (#%d) by "Swap objects" module.',
    'LC__MODULE__SWAPCI__CONFIG'                                           => 'Configuration',
    'LC__MODULE__SWAPCI__CONFIG_TITLE'                                     => 'Object swap configuration',
    'LC__MODULE__SWAPCI__CONFIG_AVAILAVLE_OBJ_TYPES'                       => 'Selectable object-types',
    'LC__MODULE__SWAPCI__CONFIG_AVAILAVLE_OBJ_TYPES_DESCRIPTION'           => 'Here you can select the object types that shall be swappable and default categories.',
    'LC__MODULE__SWAPCI__CONFIG_CONSIDER_STATUS'                           => 'Consider the "swap" status?',
    'LC__MODULE__SWAPCI__CONFIG_CONSIDER_STATUS_DESCRIPTION'               => 'The swapped object will receive the status "Swapped", the new object will get "In operation"',
    'LC__MODULE__SWAPCI__CONFIG_STORE_STATUS'                              => 'CMDB status for storing objects',
    'LC__MODULE__SWAPCI__CONFIG_STORE_STATUS_DESCRIPTION'                  => 'Only objects with the given CMDB status will be available for swapping',
    'LC__MODULE__SWAPCI__CONFIG_ARCHIVE_SWAPPED_OBJ'                       => 'Archive swapped objects?',
    'LC__MODULE__SWAPCI__CONFIG_KEEP_SWAPPED_CATS_DATA'                    => 'Keep swapped object categories data?',
    'LC__MODULE__SWAPCI__CONFIG_SWAP_SYSID'                                => 'Also swap the SYS-ID?',
    'LC__MODULE__SWAPCI__GUI'                                              => 'Swap objects',
    'LC__MODULE__SWAPCI__GUI_TITLE'                                        => 'Welcome to the "Swap CI"',
    'LC__MODULE__SWAPCI__GUI_ERROR_OBJECTS_ARE_IDENTICAL'                  => 'Attention! The selected objects are the same.',
    'LC__MODULE__SWAPCI__GUI_ERROR_OBJ_TYPE_MISMATCH'                      => 'Attention! The selected objects have different types.',
    'LC__MODULE__SWAPCI__GUI_OBJECT_TO_SWAP'                               => 'Object to swap',
    'LC__MODULE__SWAPCI__GUI_STORED_OBJECT'                                => 'Stored object',
    'LC__MODULE__SWAPCI__GUI_START_SWAPPING'                               => 'Start swapping',
    'LC__MODULE__SWAPCI__GUI_CATEGORIES_TO_SWAP'                           => 'Categories to be adopted',
    'LC__MODULE__SWAPCI__GUI_CATEGORIES_TO_SWAP_DESCRIPTION'               => 'The following categories shall be adopted by the new object (The other category data will not be altered)',
    'LC__MODULE__SWAPCI__GUI_DEBUG_MESSAGES'                               => 'Debug messages',
    'LC__MODULE__SWAPCI__GUI_CHANGE_OBJECTS'                               => 'Change',
    'LC__MODULE__SWAPCI__GUI_FINISHED'                                     => 'Finished the swap process! Please open the Log for more information',
    'LC__MODULE__SWAPCI__GUI_FINISHED_WITH_ERROR'                          => 'The swap process was interrupted by an error - Please check the Log!',
    'LC__MODULE__SWAPCI__GUI_BY_WORKPLACE'                                 => 'Swap by workplace',
    'LC__MODULE__SWAPCI__GUI_BY_WORKPLACE__OBJ_TYPE_SELECTION'             => 'Object-type selection',
    'LC__MODULE__SWAPCI__GUI_BY_WORKPLACE__TREE_TITLE'                     => 'Workplaces, which inherit objects of the type "<span>-</span>"',
    'LC__MODULE__SWAPCI__GUI_BY_WORKPLACE__SWAP_BUTTON'                    => 'Swap selected objects',
    'LC__MODULE__SWAPCI__GUI_BY_WORKPLACE__TOGGLE_TREE'                    => 'Toggle workplace tree',
    'LC__MODULE__SWAPCI__REPORT'                                           => 'Swap-report',
    'LC__MODULE__SWAPCI__REPORT_DESCRIPTION'                               => 'Dieser Report zeigt alle getauschten Objekte an.',
    'LC__MODULE__SWAPCI__REPORT_TITLE'                                     => 'Object swap report view',
    'LC__MODULE__SWAPCI__REPORT_NO_OBJECTS'                                => 'No swapped objects.',
    'LC__MODULE__SWAPCI__REPORT_DATETIME'                                  => 'Date and time',
    'LC__MODULE__SWAPCI__REPORT_OLD_OBJECT_NAME'                           => 'Swapped object',
    'LC__MODULE__SWAPCI__REPORT_NEW_OBJECT_NAME'                           => 'New object',
    'LC__MODULE__SWAPCI__REPORT_OBJ_TYPE'                                  => 'Object type',
    'LC__MODULE__SWAPCI__REPORT_LOG'                                       => 'Log',
    'LC__MODULE__SWAPCI__REPORT_PERSON'                                    => 'Person',
    'LC__MODULE__SWAPCI__REPORT_SHOW_LOG'                                  => 'Open log',
    'LC__MODULE__SWAPCI__REPORT_HIDE_LOG'                                  => 'Close log',
    'LC__MODULE__SWAPCI__REPORT_OBJECT_NO_LONGER_EXISTS'                   => 'Object no longer exists',
    'LC__CMDB_STATUS__SWAPPED'                                             => 'swapped',
    'LC__MODULE__SWAPCI__NAVBAR__SWAP'                                     => 'Swap',
    'LC__MODULE__SWAPCI__NAVBAR__SWAP_OBJECTS_TOOLTIP'                     => 'Swap the selected objects',
    'LC__MODULE__SWAPCI__NAVBAR__SWAP_OBJECT_TOOLTIP'                      => 'Swap the current object',
    'LC__AUTH_GUI__SWAP_GUI'                                               => 'Swap objects',
    'LC__AUTH_GUI__SWAP_GUI_BY_WORKPLACE'                                  => 'Swap by workplace',
    'LC__AUTH_GUI__SWAP_CONFIG'                                            => 'Swap CI module configuration',
    'LC__AUTH_GUI__SWAP_IN_LIST'                                           => 'Swap CI-button in object list',
    'LC__AUTH_GUI__SWAP_IN_OBJ'                                            => 'Swap CI-button in objects',
    'LC__AUTH__SWAPCI_EXCEPTION__MISSING_RIGHT_FOR_SWAP_GUI'               => 'You are not allowed to execute the "%s" action in the Swap GUI.',
    'LC__AUTH__SWAPCI_EXCEPTION__MISSING_RIGHT_FOR_SWAP_GUI_BY_WORKPLACES' => 'You are not allowed to execute the "%s" action in the Swap by workplace GUI.',
    'LC__AUTH__SWAPCI_EXCEPTION__MISSING_RIGHT_FOR_SWAP_CONFIG'            => 'You are not allowed to execute the "%s" action in the Swap CI configuration.',
    'LC__AUTH__SWAPCI_EXCEPTION__MISSING_RIGHT_FOR_SWAP_BUTTON'            => 'You are not allowed to use the "Swap" button.',
];