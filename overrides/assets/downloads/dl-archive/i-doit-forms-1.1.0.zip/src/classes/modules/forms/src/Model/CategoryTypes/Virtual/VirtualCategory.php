<?php

namespace idoit\Module\Forms\Model\CategoryTypes\Virtual;

interface VirtualCategory
{
    public function getRemovedProperties(): array;
}
