#!/bin/bash
if test -f .env; then
  set -a; source .env; set +a
else
  echo "Please, configure Forms Backend in .env file. You can do it with following commands:
cp .env.dist .env
vim .env
"
  exit 1
fi

if test -z "${FORMS_SECRET-}"; then
  echo "Please, set up FORMS_SECRET in .env file.
FORMS_SECRET is used to secure your installation"
  exit 1
fi

node ./dist/src/main $@
