<?php

namespace idoit\Module\Forms\Exceptions;

use Exception;

class FormRequestBodyException extends Exception
{

}
