<?php

namespace idoit\Module\Forms\Controller;

use idoit\Module\Forms\View\Main as MainView;
use isys_application as Application;
use isys_register as Register;

class Form extends Main
{
    /**
     * Default handler for displaying the form GUI.
     *
     * @param   Register    $request
     * @param   Application $application
     */
    public function handle(Register $request, Application $application)
    {
        return new MainView($request, 'idoit.addon.forms.Form', []);
    }
}