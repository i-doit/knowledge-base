<?php

namespace idoit\Module\Forms\Processor;

use idoit\Module\Forms\Processor;
use isys_cmdb_dao;
use isys_custom_fields_dao;
use isys_report;

/**
 * Class Uninstall
 *
 * @package   idoit\Module\Forms\Processor
 * @copyright synetics
 * @license   
 */
class Uninstall extends Processor
{
    /**
     * @return void
     * @throws \idoit\Exception\JsonException
     * @throws \isys_exception_dao
     * @throws \Exception
     */
    public function process()
    {

    }
}
