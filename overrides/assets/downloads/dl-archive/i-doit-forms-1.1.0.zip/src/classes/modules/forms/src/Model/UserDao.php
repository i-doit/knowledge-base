<?php

namespace idoit\Module\Forms\Model;

use idoit\Model\Dao\Base;
use isys_component_dao_result;

class UserDao extends Base
{
  /**
   * @return isys_component_dao_result
   * @throws \isys_exception_database
   */
  public function getAll(): isys_component_dao_result
  {
    $recordStatusNormal = $this->convert_sql_int(C__RECORD_STATUS__NORMAL);

    $sql = "SELECT isys_obj__id AS id, isys_obj__title AS title
      FROM isys_cats_person_list
      LEFT JOIN isys_obj ON isys_cats_person_list__isys_obj__id = isys_obj__id
      WHERE isys_cats_person_list__status = $recordStatusNormal
      AND isys_obj__status = $recordStatusNormal
      AND isys_cats_person_list__disabled_login = 0
      AND isys_cats_person_list__title <> ''
      AND isys_cats_person_list__user_pass <> ''";

    return $this->retrieve($sql);
  }
}
