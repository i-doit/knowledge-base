// This vars hold the last cursor position for adding the placeholder at that position
g_range = null;
g_sel = null;
g_edit_placeholder = null;

// Add DIV-Container for our placeholder popups
document.body.appendChild(new Element('div', {id: 'popup_placeholder', 'class': 'popup', 'style': 'display:none;z-index:1051'}));