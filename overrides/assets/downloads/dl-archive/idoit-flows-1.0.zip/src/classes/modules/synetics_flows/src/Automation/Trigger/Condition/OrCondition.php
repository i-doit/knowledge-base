<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Trigger\Condition;

use idoit\Module\SyneticsFlows\Serialization\ArrayFormat;

class OrCondition extends Condition
{
    public function __construct(
        #[ArrayFormat(Condition::class)]
        protected array $items = [],
    )
    {
    }

    public function getItems(): array
    {
        return $this->items;
    }
}