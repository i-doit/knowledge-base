<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Dto\Criteria;

class RangeCriteria extends FieldCriteria
{
    public function __construct(?string $field = null, protected $from = null, protected $to = null)
    {
        parent::__construct($field);
    }

    /**
     * @return null
     */
    public function getFrom()
    {
        return $this->from;
    }

    /**
     * @return null
     */
    public function getTo()
    {
        return $this->to;
    }
}