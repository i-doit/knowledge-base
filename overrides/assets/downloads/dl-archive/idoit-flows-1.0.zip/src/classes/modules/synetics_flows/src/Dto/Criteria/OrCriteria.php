<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Dto\Criteria;

class OrCriteria extends AggregateCriteria
{

}