<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Dto\Criteria;

use idoit\Module\SyneticsFlows\Dto\Criteria;

class QueryCriteria extends FieldCriteria
{
    public function __construct(?string $field = null, private ?Criteria $criteria = null)
    {
        parent::__construct($field);
    }

    public function getCriteria(): ?Criteria
    {
        return $this->criteria;
    }
}