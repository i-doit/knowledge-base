<?php

return [
    'LC__MODULE__SYNETICS_FLOWS__FLOWS' => 'Flows',
    'LC__MODULE__SYNETICS_FLOWS__MANAGE_FLOWS' => 'Manage flows',
    'LC__MODULE__SYNETICS_FLOWS__AUTH__MISSING_SYNETICS_FLOWS_RIGHT' => 'You are missing the %s right for the Flows Add-on. Please, check your rights',
    'LC__MODULE__SYNETICS_FLOWS__NOT_LICENSED' => 'Flows add-on is currently not licensed. Please update your license key.',
];
