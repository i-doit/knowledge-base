<?php

namespace idoit\Module\SyneticsFlows\Automation\Trigger\ConditionBuilder;

use idoit\Module\SyneticsFlows\Automation\Trigger\Condition\Condition;

interface ConditionBuilder
{
    public function build(Condition $condition): string;
}
