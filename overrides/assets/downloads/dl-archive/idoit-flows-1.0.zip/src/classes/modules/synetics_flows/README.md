# Synetics Flows

`Synetics Flows` add-on consists of a backend which make use of the symfony-based routing in i-doit and provides necessary endpoints for data exchange and operations.
The frontend part is based on react and integrates vite as build-tool.

## Setup

Setup up the frontend in `react` directory by simply executing:

```shell
cd react && npm i
```
After all dependencies are installed you are ready to go.

## Requirements

* `node` > 18.18.0 || > 20
* `npm` > 8

## IDE Setup

Enable `eslint` settings adjust parameters as following:

* Activate `Automatic ESLint configuration`
* Set `Run for files` to `**/*.{ts,tsx}`
* Activate `Run eslint --fix on save`

## Development

For development purpose we can start `vite` in watch-mode. This ensures that all files are rebuild if any changes in related files happens:

```shell
npm run dev
```
