<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\ExecutionResult;

use idoit\Module\SyneticsFlows\Automation\Action\ExecutionInfo\ExecutionInfo;

class DebugResult extends ExecutionResult
{
    public function __construct(private ExecutionInfo $action)
    {
    }

    public function getAction(): ExecutionInfo
    {
        return $this->action;
    }

    public function __toString(): string
    {
        return 'Test mode';
    }
}