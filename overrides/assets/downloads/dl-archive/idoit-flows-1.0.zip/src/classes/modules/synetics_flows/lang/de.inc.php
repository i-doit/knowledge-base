<?php

return [
    'LC__MODULE__SYNETICS_FLOWS__FLOWS' => 'Flows',
    'LC__MODULE__SYNETICS_FLOWS__MANAGE_FLOWS' => 'Flows verwalten',
    'LC__MODULE__SYNETICS_FLOWS__AUTH__MISSING_SYNETICS_FLOWS_RIGHT' => 'Ihnen fehlt das %s Recht für das Flows Add-on. Bitte überprüfen Sie Ihre Rechte',
    'LC__MODULE__SYNETICS_FLOWS__NOT_LICENSED'=> 'Das Flows Add-on ist aktuell nicht lizenziert. Bitte aktualisieren Sie Ihren Lizenzschlüssel.',
];
