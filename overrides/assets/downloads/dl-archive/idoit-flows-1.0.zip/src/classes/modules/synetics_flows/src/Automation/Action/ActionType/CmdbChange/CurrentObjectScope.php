<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\ActionType\CmdbChange;

class CurrentObjectScope extends CmdbScope
{

}