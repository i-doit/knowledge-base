<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\ActionType\CmdbChange;

use idoit\Module\SyneticsFlows\Serialization\Discriminator;
use idoit\Module\SyneticsFlows\Serialization\SerializableTrait;

#[Discriminator([
    'current' => CurrentObjectScope::class,
    'objects' => ObjectIdsScope::class
])]
abstract class CmdbScope implements \JsonSerializable
{
    use SerializableTrait;
}