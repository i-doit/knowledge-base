<?php

/**
 * i-doit
 *
 * @package    i-doit
 * @subpackage API
 * @author     Selcuk Kekec <skekec@i-doit.de>
 * @version    1.10
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */

use idoit\Module\Document\Console\Command\CompileDocumentsCommand;

/**
 * Class isys_model_console_document
 */
class isys_api_model_console_document extends isys_api_model_console
{
    /**
     * Compile document
     *
     * @param array $params
     *
     * @return array
     * @throws Exception
     */
    public function compile(array $params = [])
    {
        $this->commandExists(CompileDocumentsCommand::class);

        return $this->run(CompileDocumentsCommand::NAME, $params['options'], $params['arguments']);
    }
}