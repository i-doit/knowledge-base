<?php

/**
 * i-doit
 *
 * @package    i-doit
 * @subpackage API
 * @author     Selcuk Kekec <skekec@i-doit.de>
 * @version    1.10
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */

namespace idoit\Module\Api\Model\Cmdb\Category\Processor;

/**
 * GenericProcessor
 *
 * @package    idoit\Module\Api\Model\Category
 */
class GenericProcessor extends AbstractCategoryProcessor
{
    /**
     * Generic processor should not modify anything
     */
}