<?php

/**
 * i-doit
 *
 * @package    i-doit
 * @subpackage API
 * @author     Selcuk Kekec <skekec@i-doit.de>
 * @version    1.10
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */

namespace idoit\Module\Api\Response;

/**
 * Class AbstractResponse
 *
 * @package idoit\Module\Api\Response
 */
abstract class AbstractResponse
{
    /**
     * Get response
     *
     * @return array
     */
    abstract public function getResponse();

    /**
     * Validate response
     *
     * @return bool
     */
    abstract public function validate();
}