<?php

namespace idoit\Module\Events\Model;

use idoit\Model\Dao\Base;

/**
 * Class Dao.
 *
 * @package   idoit\Module\Events\Model
 * @author    Leonard Fischer <lfischer@i-doit.com>
 * @copyright synetics GmbH
 * @license   http://www.i-doit.com/license
 */
class Dao extends Base
{
}
