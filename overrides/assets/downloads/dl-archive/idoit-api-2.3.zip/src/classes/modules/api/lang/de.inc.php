<?php
/**
 * i-doit
 *
 * "Relocate-CI" Module language file
 *
 * @package     modules
 * @subpackage  relocate_ci
 * @author      Leonard Fischer <lfischer@i-doit.com>
 * @version     1.0.0
 * @copyright   synetics GmbH
 * @license     http://www.i-doit.com/license
 * @since       i-doit 1.4.7
 */

return [
    'LC__ADDON__API'                                                       => 'API',
    'LC__ADDON__API__AUTH_CONFIGURATION'                                   => 'Konfiguration',
    'LC__ADDON__API__AUTH_CATEGORIES_ATTRIBUTES'                           => 'Attribut Dokumentation',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION'                              => 'Attribut Dokumentation',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES'                  => 'Attribute',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__DATA_TYPE_READ'  => 'Datentyp (lesen)',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__DATA_TYPE_WRITE' => 'Datentyp (schreiben)',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__DESCRIPTION'     => 'Beschreibung',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__KEY'             => 'Key',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__TITLE'           => 'Bezeichnung',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__TYPE'            => 'Attribut-Typ',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__CATEGORY_INFORMATION'        => 'Kategorie-Informationen',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__CONSTANT'                    => 'Konstante',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__EXAMPLE'                     => 'Beispiel',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ID'                          => 'ID',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__DEFINITION'                  => 'Definition',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__MULTIVALUE'                  => 'Multivalue',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__PLEASE_SELECT_A_CATEGORY'    => 'Bitte wählen Sie eine Kategorie',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__TABLE__NAME'                 => 'Name',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__TABLE__DESCRIPTION'          => 'Beschreibung',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__TABLE__DEFAULT'              => 'Standardwert',
    'LC__ADDON__API__CONFIGURATION'                                        => 'JSON-RPC API',
    'LC__ADDON__API__CONFIGURATION__API_KEY'                               => 'API-Key',
    'LC__ADDON__API__CONFIGURATION__API_KEY__CREATE_NEW'                   => 'Neuen API-Key erzeugen',
    'LC__ADDON__API__CONFIGURATION__ACTIVE'                                => 'JSON-RPC API aktivieren',
    'LC__ADDON__API__CONFIGURATION__FORCE_AUTHENTIFICATION'                => 'Erzwinge Authentifizierung',
    'LC__ADDON__API__CONFIGURATION__FORCE_AUTHENTIFICATION__NOTIFICATION'  => 'Dieser Wert kann nur in den Systemeinstellung vom Admin-Center bearbeitet werden',
    'LC__ADDON__API__CONFIGURATION__STRIP_HTML'                            => 'Entfernen von HTML-Tags aus Beschreibungsfeldern',
    'LC__ADDON__API__CONFIGURATION__LOG_LEVEL'                             => 'Log Level',
    'LC__ADDON__API__ENDPOINT_DOCUMENTATION'                               => 'Endpunkt Dokumentation',
    'LC__ADDON__API__ENDPOINT_DOCUMENTATION__REQUEST_EXAMPLES'             => 'Anfrage Beispiele',
    'LC__ADDON__API__ENDPOINT_DOCUMENTATION__RESPONSE_EXAMPLES'            => 'Antwort Beispiele',
    'LC__ADDON__API__ENDPOINT_DOCUMENTATION__CURRENTLY_NO_EXAMPLES'        => 'Derzeit keine Beispiele',
    'LC__ADDON__API__ENDPOINT_DOCUMENTATION__PARAMETERS'                   => 'Parameter',
    'LC__ADDON__API__ENDPOINT_DOCUMENTATION__NO_PARAMETERS'                => 'Keine Parameter',
    'LC__ADDON__API__ENDPOINT_DOCUMENTATION__COLLAPSE_ALL'                 => 'Alles einklappen',
    'LC__ADDON__API__ENDPOINT_DOCUMENTATION__EXPAND_ALL'                   => 'Alles ausklappen',
    'LC__ADDON__API__ENDPOINT__CMDB_CATEGORY_ARCHIVE'                      => 'Wird einen einzelnen Kategorieeintrag "archivieren".',
    'LC__ADDON__API__ENDPOINT__CMDB_CATEGORY_DELETE'                       => 'Wird einen einzelnen Kategorieeintrag "löschen".',
    'LC__ADDON__API__ENDPOINT__CMDB_CATEGORY_PURGE'                        => 'Wird einen einzelnen Kategorieeintrag endgültig aus der Datenbank entfernen.',
    'LC__ADDON__API__ENDPOINT__CMDB_EXTERNAL_PULL'                         => 'Erhalte Objekt- und Kategoriedaten basierend auf der externen Kennung.',
    'LC__ADDON__API__ENDPOINT__CMDB_EXTERNAL_PUSH'                         => 'Pusht ein Objekt und seine Kategorieeinträge auf einmal, basierend auf dessen externen Kennung.',
    'LC__ADDON__API__ENDPOINT__CMDB_OBJECT_ARCHIVE'                        => 'Wird ein einzelnes Object "archivieren".',
    'LC__ADDON__API__ENDPOINT__CMDB_OBJECT_DELETE'                         => 'Wird ein einzelnes Object "löschen".',
    'LC__ADDON__API__ENDPOINT__CMDB_OBJECT_PURGE'                          => 'Wird ein einzelnes Object endgültig aus der Datenbank entfernen.',
    'LC__ADDON__API__ENDPOINT__CMDB_OBJECT_READ'                           => 'Wird ein einzelnes Objekt aus i-doit lesen, kann gleichzeitig Kategorieninformationen lesen.',
    'LC__ADDON__API__ENDPOINT__CMDB_OBJECT_SAVE'                           => 'Wird ein einzelnes Objekt in i-doit erstellen oder aktualisieren, kann beim erstellen auch Kategorieninformationen beinhalten.',
    // Object type group specific translations
    'LC__ADDON__API__ENDPOINT__CMDB_OBJECT_TYPE_GROUP_CREATE'              => 'Wird eine Objekttyp-Gruppen in i-doit erstellen.',
    'LC__ADDON__API__ENDPOINT__CMDB_OBJECT_TYPE_GROUP_DELETE'              => 'Löscht eine Objekttyp-Gruppe aus i-doit.',
    'LC__ADDON__API__ENDPOINT__CMDB_OBJECT_TYPE_GROUP_READ'                => 'Wird ein oder mehrere Objekttyp-Gruppen aus i-doit lesen.',
    'LC__ADDON__API__ENDPOINT__CMDB_OBJECT_TYPE_GROUP_UPDATE'              => 'Wird eine Objekttyp-Gruppen bearbeiten.',
    'LC__ADDON__API__PARAMETER__CMDB_OBJECT_TYPE_GROUP_SORT'               => 'Sortierung der Objekttyp-Gruppe',
    'LC__ADDON__API__PARAMETER__CMDB_OBJECT_TYPE_GROUP_TITLE'              => 'Titel der Objekttyp-Gruppe',
    'LC__ADDON__API__PARAMETER__CMDB_OBJECT_TYPE_GROUP_VISIBLE'            => 'Sichtbarkeit der Objekttyp-Gruppe',

    'LC__ADDON__API__ENDPOINT__CMDB_REPORT_LIST'                  => 'Listet alle verfügbaren Reports basierend auf Ihren Rechten auf. Um einen Report auszuführen, verwenden Sie "cmdb.report.read.v2".',
    'LC__ADDON__API__ENDPOINT__CMDB_REPORT_READ'                  => 'Führt einen übergebenen Report aus.',
    'LC__ADDON__API__ENDPOINT__SYSTEM_ENDPOINTS_READ'             => 'Wird alle registrierten Endpunkte der neuen Struktur lesen.',
    'LC__ADDON__API__PARAMETER__CATEGORY_CONSTANT'                => 'Kategorie Konstante als String.',
    'LC__ADDON__API__PARAMETER__CATEGORY_CONSTANTS'               => 'Array mit Kategoriekonstanten als String.',
    'LC__ADDON__API__PARAMETER__CONSTANT'                         => 'Einzelne Konstante als String.',
    'LC__ADDON__API__PARAMETER__CONSTANT_OR_ARRAY'                => 'Konstante als String oder Array.',
    'LC__ADDON__API__PARAMETER__DESCRIPTION'                      => 'Beschreibung als String.',
    'LC__ADDON__API__PARAMETER__EXTERNAL_CATEGORY_DATA'           => 'Kategoriedaten für das Asset.',
    'LC__ADDON__API__PARAMETER__EXTERNAL_EXT_ID'                  => 'Zweiter Teil der externen Kennung, der verwendet wird, um das Asset zu identifizieren.',
    'LC__ADDON__API__PARAMETER__EXTERNAL_EXT_TYPE'                => 'Erster Teil der externen Kennung, der verwendet wird, um die Datenquelle zu identifizieren.',
    'LC__ADDON__API__PARAMETER__EXTERNAL_OBJECT_TITLE'            => 'Objekttitel des Assets, das erstellt werden soll, falls es nicht existiert.',
    'LC__ADDON__API__PARAMETER__EXTERNAL_OBJECT_TYPE_TITLE'       => 'Objekttyp des Assets als Konstante, das erstellt werden soll, falls es nicht existiert.',
    'LC__ADDON__API__PARAMETER__ID'                               => 'Numerische Eintrags-ID.',
    'LC__ADDON__API__PARAMETER__ID_OR_ARRAY'                      => 'Numerische Eintrags-ID als Integer oder Array.',
    'LC__ADDON__API__PARAMETER__OBJECT_ID'                        => 'Numerische Objekt-ID.',
    'LC__ADDON__API__PARAMETER__OBJECT_TITLE'                     => 'Objektbezeichnung als String.',
    'LC__ADDON__API__PARAMETER__OBJECT_SYSID'                     => 'Objekt SYS-ID als String.',
    'LC__ADDON__API__PARAMETER__OBJECT_CATEGORY_ID_OR_TITLE'      => 'Kategorie, entweder als ID (itneger) oder Namen (string).',
    'LC__ADDON__API__PARAMETER__OBJECT_PURPOSE_ID_OR_TITLE'       => 'Einsatzzweck, entweder als ID (itneger) oder Namen (string).',
    'LC__ADDON__API__PARAMETER__OBJECT_TYPE_CONSTANT_OR_ID'       => 'Objekttyp, entweder als ID (integer) oder Konstante (string).',
    'LC__ADDON__API__PARAMETER__OBJECT_TYPE_GROUP_CONSTANT_OR_ID' => 'Objekttyp-Gruppe, entweder als ID (integer) oder Konstante (string).',
    'LC__ADDON__API__PARAMETER__OBJECT_TAGS'                      => 'Array mit Tags als String.',
    'LC__ADDON__API__PARAMETER__REPORT_OFFSET'                    => 'Setze einen Offset, um die ersten {n} Zeilen zu überspringen. Kann zusammen mit "Limit" verwendet werden, um zu paginieren.',
    'LC__ADDON__API__PARAMETER__REPORT_LIMIT'                     => 'Begrenze, wie viele Zeilen zurückgegeben werden sollen. Kann zusammen mit "Offset" verwendet werden, um zu paginieren.',
    'LC__ADDON__API__PARAMETER__REQUIRED'                         => 'Erforderlich',
];
