<?php

/**
 * i-doit
 *
 * @package    i-doit
 * @subpackage API
 * @author     Selcuk Kekec <skekec@i-doit.de>
 * @version    1.10
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */

namespace idoit\Module\Api\Validation\Property;

use idoit\Component\Property\Property;
use idoit\Module\Api\Exception\ValidationException;
use idoit\Module\Api\Validation\PropertyValidation;

/**
 * Class Dialog
 *
 * @package idoit\Module\Api\Validation\Property
 */
class Dialog extends PropertyValidation
{

    /**
     * Validate value
     *
     * @return bool
     * @throws ValidationException
     */
    public function validate()
    {
        $propertyDefinition = $this->getPropertyDefinition();

        $isMultiselect = isset($propertyDefinition[Property::C__PROPERTY__UI][Property::C__PROPERTY__UI__PARAMS]['p_multiple']) &&
            $propertyDefinition[Property::C__PROPERTY__UI][Property::C__PROPERTY__UI__PARAMS]['p_multiple'];

        $value = $this->getValue();

        // API-585 Implement multiselect specific validation
        if ($isMultiselect) {
            if (!is_array($value)) {
                throw new ValidationException($this->getPropertyType(), 'Property has to be an array of integer or string values.');
            }
        } else {
            if (!is_int($value) && !is_string($value)) {
                throw new ValidationException($this->getPropertyType(), 'Property has to be an integer or string value.');
            }

            if (is_string($value) && isys_strlen($value) > 255) {
                throw new ValidationException($this->getPropertyType(), 'Property exceeded maximum length of possible 255 characters.');
            }
        }

        // @see API-564 Allow empty (-1) values, if the property allows it.
        $uiParams = $propertyDefinition[Property::C__PROPERTY__UI][Property::C__PROPERTY__UI__PARAMS] ?? [];

        $minValue = (!isset($uiParams['p_bDbFieldNN']) || $uiParams['p_bDbFieldNN']) ? -1 : 0;

        if (is_int($value) && $value < $minValue) {
            throw new ValidationException($this->getPropertyType(), 'Property value should be greater then zero.');
        }

        return true;
    }
}
