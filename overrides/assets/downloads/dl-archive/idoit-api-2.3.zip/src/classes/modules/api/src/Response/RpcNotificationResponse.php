<?php

/**
 * i-doit
 *
 * @package    i-doit
 * @subpackage API
 * @author     Selcuk Kekec <skekec@i-doit.de>
 * @version    1.10
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */

namespace idoit\Module\Api\Response;

/**
 * Class RpcNotificationResponse
 *
 * @package idoit\Module\Api\Response
 */
class RpcNotificationResponse extends RpcResponse
{

    /**
     * Get response
     *
     * @return null
     */
    public function getResponse()
    {
        return null;
    }

    /**
     * Validate response
     *
     * @return bool
     */
    public function validate()
    {
        return true;
    }

    /**
     * RpcNotificationResponse constructor.
     */
    public function __construct()
    {

    }
}