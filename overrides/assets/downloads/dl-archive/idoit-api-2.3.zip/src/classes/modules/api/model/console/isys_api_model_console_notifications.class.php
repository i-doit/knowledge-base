<?php

/**
 * i-doit
 *
 * @package    i-doit
 * @subpackage API
 * @author     Selcuk Kekec <skekec@i-doit.de>
 * @version    1.10
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */

use idoit\Console\Command\Notification\HandleNotificationsCommand;

/**
 * Class isys_model_console_notifications
 */
class isys_api_model_console_notifications extends isys_api_model_console
{
    /**
     * Send notification
     *
     * @param array $params
     *
     * @return array
     * @throws Exception
     */
    public function send(array $params = [])
    {
        // @see API-544 Check if the feature is available.
        $this->checkFeatureAvailability('notification-command');

        // Check whether command exists
        $this->commandExists(HandleNotificationsCommand::class);

        return $this->run(HandleNotificationsCommand::NAME, $params['options'], $params['arguments']);
    }
}
