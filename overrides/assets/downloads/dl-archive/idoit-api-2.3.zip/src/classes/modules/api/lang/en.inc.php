<?php
/**
 * i-doit
 *
 * "Relocate-CI" Module language file
 *
 * @package     modules
 * @subpackage  relocate_ci
 * @author      Leonard Fischer <lfischer@i-doit.com>
 * @version     1.0.0
 * @copyright   synetics GmbH
 * @license     http://www.i-doit.com/license
 * @since       i-doit 1.4.7
 */

return [
    'LC__ADDON__API'                                                       => 'API',
    'LC__ADDON__API__AUTH_CONFIGURATION'                                   => 'Configuration',
    'LC__ADDON__API__AUTH_CATEGORIES_ATTRIBUTES'                           => 'Attribute documentation',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION'                              => 'Attribute documentation',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES'                  => 'Attributes',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__DATA_TYPE_READ'  => 'Data type (read)',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__DATA_TYPE_WRITE' => 'Data type (write)',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__DESCRIPTION'     => 'Description',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__KEY'             => 'Key',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__TITLE'           => 'Title',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ATTRIBUTES__TYPE'            => 'Attribute type',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__CATEGORY_INFORMATION'        => 'Category information',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__CONSTANT'                    => 'Constant',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__EXAMPLE'                     => 'Example',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__ID'                          => 'ID',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__DEFINITION'                  => 'Definition',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__MULTIVALUE'                  => 'Multivalue',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__PLEASE_SELECT_A_CATEGORY'    => 'Please select a category',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__TABLE__NAME'                 => 'Name',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__TABLE__DESCRIPTION'          => 'Description',
    'LC__ADDON__API__ATTRIBUTE_DOCUMENTATION__TABLE__DEFAULT'              => 'Default',
    'LC__ADDON__API__CONFIGURATION'                                        => 'JSON-RPC API',
    'LC__ADDON__API__CONFIGURATION__API_KEY'                               => 'API-Key',
    'LC__ADDON__API__CONFIGURATION__API_KEY__CREATE_NEW'                   => 'Create new API-Key',
    'LC__ADDON__API__CONFIGURATION__ACTIVE'                                => 'Activate JSON-RPC API',
    'LC__ADDON__API__CONFIGURATION__FORCE_AUTHENTIFICATION'                => 'Enforce authentification',
    'LC__ADDON__API__CONFIGURATION__FORCE_AUTHENTIFICATION__NOTIFICATION'  => 'This value can only be edited in the system settings in the admin-center',
    'LC__ADDON__API__CONFIGURATION__STRIP_HTML'                            => 'Strip HTML tags from description fields',
    'LC__ADDON__API__CONFIGURATION__LOG_LEVEL'                             => 'Log Level',
    'LC__ADDON__API__ENDPOINT_DOCUMENTATION'                               => 'Endpoint documentation',
    'LC__ADDON__API__ENDPOINT_DOCUMENTATION__REQUEST_EXAMPLES'             => 'Request examples',
    'LC__ADDON__API__ENDPOINT_DOCUMENTATION__RESPONSE_EXAMPLES'            => 'Response examples',
    'LC__ADDON__API__ENDPOINT_DOCUMENTATION__CURRENTLY_NO_EXAMPLES'        => 'Currently no examples',
    'LC__ADDON__API__ENDPOINT_DOCUMENTATION__PARAMETERS'                   => 'Parameters',
    'LC__ADDON__API__ENDPOINT_DOCUMENTATION__NO_PARAMETERS'                => 'No parameters',
    'LC__ADDON__API__ENDPOINT_DOCUMENTATION__COLLAPSE_ALL'                 => 'Collapse all',
    'LC__ADDON__API__ENDPOINT_DOCUMENTATION__EXPAND_ALL'                   => 'Expand all',
    'LC__ADDON__API__ENDPOINT__CMDB_CATEGORY_ARCHIVE'                      => 'Will "archive" a singular category entry.',
    'LC__ADDON__API__ENDPOINT__CMDB_CATEGORY_DELETE'                       => 'Will "delete" a singular category entry.',
    'LC__ADDON__API__ENDPOINT__CMDB_CATEGORY_PURGE'                        => 'Will permanently remove a singular category entry from the database.',
    'LC__ADDON__API__ENDPOINT__CMDB_EXTERNAL_PULL'                         => 'Get object and category data based on external identifier.',
    'LC__ADDON__API__ENDPOINT__CMDB_EXTERNAL_PUSH'                         => 'Push an object and its category entries at ones based on your external identifier.',
    'LC__ADDON__API__ENDPOINT__CMDB_OBJECT_ARCHIVE'                        => 'Will "archive" a singular object.',
    'LC__ADDON__API__ENDPOINT__CMDB_OBJECT_DELETE'                         => 'Will "delete" a singular object.',
    'LC__ADDON__API__ENDPOINT__CMDB_OBJECT_PURGE'                          => 'Will permanently remove a singular object from the database.',
    'LC__ADDON__API__ENDPOINT__CMDB_OBJECT_READ'                           => 'Reads a singular object from i-doit, can include category information.',
    'LC__ADDON__API__ENDPOINT__CMDB_OBJECT_SAVE'                           => 'Will create or update a singular object from i-doit, can include category information when creating.',
    // Object type group specific translations
    'LC__ADDON__API__ENDPOINT__CMDB_OBJECT_TYPE_GROUP_CREATE'              => 'Creates one new object type group in i-doit.',
    'LC__ADDON__API__ENDPOINT__CMDB_OBJECT_TYPE_GROUP_DELETE'              => 'Deletes one object type group in i-doit.',
    'LC__ADDON__API__ENDPOINT__CMDB_OBJECT_TYPE_GROUP_READ'                => 'Reads one or more object type group from i-doit.',
    'LC__ADDON__API__ENDPOINT__CMDB_OBJECT_TYPE_GROUP_UPDATE'              => 'Update an existing object type group.',
    'LC__ADDON__API__PARAMETER__CMDB_OBJECT_TYPE_GROUP_SORT'               => 'Sorting of the object type group',
    'LC__ADDON__API__PARAMETER__CMDB_OBJECT_TYPE_GROUP_TITLE'              => 'Title of the object type group',
    'LC__ADDON__API__PARAMETER__CMDB_OBJECT_TYPE_GROUP_VISIBLE'            => 'Visibility of the object type groups',

    'LC__ADDON__API__ENDPOINT__CMDB_REPORT_LIST'                  => 'Lists up all available reports, based on your rights. To execute a report use "cmdb.report.read.v2".',
    'LC__ADDON__API__ENDPOINT__CMDB_REPORT_READ'                  => 'Reads a given report.',
    'LC__ADDON__API__ENDPOINT__SYSTEM_ENDPOINTS_READ'             => 'Reads all registered endpoints of the new structure.',
    'LC__ADDON__API__PARAMETER__CATEGORY_CONSTANT'                => 'Category constant as string.',
    'LC__ADDON__API__PARAMETER__CATEGORY_CONSTANTS'               => 'Array of category constants as strings.',
    'LC__ADDON__API__PARAMETER__CONSTANT'                         => 'Single constant as string.',
    'LC__ADDON__API__PARAMETER__CONSTANT_OR_ARRAY'                => 'Constant as string or array.',
    'LC__ADDON__API__PARAMETER__DESCRIPTION'                      => 'Description as string.',
    'LC__ADDON__API__PARAMETER__EXTERNAL_CATEGORY_DATA'           => 'Category data for asset.',
    'LC__ADDON__API__PARAMETER__EXTERNAL_EXT_ID'                  => 'Second part of external identifier used to identifiy the asset.',
    'LC__ADDON__API__PARAMETER__EXTERNAL_EXT_TYPE'                => 'First part of external identifier used to identify the data source.',
    'LC__ADDON__API__PARAMETER__EXTERNAL_OBJECT_TITLE'            => 'Object title of asset which should be created if not exist.',
    'LC__ADDON__API__PARAMETER__EXTERNAL_OBJECT_TYPE_TITLE'       => 'Constant of object type of asset which should be created if not exist.',
    'LC__ADDON__API__PARAMETER__ID'                               => 'Numeric entry ID.',
    'LC__ADDON__API__PARAMETER__ID_OR_ARRAY'                      => 'Numeric entry ID as integer or array.',
    'LC__ADDON__API__PARAMETER__OBJECT_ID'                        => 'Numeric object ID.',
    'LC__ADDON__API__PARAMETER__OBJECT_TITLE'                     => 'Object title as string.',
    'LC__ADDON__API__PARAMETER__OBJECT_SYSID'                     => 'Object SYS-ID as string.',
    'LC__ADDON__API__PARAMETER__OBJECT_CATEGORY_ID_OR_TITLE'      => 'category, either as ID (itneger) or name (string).',
    'LC__ADDON__API__PARAMETER__OBJECT_PURPOSE_ID_OR_TITLE'       => 'purpose, either as ID (itneger) or name (string).',
    'LC__ADDON__API__PARAMETER__OBJECT_TYPE_CONSTANT_OR_ID'       => 'Object type, either as ID (integer) or constant (string).',
    'LC__ADDON__API__PARAMETER__OBJECT_TYPE_GROUP_CONSTANT_OR_ID' => 'Object type group, either as ID (integer) or constant (string).',
    'LC__ADDON__API__PARAMETER__OBJECT_TAGS'                      => 'Array of tags as string.',
    'LC__ADDON__API__PARAMETER__REPORT_OFFSET'                    => 'Set a offset to skip the first {n} rows, can be used together with "limit" to page.',
    'LC__ADDON__API__PARAMETER__REPORT_LIMIT'                     => 'Limit how many rows should be returned, can be used together with "offset" to page.',
    'LC__ADDON__API__PARAMETER__REQUIRED'                         => 'Required',
];
