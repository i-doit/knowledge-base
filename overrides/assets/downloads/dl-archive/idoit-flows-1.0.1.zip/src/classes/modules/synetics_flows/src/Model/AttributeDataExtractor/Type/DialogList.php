<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Model\AttributeDataExtractor\Type;

use idoit\Component\Property\Property;
use idoit\Module\Cmdb\Component\AttributeDataCollector\CollectorTypes\AbstractCollector;
use idoit\Module\Cmdb\Component\AttributeDataCollector\CollectorTypes\DialogList as DialogListCollector;
use idoit\Module\SyneticsFlows\Model\AttributeDataExtractor\ExtractorInterface;

class DialogList extends Dialog implements ExtractorInterface
{
    /**
     * @param AbstractCollector $dataCollector
     *
     * @return bool
     */
    public function supports(AbstractCollector $dataCollector): bool
    {
        return $dataCollector instanceof DialogListCollector;
    }
}
