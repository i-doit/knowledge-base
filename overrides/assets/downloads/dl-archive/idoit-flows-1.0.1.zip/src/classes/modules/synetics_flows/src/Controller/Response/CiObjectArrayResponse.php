<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Controller\Response;

use Symfony\Component\HttpFoundation\JsonResponse;

class CiObjectArrayResponse extends JsonResponse
{
    public function __construct(array $data, ?int $total, ?array $groups, ?array $groupsAll )
    {
        parent::__construct(new CiObjectArrayResult($data, $total, $groups,  $groupsAll));
    }
}
