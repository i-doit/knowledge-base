<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Validation;

abstract class Validator
{
    /**
     * @param mixed $value
     *
     * @return string[]
     */
    public abstract function validate(mixed $value): array;
}