<?php

return [
    'LC__MODULE__SYNETICS_FLOWS__FLOWS'                              => 'Flows',
    'LC__MODULE__SYNETICS_FLOWS__MANAGE_FLOWS'                       => 'Manage flows',
    'LC__MODULE__SYNETICS_FLOWS__AUTH__MISSING_SYNETICS_FLOWS_RIGHT' => 'You are missing the %s right for the Flows Add-on. Please, check your rights',
    'LC__MODULE__SYNETICS_FLOWS__NOT_LICENSED'                       => 'Flows add-on is currently not licensed. Please update your license key.',
    // Validation errors.
    'LC__MODULE__SYNETICS_FLOWS__VALUE_REQUIRED'                     => 'The value is required.',
    'LC__MODULE__SYNETICS_FLOWS__TRIGGER_REQUIRED'                   => 'The trigger is required. Add a trigger to the flow.',
    'LC__MODULE__SYNETICS_FLOWS__ACTION_REQUIRED'                    => 'The action is required. Add an action to the flow.',
    'LC__MODULE__SYNETICS_FLOWS__ATTRIBUTE_INVALID_ERROR'            => 'Attribute is not valid. Please ensure that it contains the category constant and attribute like for example \'C__CATG__MODEL.manufacturer\'.',
    // Type specific validation errors
    'LC__MODULE__SYNETICS_FLOWS__INVALID_URL'                        => 'You need to provide a valid URL.',
    'LC__MODULE__SYNETICS_FLOWS__INVALID_EMAIL'                      => 'Invalid email address.',
    'LC__MODULE__SYNETICS_FLOWS__AT_LEAST_ONE_TIME'                  => 'At least one time range should be selected.',
    'LC__MODULE__SYNETICS_FLOWS__FROM_BEFORE_TO_TIME'                => '"From" must be before "to".',
    'LC__MODULE__SYNETICS_FLOWS__TO_AFTER_FROM_TIME'                 => '"To" must be after "from".',
    'LC__MODULE__SYNETICS_FLOWS__START_BEFORE_END_DATE'              => '"Start" must be before "end".',
    'LC__MODULE__SYNETICS_FLOWS__END_AFTER_START_DATE'               => '"End" must be after "start".',
    'LC__MODULE__SYNETICS_FLOWS__BEFORE_TO'                          => 'Value must be before "To" value.',
    'LC__MODULE__SYNETICS_FLOWS__AFTER_FROM'                         => 'Value must be after "From" value.',
    'LC__MODULE__SYNETICS_FLOWS__VALUE_ON_OF'                        => 'Value should be one of:',
    'LC__MODULE__SYNETICS_FLOWS__POSITIV_INT'                        => 'Period must be positive number.',
    'LC__MODULE__SYNETICS_FLOWS__FLOWS_STARTED' => 'Started Flows %s',
    'LC__MODULE__SYNETICS_FLOWS__FLOW_STARTED' => 'Started Flow %s',
    'LC__MODULE__SYNETICS_FLOWS__FLOW_NOT_STARTED' => 'Couldn’t start Flow %s',
    'LC__MODULE__SYNETICS_FLOWS__FLOWS_NOT_STARTED' => 'Couldn’t start Flows %s',
    'LC__MODULE__SYNETICS_FLOWS__SHOW_ALL_FLOWS' => 'Show all flows of this group',
    'LC__MODULE__SYNETICS_FLOWS__TRIGGER_FLOW' => 'Triggers flow %s',
];
