<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Serialization;

use Attribute;

#[Attribute(Attribute::TARGET_PROPERTY)]
class Exclude extends Format
{
    public function toJson(mixed $object): mixed
    {
        return null;
    }

    public function fromJson(mixed $string): mixed
    {
        return null;
    }
}