<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\ActionType\IdoitCommand\Command;

use idoit\Module\SyneticsFlows\Automation\Action\ActionType\IdoitCommand\IdoitCommand;
use Symfony\Component\Console\Command\Command;

interface CommandConverter
{
    public function convert(Command $command): ?IdoitCommand;

    public function supports(Command $command): bool;
}