<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\ActionType\IdoitCommand\Command;

interface OrderConverter
{
    public function convert(string $commandName, array $items): array;

    public function supports(string $commandName): bool;
}