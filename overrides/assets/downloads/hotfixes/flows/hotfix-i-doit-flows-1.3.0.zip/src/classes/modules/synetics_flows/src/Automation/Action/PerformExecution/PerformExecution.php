<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\PerformExecution;

use idoit\Module\SyneticsFlows\Automation\Action\ExecutionResult\ExecutionResult;
use idoit\Module\SyneticsFlows\Automation\Execution;

interface PerformExecution
{
    public function perform(Execution $execution): ExecutionResult;

    public function supports(Execution $execution): bool;
}