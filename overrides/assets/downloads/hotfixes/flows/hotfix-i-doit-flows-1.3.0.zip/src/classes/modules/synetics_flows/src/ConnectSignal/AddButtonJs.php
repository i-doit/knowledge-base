<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\ConnectSignal;

use isys_component_template;
use isys_module_synetics_flows;

class AddButtonJs
{
    public function __construct(
        private isys_component_template $templates,
    )
    {
    }

    public function __invoke(string $type): void
    {
        $objectId = (int)($_GET[C__CMDB__GET__OBJECT] ?? null);

        // @see FLOW-400 Only append JS in object context.
        if ($objectId <= 0) {
            return;
        }

        $this->templates->appendJavascript(isys_module_synetics_flows::getWwwPath() . 'assets/js/automation_buttons.js');
    }
}
