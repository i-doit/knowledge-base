<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Trigger\TriggerType;

class ApiCallTriggerType extends TriggerType
{

}