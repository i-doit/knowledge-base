<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Trigger\Invocation;

class TimeInvocation extends Invocation
{
    public const TYPE = 'schedule';

    public function __toString(): string
    {
        return 'On schedule';
    }
}