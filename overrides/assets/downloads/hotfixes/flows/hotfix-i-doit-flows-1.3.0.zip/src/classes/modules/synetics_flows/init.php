<?php
/**
 * i-doit
 *
 * Admin Center 2.0
 *
 * @package   synetics_flows add-on
 * @copyright synetics
 * @license   https://www.i-doit.com/
 */

use Symfony\Component\Config\FileLocator;
use Symfony\Component\Routing\Loader\PhpFileLoader;

if (isys_module_manager::instance()->is_active('synetics_flows')) {
    require __DIR__ . '/vendor/autoload.php';

    $container = isys_application::instance()->container;

    $container->get('routes')
        ->addCollection((new PhpFileLoader(new FileLocator(__DIR__)))->load('config/routes.php'));
}
