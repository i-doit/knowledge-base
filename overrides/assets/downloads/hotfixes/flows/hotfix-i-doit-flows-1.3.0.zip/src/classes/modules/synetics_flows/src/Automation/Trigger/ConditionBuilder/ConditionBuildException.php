<?php

namespace idoit\Module\SyneticsFlows\Automation\Trigger\ConditionBuilder;

use Exception;
use Symfony\Component\HttpFoundation\Response;

class ConditionBuildException extends Exception
{
    public static function buildError(string $type, string $message)
    {
        return new self(
            "Something went wrong while building the {$type} Condition: {$message}",
            Response::HTTP_BAD_REQUEST
        );
    }
}
