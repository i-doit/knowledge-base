<?php

namespace idoit\Module\SyneticsFlows\Mailer;

use isys_library_mail;

class FlowMailer extends isys_library_mail
{
    public function __construct()
    {
        parent::__construct();

        $this->AllowEmpty = true;
    }
}
