<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Action\ExecutionInfo;

use idoit\Module\SyneticsFlows\Automation\Action\ActionType\ActionType;

class PlannedExecutionInfo extends ExecutionInfo
{
    public function __construct(private ActionType $actionType)
    {
    }

    public function getActionType(): ActionType
    {
        return $this->actionType;
    }

    public function __toString(): string
    {
        return 'Planned to be executed';
    }
}