<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Trigger\InvocationMatcher;

use idoit\Module\SyneticsFlows\Automation\Automation;
use idoit\Module\SyneticsFlows\Automation\Trigger\Invocation\Invocation;

interface InvocationMatcher
{
    /**
     * @param Invocation $invocation
     *
     * @return iterable<Automation>
     */
    public function findAutomations(Invocation $invocation): iterable;

    public function supports(Invocation $invocation): bool;
}