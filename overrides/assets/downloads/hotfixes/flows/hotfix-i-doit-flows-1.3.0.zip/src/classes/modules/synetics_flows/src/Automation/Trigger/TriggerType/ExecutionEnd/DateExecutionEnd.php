<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsFlows\Automation\Trigger\TriggerType\ExecutionEnd;

use idoit\Module\SyneticsFlows\Validation\Required;

class DateExecutionEnd extends ExecutionEnd
{
    public function __construct(
        #[Required]
        private ?string $value = null,
    )
    {
    }

    public function getValue(): ?string
    {
        return $this->value;
    }
}