<?php

namespace idoit\Module\SyneticsFlows\Automation\Trigger\ConditionBuilder;

use idoit\Module\SyneticsFlows\Dto\Criteria;

interface ConditionBuilder
{
    public function buildSqlCriteria(string $field, Criteria $criteria): string;
}
