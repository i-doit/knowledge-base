<?php

use phpseclib3\Crypt\Random;
use phpseclib3\Crypt\Rijndael;
use phpseclib3\Exception\BadDecryptionException;

/**
 * i-doit
 *
 * Helper methods for Crypting via phpseclib
 *
 * @package     i-doit
 * @subpackage  Helper
 * @copyright   i-doit GmbH
 * @license     http://www.i-doit.com/license
 * @since       1.0
 */
class isys_helper_crypt
{
    /**
     * Default delimiter
     *
     * @type string
     */
    const DELIMITER = '|$$|';

    /**
     * Normalize a key to a size phpseclib3's Rijndael accepts (16/20/24/28/32 bytes), matching the old phpseclib2_compat behaviour.
     *
     * @param string $key
     * @return string
     */
    private static function normalizeKey(string $key): string
    {
        $length = strlen($key);
        $keyLength = match (true) {
            $length <= 16 => 16,
            $length <= 20 => 20,
            $length <= 24 => 24,
            $length <= 28 => 28,
            default => 32,
        };

        return str_pad(substr($key, 0, $keyLength), $keyLength, "\0");
    }

    /**
     * Builds a Rijndael cipher, keyed with the tenant's crypto hash.
     *
     * @return Rijndael
     */
    private static function createCipher(): Rijndael
    {
        global $g_crypto_hash;

        $cipher = new Rijndael('cbc');
        $cipher->setKey(self::normalizeKey($g_crypto_hash));

        return $cipher;
    }

    /**
     * Encrypt a string.
     *
     * @param  string|null $string
     *
     * @return string
     */
    public static function encrypt(?string $string): string
    {
        $cipher = self::createCipher();
        $l_iv = Random::string($cipher->getBlockLength() >> 3);
        $cipher->setIV($l_iv);

        $l_crypted_string = $l_iv . self::DELIMITER . $cipher->encrypt((string)$string);

        return base64_encode($l_crypted_string);
    }

    /**
     * Decrypt a string.
     *
     * @param  mixed $string
     *
     * @return string|boolean
     */
    public static function decrypt($string)
    {
        // Decrypted password
        $decryptedPassword = false;

        // Check whether string is really a string
        if (is_string($string)) {
            // Prepare encrypting password
            $base64decoding = base64_decode($string, true);

            // Check whether delimiter is included
            if (str_contains($base64decoding, self::DELIMITER)) {
                // Destruct crypted string into its parts
                $cryptedArray = explode(self::DELIMITER, $base64decoding);

                // Prepare and run decrypting routine
                $cipher = self::createCipher();
                $cipher->setIV($cryptedArray[0]);

                try {
                    // Decrypt password
                    $password = $cipher->decrypt($cryptedArray[1]);
                } catch (BadDecryptionException $e) {
                    $language = isys_application::instance()->container->get('language');

                    isys_application::instance()->container->get('notify')->error(
                        $language->get('LC__CMDB__CATG__PASSWORD__DECRYPTION_ERROR') . '<br /><br />' . $e->getMessage(),
                        ['sticky' => true]
                    );
                } catch (Exception $e) {
                    isys_application::instance()->container->get('notify')->error(
                        $e->getMessage(),
                        ['sticky' => true]
                    );
                }

                // Validate decrypted password
                if (self::validateDecryption($password)) {
                    $decryptedPassword = $password;
                }
            }
        }

        return $decryptedPassword;
    }

    /**
     * Validate decrypted password
     *
     * @param mixed $string
     *
     * @return bool
     */
    public static function validateDecryption($string): bool
    {
        // Needed because of some possible inconsistencies in libiconv
        ini_set('mbstring.substitute_character', 'none');

        // Convert UTF-8 to UTF-8//Ignore - Ignore unknown characters
        $stringWithoutUnknownChars = iconv('UTF-8', 'UTF-8//IGNORE', $string);

        // Check whether string length of target and source are the same
        return strlen($stringWithoutUnknownChars) == strlen($string);
    }

    /**
     * Password Encryption method
     *
     * @param string $string
     *
     * @return string
     *
     */
    public static function encryptPassword(string $string): string
    {
        global $g_security;
        global $g_crypto_hash;
        $string = $g_crypto_hash.$string;

        return match ($g_security['passwords_encryption_method']) {
            'argon2i' => password_hash($string, PASSWORD_ARGON2I),
            default => password_hash($string, PASSWORD_BCRYPT),
        };
    }

    /**
     * Check is password correct
     *
     * @param string $login_password
     * @param string $user_password
     * @param bool   $should_migrated
     *
     * @return bool
     *
     */
    public static function checkPassword(?string $login_password, ?string $user_password, ?bool $should_migrated = false): bool
    {
        global $g_crypto_hash;

        if ($should_migrated) {
            $md5_pass = md5($login_password);
            return password_verify($g_crypto_hash.$md5_pass, $user_password);
        }

        $login_password = $g_crypto_hash.$login_password;
        return password_verify($login_password, $user_password);
    }

    /**
     * Check is password needs to be rehashed
     *
     * @param string $user_pass
     *
     * @return bool
     *
     */
    public static function isPasswordNeedsRehash(string $user_pass): bool
    {
        global $g_security;

        $config_encryption_method = $g_security['passwords_encryption_method'];
        $password_data = password_get_info($user_pass);
        $current_encryption_method = $password_data['algoName'];

        return $config_encryption_method !== $current_encryption_method;
    }

    /**
     * @return string
     */
    public static function getEncryptionMethod(): string
    {
        global $g_security;

        if (isset($g_security['passwords_encryption_method'])) {
            if ($g_security['passwords_encryption_method'] === 'bcrypt') {
                return 'bcrypt';
            }

            if ($g_security['passwords_encryption_method'] === 'argon2i') {
                return 'argon2i';
            }
        }

        return defined('PASSWORD_ARGON2I') ? 'argon2i' : 'bcrypt';
    }
}
