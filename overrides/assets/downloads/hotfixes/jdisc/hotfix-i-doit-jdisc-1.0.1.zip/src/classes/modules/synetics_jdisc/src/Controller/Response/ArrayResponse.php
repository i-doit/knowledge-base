<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsJdisc\Controller\Response;

use Symfony\Component\HttpFoundation\JsonResponse;

class ArrayResponse extends JsonResponse
{
    public function __construct(array $data, ?int $total)
    {
        parent::__construct(new ArrayResult($data, $total));
    }
}
