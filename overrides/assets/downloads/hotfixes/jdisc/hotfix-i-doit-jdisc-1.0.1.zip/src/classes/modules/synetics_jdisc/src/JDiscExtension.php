<?php

namespace idoit\Module\SyneticsJdisc;

use isys_module_synetics_jdisc;
use Symfony\Component\Config\FileLocator;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Extension\Extension;
use Symfony\Component\DependencyInjection\Loader\YamlFileLoader;

class JDiscExtension extends Extension
{
    public function load(array $configs, ContainerBuilder $container)
    {
        $fileLoader = new YamlFileLoader($container, new FileLocator(isys_module_synetics_jdisc::getPath()));
        $fileLoader->load('config/services.yaml');
    }
}
