<?php

class isys_cmdb_ui_category_g_jdisc_device_information extends isys_cmdb_ui_category_global
{
    /**
     * Sets the template file (*.tpl).
     *
     * @param string $p_template
     *
     * @return  isys_cmdb_ui_category
     */
    public function set_template($p_template)
    {
        global $g_dirs;
        $this->m_template_file = $g_dirs["class"] . "/modules/synetics_jdisc/templates/content/bottom/content/" . $p_template;

        return $this;
    }

    public function process(isys_cmdb_dao_category $p_cat)
    {
        $rules = parent::process($p_cat);

        isys_component_template_navbar::getInstance()
            ->set_active(false, C__NAVBAR_BUTTON__EDIT)
            ->set_visible(false, C__NAVBAR_BUTTON__EDIT);

        return $rules;
    }
}
