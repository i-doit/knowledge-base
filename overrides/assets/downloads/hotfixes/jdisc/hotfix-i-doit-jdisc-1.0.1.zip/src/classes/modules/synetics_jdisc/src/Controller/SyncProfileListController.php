<?php

namespace idoit\Module\SyneticsJdisc\Controller;

use idoit\Module\SyneticsJdisc\View\SyncProfileList;
use Symfony\Component\HttpFoundation\Response;

class SyncProfileListController
{
    /**
     * @return Response
     * @throws \Exception
     */
    public function page(): Response
    {
        return SyncProfileList::factory()->render();
    }
}
