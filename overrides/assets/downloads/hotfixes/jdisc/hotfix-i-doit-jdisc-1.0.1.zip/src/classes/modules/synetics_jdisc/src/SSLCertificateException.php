<?php

namespace idoit\Module\SyneticsJdisc;

use Exception;

class SSLCertificateException extends Exception
{

}
