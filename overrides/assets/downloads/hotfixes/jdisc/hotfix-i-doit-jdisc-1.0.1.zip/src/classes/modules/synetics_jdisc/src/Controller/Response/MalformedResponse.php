<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsJdisc\Controller\Response;

use idoit\Module\SyneticsJdisc\Validation\ValidationMessage;
use Symfony\Component\HttpFoundation\JsonResponse;

class MalformedResponse extends JsonResponse
{
    /**
     * @param ValidationMessage[] $errors
     */
    public function __construct(array $errors)
    {
        parent::__construct(['errors' => $errors], empty($errors) ? 200 : 400);
    }
}
