<?php
namespace idoit\Module\SyneticsJdisc\Graphql\Type;

interface TypeInterface
{
    /**
     * @return mixed
     */
    public function getFormattedValue();
}
