<?php

namespace idoit\Module\SyneticsJdisc\Controller\Exception;

use Exception;

class NotFoundException extends Exception
{

}
