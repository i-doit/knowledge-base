<?php

namespace idoit\Module\SyneticsJdisc\Graphql;

interface ParameterBagInterface
{
    /**
     * @return array
     */
    public function getParameters(): array;
}
