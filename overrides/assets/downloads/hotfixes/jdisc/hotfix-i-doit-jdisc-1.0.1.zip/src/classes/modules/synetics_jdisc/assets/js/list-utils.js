window.openDuplicateModal = function(url) {
    var $checkedElements = $$('input[name="id[]"]:checked');

    if ($checkedElements.length === 0) {
        idoit.Notify.info('[{isys type="lang" ident="LC__JDISC__DUPLICATE__SELECT_AT_LEAST_ONE_ENTRY"}]');
        return;
    }

    const ids = $checkedElements.map(x => x.getValue());

    new Ajax.Request(url, {
        method:     'get',
        parameters: {
            'ids': JSON.stringify(ids)
        },
        onComplete: function (xhr) {
            if (!is_json_response(xhr, true)) {
                return;
            }

            const json = xhr.responseJSON;

            Modal.open(json.data, { maxWidth: 640, maxHeight: 320 });
        }
    });
};
