<?php

namespace idoit\Module\SyneticsJdisc\Graphql\Type;

interface EnumTypeInterface
{

}
