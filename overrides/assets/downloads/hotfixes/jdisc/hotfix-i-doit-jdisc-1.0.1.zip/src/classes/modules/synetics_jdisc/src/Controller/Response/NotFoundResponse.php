<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsJdisc\Controller\Response;

use Symfony\Component\HttpFoundation\JsonResponse;

class NotFoundResponse extends JsonResponse
{
    public function __construct(string $model)
    {
        parent::__construct(['error' => $model . ' not found'], 404);
    }
}
