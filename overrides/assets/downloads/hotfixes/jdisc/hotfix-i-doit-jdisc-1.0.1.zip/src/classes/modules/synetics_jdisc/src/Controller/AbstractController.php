<?php

namespace idoit\Module\SyneticsJdisc\Controller;

use isys_application;
use isys_component_template;
use isys_component_template_language_manager;

abstract class AbstractController
{
    public isys_component_template $template;
    public isys_component_template_language_manager $language;

    public function __construct() {
        $this->template = isys_application::instance()->container->get('template');
        $this->language = isys_application::instance()->container->get('language');
    }
}
