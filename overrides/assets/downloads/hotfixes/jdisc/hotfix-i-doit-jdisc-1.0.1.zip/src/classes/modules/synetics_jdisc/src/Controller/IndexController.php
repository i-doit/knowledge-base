<?php

namespace idoit\Module\SyneticsJdisc\Controller;

use idoit\Response\IdoitResponse;
use isys_application;
use isys_module_synetics_jdisc;
use Symfony\Component\HttpFoundation\Response;

class IndexController extends AbstractController
{
    public function page(string $slug = ''): Response
    {
        $container = isys_application::instance()->container;

//        if (!isys_module_synetics_jdisc::isLicensed()) {
//            $this->template
//                ->assign('jdiscDocumentRoot', isys_application::instance()->www_path)
//                ->assign('errorMessage', $container->get('language')->get('LC__MODULE__JDISC__NOT_LICENSED'));
//            return (new IdoitResponse(isys_module_synetics_jdisc::getPath() . 'templates/error.tpl'))->showBreadcrumb(false)->showNavbar(false);
//        }

        // Assign some necessary data.
        $this->template->assign('jsDirectory', isys_module_synetics_jdisc::getWwwPath() . 'js/');
        $this->template->assign('slug', $slug);
        $this->template->assign('title', 'JDisc');
        return (new IdoitResponse(isys_module_synetics_jdisc::getPath() . 'templates/iframe.tpl'))->showBreadcrumb(false)->showNavbar(false);
    }

    public function iframe(): Response
    {
        $container = isys_application::instance()->container;

//        if (!isys_module_synetics_jdisc::isLicensed()) {
//            $this->template
//                ->assign('jdiscDocumentRoot', isys_application::instance()->www_path)
//                ->assign('errorMessage', $container->get('language')->get('LC__MODULE__JDISC__NOT_LICENSED'));
//            return new Response($this->template->fetch(isys_module_synetics_jdisc::getPath() . 'templates/error.tpl'));
//        }

        $auth = isys_module_synetics_jdisc::getAuth();
        $language = isys_application::instance()->container->get('language');

//        if (!isys_module_synetics_jdisc::isLicensed()) {
//            $this->template
//                ->assign('errorMessage', $language->get('LC__MODULE__JDISC__NOT_LICENSED'));
//            return new Response($this->template->fetch(isys_module_synetics_jdisc::getPath() . 'templates/error.tpl'));
//        }
        // Assign some necessary data. @todo add authorization
        $this->template
            ->assign('jsDirectory', isys_module_synetics_jdisc::getWwwPath() . 'js/');
        return new Response($this->template->fetch(isys_module_synetics_jdisc::getPath() . 'templates/index.tpl'));
    }
}
