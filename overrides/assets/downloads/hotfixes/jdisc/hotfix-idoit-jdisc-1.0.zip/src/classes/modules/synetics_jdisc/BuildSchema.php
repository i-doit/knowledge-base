<?php

include_once('./vendor/autoload.php');

$schema = Axtiva\FlexibleGraphql\Utils\SchemaBuilder::build('GraphQL_Schema.txt');

$namespace = 'idoit\Module\SyneticsJdisc\Graphql\Schema';
$schemaPath = './src/Graphql/Schema';

if (!is_dir($schemaPath)) {
    mkdir($schemaPath, 0775, true);
}

$builder = new Axtiva\FlexibleGraphql\Builder\Foundation\CodeGeneratorBuilder(
    new Axtiva\FlexibleGraphql\Generator\Config\Foundation\Psr4\CodeGeneratorConfig(
        $schemaPath,
        Axtiva\FlexibleGraphql\Generator\Config\Foundation\Psr4\CodeGeneratorConfig::V7_4,
        $namespace
    )
);
$generator = $builder->build();
foreach ($generator->generateAllTypes($schema) as $filename);
