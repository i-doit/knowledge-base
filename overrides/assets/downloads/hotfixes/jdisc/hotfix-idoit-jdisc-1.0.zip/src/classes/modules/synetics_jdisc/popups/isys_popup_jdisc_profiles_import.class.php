<?php

class isys_popup_jdisc_profiles_import extends isys_component_popup
{
    /**
     * Handles SMARTY request for dialog plus lists and builds the list base on the specified table.
     *
     * @param isys_component_template & $p_tplclass
     * @param array                     $p_params
     *
     * @return  string
     */
    public function handle_smarty_include(isys_component_template $p_tplclass, $p_params)
    {
        return '';
    }

    /**
     * Method for handling the module request.
     *
     * @param isys_module_request $p_modreq
     *
     * @return void
     * @throws \idoit\Exception\JsonException
     */
    public function &handle_module_request(isys_module_request $p_modreq)
    {
        $rules = [
            'C__JDISC_PROFILES__MERGE_PROFILES' => [
                'p_arData'     => get_smarty_arr_YES_NO(),
                'p_bDbFieldNN' => true,
                'p_strClass'   => 'input-mini'
            ],
            'C__JDISC_PROFILES__UPLOAD'         => [
                'p_strClass' => 'input-block'
            ]
        ];

        $this->template->activate_editmode()
            ->assign('redirectUrl', isys_application::instance()->container->get('request')->request->get('redirectUrl'))
            ->smarty_tom_add_rules('tom.popup.profilesImport', $rules)
            ->display(isys_module_synetics_jdisc::getPath() . 'templates/popup/popupImport.tpl');
        die;
    }
}
