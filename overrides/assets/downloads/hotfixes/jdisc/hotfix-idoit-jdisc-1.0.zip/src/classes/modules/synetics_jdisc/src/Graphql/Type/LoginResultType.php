<?php

namespace idoit\Module\SyneticsJdisc\Graphql\Type;

class LoginResultType extends AbstractType implements EnumTypeInterface
{
    public static function getType(): string
    {
        return 'LoginResult';
    }
}
