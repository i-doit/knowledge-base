<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsJdisc\Controller\Response;

use Symfony\Component\HttpFoundation\JsonResponse;

class IdResponse extends JsonResponse
{
    public function __construct(string $id)
    {
        parent::__construct(['id' => $id]);
    }
}
