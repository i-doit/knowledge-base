<?php declare(strict_types = 1);

namespace idoit\Module\SyneticsJdisc\Controller\Table;

class Sort
{
    public function __construct(private string $id, private bool $desc)
    {
    }

    public function getId(): string
    {
        return $this->id;
    }

    public function isDesc(): bool
    {
        return $this->desc;
    }

}
