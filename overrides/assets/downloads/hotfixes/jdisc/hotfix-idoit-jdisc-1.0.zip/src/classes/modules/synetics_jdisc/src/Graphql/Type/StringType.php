<?php
namespace idoit\Module\SyneticsJdisc\Graphql\Type;

class StringType extends AbstractType implements TypeInterface
{
    /**
     * @return string
     */
    public static function getType(): string
    {
        return parent::$isRequired ? 'String!' : 'String';
    }

    /**
     * @return string
     */
    public function getFormattedValue(): string
    {
        return $this->getValue();
    }
}
