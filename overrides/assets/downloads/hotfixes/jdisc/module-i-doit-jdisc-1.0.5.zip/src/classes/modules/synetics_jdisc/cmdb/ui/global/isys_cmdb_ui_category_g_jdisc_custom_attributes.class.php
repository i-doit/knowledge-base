<?php

/**
 * i-doit
 *
 * UI: global category for JDisc custom attribute
 *
 * @package     i-doit
 * @subpackage  CMDB_Categories
 * @copyright   i-doit GmbH
 * @license     http://www.i-doit.com/license
 */
class isys_cmdb_ui_category_g_jdisc_custom_attributes extends isys_cmdb_ui_category_global
{
    /**
     * Return the template file path.
     *
     * @return string
     */
    public function get_template()
    {
        return isys_module_synetics_jdisc::getPath() . 'templates/content/bottom/content/catg__jdisc_custom_attributes.tpl';
    }
}
