<?php

use idoit\Component\FeatureManager\FeatureCheckInterface;
use idoit\Component\FeatureManager\FeatureManager;
use idoit\Component\Property\Exception\UnsupportedConfigurationTypeException;
use idoit\Component\Property\Type\CommentaryProperty;
use idoit\Component\Property\Type\DateProperty;
use idoit\Component\Property\Type\TextProperty;

class isys_cmdb_dao_category_g_jdisc_device_information extends isys_cmdb_dao_category_global implements FeatureCheckInterface
{
    /**
     * @param isys_component_database $p_db
     */
    public function __construct(isys_component_database $p_db)
    {
        $this->m_category = 'jdisc_device_information';
        $this->m_multivalued = false;

        parent::__construct($p_db);

        $this->categoryTitle = 'LC__CATG__JDISC_DEVICE_INFORMATION';
        $this->m_is_purgable = false;
    }

    /**
     * Method for returning the properties.
     *
     * @return array
     * @throws UnsupportedConfigurationTypeException
     */
    protected function properties()
    {
        return [
            'importDate'     => (new DateProperty(
                'C__CATG__JDISC_DEVICE_INFORMATION__IMPORT_DATE',
                'LC__CMDB__CATG__JDISC_DEVICE_INFORMATION__IMPORT_DATE',
                'isys_catg_jdisc_device_information_list__import_date',
                'isys_catg_jdisc_device_information_list',
                true,
            ))->mergePropertyUiParams([
                'p_bDisabled' => true,
            ])->mergePropertyProvides([
                C__PROPERTY__PROVIDES__MULTIEDIT => false,
            ]),
            'lastSeen'       => (new DateProperty(
                'C__CATG__JDISC_DEVICE_INFORMATION__LAST_SEEN',
                'LC__CMDB__CATG__JDISC_DEVICE_INFORMATION__LAST_SEEN',
                'isys_catg_jdisc_device_information_list__last_seen',
                'isys_catg_jdisc_device_information_list',
                true,
            ))->mergePropertyUiParams([
                'p_bDisabled' => true,
            ])->mergePropertyProvides([
                C__PROPERTY__PROVIDES__MULTIEDIT => false,
            ]),
            'lastDiscovered' => (new DateProperty(
                'C__CATG__JDISC_DEVICE_INFORMATION__LAST_DISCOVERED',
                'LC__CMDB__CATG__JDISC_DEVICE_INFORMATION__LAST_DISCOVERED',
                'isys_catg_jdisc_device_information_list__last_discovered',
                'isys_catg_jdisc_device_information_list',
                true,
            ))->mergePropertyUiParams([
                'p_bDisabled' => true,
            ])
            ->mergePropertyProvides([
                C__PROPERTY__PROVIDES__MULTIEDIT => false,
            ]),
            'uniqueId'       => (new TextProperty(
                'C__CATG__JDISC_DEVICE_INFORMATION__UNIQUE_ID',
                'LC__CMDB__CATG__JDISC_DEVICE_INFORMATION__UNIQUE_ID',
                'isys_catg_jdisc_device_information_list__unique_id',
                'isys_catg_jdisc_device_information_list',
            )),
            'description'    => (new CommentaryProperty(
                'C__CMDB__CAT__COMMENTARY_' . C__CMDB__CATEGORY__TYPE_GLOBAL . defined_or_default('C__CATG__JDISC_DEVICE_INFORMATION', 'C__CATG__JDISC_DEVICE_INFORMATION'),
                'isys_catg_jdisc_device_information_list__description',
                'isys_catg_jdisc_device_information_list',
            )),
        ];
    }

    /**
     * @param string $uniqueId
     * @return array|null
     * @throws isys_exception_database
     */
    public function getIdentifierDataByUniqueId(string $uniqueId): ?array
    {
        $query = "SELECT DISTINCT
                isys_catg_jdisc_device_information_list__id AS id,
                isys_catg_jdisc_device_information_list__isys_obj__id AS objectId
            FROM isys_catg_jdisc_device_information_list
            WHERE isys_catg_jdisc_device_information_list__unique_id = {$this->convert_sql_text($uniqueId)}
            LIMIT 1;";

        return $this->retrieve($query)->get_row();
    }

    /**
     * @return bool
     */
    public static function isFeatureEnabled(): bool
    {
        return FeatureManager::isFeatureActive('jdisc-category');
    }
}
