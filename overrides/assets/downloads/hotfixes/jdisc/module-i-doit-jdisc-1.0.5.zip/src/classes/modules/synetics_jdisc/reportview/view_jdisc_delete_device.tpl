<div class="view_jdisc_delete_devices">
    [{if $servers}]
    <div class="form">
    <form>
        <ul class="form__items">
            <li class="form__items__field">
                <label
                    for="view-form__servers"
                    class="form__items__field__label"
                >[{isys type="lang" ident="LC__REPORT__VIEW__JDISC_AVAILABILITY__SELECT_SERVER"}]</label>

                [{isys type="f_dialog" name="servers" p_strID="view-form__servers" p_strClass="input form__items__field__input form__items__field__input--select"}]
            </li>
            <li class="form__items__field">
                <label
                    for="view-form__type"
                    class="form__items__field__label"
                >[{isys type="lang" ident="LC__REPORT__FORM__OBJECT_TYPE"}]</label>

                [{isys type="f_dialog" name="types" p_strID="view-form__type" p_strClass="input form__items__field__input form__items__field__input--select"}]
            </li>
            <li class="form__items__field">
                <button
                    id="view-form__load"
                    name="load"
                    class="btn form__items__field__btn form__items__field__btn_icon form__items__field__btn_icon_update"
                >[{isys type="lang" ident="LC__UNIVERSAL__LOAD"}]</button>

                <button
                    id="view-form__delete"
                    name="delete"
                    class="btn form__items__field__btn form__items__field__btn_icon form__items__field__btn_icon_delete"
                    disabled
                >[{isys type="lang" ident="LC__UNIVERSAL__BUTTON_DELETE"}]</button>
            </li>
        </ul>
        <input
            type="hidden"
            id="view-form__devices-size"
            name="devices-size"
            value="[{$devicesSize}]"
        >
        <input
            type="hidden"
            id="view-form__devices-processed"
            name="devices-processed"
            value="[{$devicesProcessed}]"
        >
        <input
            type="hidden"
            id="view-form__no-devices"
            name="no-devices"
            value="[{$noDevices}]"
        >
        <input
            type="hidden"
            id="view-form__delete-devices-confirmation"
            name="delete-devices-confirmation"
            value="[{isys type="lang" ident="LC__REPORT__VIEW__JDISC_DELETE_DEVICES__CONFIRMATION"}]"
        >
        <input
            type="hidden"
            id="view-form__delete-devices-failed"
            name="delete-devices-failed"
            value="[{isys type="lang" ident="LC__REPORT__VIEW__JDISC_DELETE_DEVICES__FAILED"}]"
        >
        <input
            type="hidden"
            id="view-form__delete-devices-success"
            name="delete-devices-success"
            value="[{isys type="lang" ident="LC__REPORT__VIEW__JDISC_DELETE_DEVICES__SUCCESS"}]"
        >
        <input
            type="hidden"
            id="view-form__ajax-url"
            name="ajax-url"
            value="[{$ajaxUrl}]"
        >
    <form>
    </div>
    [{else}]
    <p class="no-servers">[{isys type="lang" ident="LC__REPORT__VIEW__JDISC_AVAILABILITY__NO_SERVERS"}]</p>
    [{/if}]

    <table class="mainTable">
        <thead>
        <tr>
            <th class="checkboxes-column">
                <label class="all-devices">
                    <input
                        type="checkbox"
                        title="[{isys type="lang" ident="LC__MODULE__CMDB__LIST_CHECK_ALL_CURRENT_PAGE"}]"
                        name="all-devices"
                        value="0"
                    />
                </label>
            </th>
            <th>[{isys type="lang" ident="LC__REPORT__VIEW__JDISC_AVAILABILITY__TABLE_HEADER__TITLE"}]</th>
        </tr>
        </thead>
        <tbody>
            <tr><td colspan="2">[{$noDevices}]</td></tr>
        </tbody>

    </table>

    <div class="form form-load-more">
    <form>
        <ul class="form__items">
            <li class="form__items__field">
                <button
                    id="view-form__load-more"
                    name="load-more"
                    class="btn form__items__field__btn form__items__field__btn_icon form__items__field__btn_icon_update hide"
                >[{isys type="lang" ident="LC__UNIVERSAL__LOAD_MORE"}]</button>
            </li>
        </ul>
    <form>
    </div>
</div>

<style>
[{include file="./view_jdisc_delete_device.css"}]
</style>

<script type="text/javascript">
[{include file="./view_jdisc_delete_device.js"}]
</script>
