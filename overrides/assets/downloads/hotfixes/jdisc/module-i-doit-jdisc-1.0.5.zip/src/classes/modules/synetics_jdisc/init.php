<?php
/**
 * i-doit
 *
 * Module initializer
 *
 * @package     i-doit
 * @subpackage  Modules
 * @copyright   i-doit GmbH
 * @license     http://www.i-doit.com/license
 */

use idoit\Component\Autoloader;
use idoit\Component\Download\DownloadType;
use idoit\Component\FeatureManager\FeatureManager;
use idoit\Component\Upload\UploadType;
use idoit\Event\System\Settings\ExtendTenantSettings;
use idoit\Module\SyneticsJdisc\Model\LogsDao;
use idoit\Module\SyneticsJdisc\Upload\JDiscProfiles;
use idoit\Psr4AutoloaderClass;

Autoloader::appendClassmap(include(__DIR__ . '/classmap.php'));

if (isys_module_manager::instance()->is_active('synetics_jdisc')) {
    require __DIR__ . '/vendor/autoload.php';

    define('C__JDISC__TITLE_TRANSFORM__AS_IS', 1);
    define('C__JDISC__TITLE_TRANSFORM__UPPERCASE', 2);
    define('C__JDISC__TITLE_TRANSFORM__LOWERCASE', 3);

    isys_register::factory('additional-dialog-admin-tables')
        ->set('isys_jdisc_status_list');

    Psr4AutoloaderClass::factory()
        ->addNamespace('idoit\Module\SyneticsJdisc', __DIR__ . '/src/')
        ->addNamespace('idoit\Module\Synetics_jdisc', __DIR__ . '/src/');

    $jdiscModule = new isys_module_synetics_jdisc();

    isys_application::instance()->container->get('signals')
        ->connect('mod.cmdb.objectDeleted', [$jdiscModule, 'clearMapping'])
        ->connect('mod.cmdb.afterObjectTypeSave', [$jdiscModule, 'slot_after_obj_type_save'])
        ->connect('mod.cmdb.viewProcessed', [$jdiscModule, 'slot_view_proceessed']);

    // Add report views.
    isys_register::factory('additional-report-views')
        ->set(__DIR__ . '/reportview/isys_report_view_jdisc_availability.class.php')
        ->set(__DIR__ . '/reportview/isys_report_view_jdisc_delete_devices.class.php');

    isys_application::instance()->container->get('upload')
        ->registerUploadType('jdisc.profiles-import', (new UploadType())->setUploadDirectory('/temp/')
            ->setValidExtensions(['json'])
            ->setSizeLimit(16777216) // 16 MB
            ->setCallbackAfterUpload([JDiscProfiles::class, 'processUpload']));

    isys_application::instance()->container->get('download')
        ->registerDownloadType('jdisc.log-file', new DownloadType([LogsDao::class, 'getDownloadPath']));

    if (FeatureManager::isFeatureActive('jdisc-settings')) {
        // Extend system settings.
        isys_application::instance()->container->get('event_dispatcher')
            ->addListener(ExtendTenantSettings::NAME, ['isys_module_synetics_jdisc', 'extendTenantSettings']);
    }
}
