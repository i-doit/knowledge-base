<?php

use idoit\Component\FeatureManager\FeatureCheckInterface;
use idoit\Component\FeatureManager\FeatureManager;

/**
 * i-doit
 *
 * DAO: global category for JDisc custom attributes.
 *
 * @package     i-doit
 * @subpackage  CMDB_Categories
 * @copyright   i-doit GmbH
 * @license     http://www.i-doit.com/license
 */
class isys_cmdb_dao_category_g_jdisc_discovery extends isys_cmdb_dao_category_g_virtual implements FeatureCheckInterface
{
    const C__JDISC_DISCOVERY__TARGET_TYPE__IP           = 'ip';
    const C__JDISC_DISCOVERY__TARGET_TYPE__FQDN         = 'fqdn';
    const C__JDISC_DISCOVERY__TARGET_TYPE__SERIALNUMBER = 'serialnumber';

    /**
     * @param isys_component_database $p_db
     */
    public function __construct(isys_component_database $p_db)
    {
        $this->m_category = 'jdisc_discovery';
        $this->m_multivalued = false;

        parent::__construct($p_db);

        $this->categoryTitle = 'LC__CMDB__CATG__JDISC_DISCOVERY';
        $this->m_is_purgable = false;
    }

    /**
     * Method for returning the properties.
     *
     * @return array
     */
    protected function properties()
    {
        return [];
    }

    /**
     * @return bool
     */
    public static function isFeatureEnabled(): bool
    {
        return FeatureManager::isFeatureActive('jdisc-category');
    }
}
