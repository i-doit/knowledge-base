<?php

namespace idoit\Module\SyneticsJdisc\Graphql;

use Exception;

class GraphqlLoginException extends Exception
{

}
