<?php

/**
 * i-doit
 *
 * UI: global category for jdisc custom attribute
 *
 * @package     i-doit
 * @subpackage  CMDB_Categories
 * @copyright   i-doit GmbH
 * @license     http://www.i-doit.com/license
 */
class isys_cmdb_ui_category_g_jdisc_ca extends isys_cmdb_ui_category_global
{
    /**
     * Process method for displaying the template.
     *
     * @global  array                             $index_includes
     *
     * @param   isys_cmdb_dao_category_g_jdisc_ca & $p_cat
     *
     */
    public function process(isys_cmdb_dao_category $p_cat)
    {
        // Initializing some variables.
        $l_rules = [];
        $l_catdata = $p_cat->get_general_data();
        $l_locales = isys_application::instance()->container->get('locales');

        switch ($l_catdata['isys_jdisc_ca_type__const']) {
            case 'C__JDISC__CA_TYPE__DATE':
                $l_catdata['isys_catg_jdisc_ca_list__content'] = $l_locales->fmt_date($l_catdata['isys_catg_jdisc_ca_list__content']);
                break;
            case 'C__JDISC__CA_TYPE__CURRENCY':
                $l_catdata['isys_catg_jdisc_ca_list__content'] = $l_locales->fmt_numeric(((float)$l_catdata['isys_catg_jdisc_ca_list__content'] / 100));
                break;
            default:
                break;
        }
        $this->fill_formfields($p_cat, $l_rules, $l_catdata);

        // Apply rules.
        $this->get_template_component()
            ->smarty_tom_add_rules("tom.content.bottom.content", $l_rules);

        return $l_rules;
    }

    /**
     * Return the template file path.
     *
     * @return string
     */
    public function get_template()
    {
        return isys_module_synetics_jdisc::getPath() . 'templates/content/bottom/content/catg__jdisc_ca.tpl';
    }
}
