<?php

namespace idoit\Exception;

/**
 * Date Exception
 *
 * @package     i-doit
 * @subpackage  Core
 * @author      Leonard Fischer <lfischer@i-doit.com>
 * @copyright   synetics GmbH
 * @license     http://www.i-doit.com/license
 * @since       21
 */
class InvalidCacheDataException extends \Exception
{
}
