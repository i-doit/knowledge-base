@echo off
setlocal

echo.
echo  ============================================================
echo   i-doit IIS Installer for Windows Server
echo  ============================================================
echo.

:: Check for administrator privileges
net session >nul 2>&1
if %errorLevel% == 0 goto :run

echo  This installer requires administrator privileges.
echo  Requesting elevation...
echo.
PowerShell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
exit /b

:run
cd /d "%~dp0"
echo  Starting installation...
echo.
PowerShell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if %errorLevel% neq 0 (
    echo.
    echo  Installation failed. Check the log file in the logs\ folder.
    echo.
)
pause
