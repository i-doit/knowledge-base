﻿#Requires -RunAsAdministrator
# =============================================================================
#  i-doit Windows IIS Installer
#  Tested: i-doit 38, Windows Server 2022, PHP 8.2, MariaDB 10.6
# =============================================================================

param(
    [string]$DbRootPassword      = "idoit_secure_password",
    [string]$DbIdoitPassword     = "idoit_secure_password",
    [string]$AdminCenterPassword = "admin123",
    [string]$TenantName          = "My Company"
)

# =============================================================================
# CONFIGURATION -- adjust versions here if needed
# =============================================================================
$PHP_VERSION     = "8.2.30"
$MARIADB_VERSION = "10.6.25"

$PHP_URL        = "https://windows.php.net/downloads/releases/php-$PHP_VERSION-nts-Win32-vs16-x64.zip"
$VCREDIST_URL   = "https://aka.ms/vs/16/release/vc_redist.x64.exe"
$MARIADB_URL    = "https://archive.mariadb.org/mariadb-$MARIADB_VERSION/winx64-packages/mariadb-$MARIADB_VERSION-winx64.msi"
$URLREWRITE_URL = "https://download.microsoft.com/download/1/2/8/128E2E22-C1B9-44A4-BE2A-5859ED1D4592/rewrite_amd64_en-US.msi"

$INSTALL_DIR    = "C:\inetpub\wwwroot"
$PHP_DIR        = "C:\PHP"
$MARIADB_BIN    = "C:\Program Files\MariaDB 10.6\bin"
$MARIADB_DATA   = "C:\Program Files\MariaDB 10.6\data"

$SCRIPT_DIR     = Split-Path -Parent $MyInvocation.MyCommand.Path
$DOWNLOAD_DIR   = Join-Path $SCRIPT_DIR "downloads"
$LOG_DIR        = Join-Path $SCRIPT_DIR "logs"
$LOG_FILE       = Join-Path $LOG_DIR "install_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"

# =============================================================================
# HELPER FUNCTIONS
# =============================================================================
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $ts   = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts] [$Level] $Message"
    Add-Content -Path $LOG_FILE -Value $line -ErrorAction SilentlyContinue
    switch ($Level) {
        "STEP"    { Write-Host "`n>>> $Message <<<" -ForegroundColor White -BackgroundColor DarkBlue }
        "SUCCESS" { Write-Host "    [OK]   $Message" -ForegroundColor Green }
        "WARNING" { Write-Host "    [WARN] $Message" -ForegroundColor Yellow }
        "ERROR"   { Write-Host "    [ERR]  $Message" -ForegroundColor Red }
        default   { Write-Host "           $Message" -ForegroundColor Cyan }
    }
}

function Invoke-Step {
    param(
        [string]$Description,
        [scriptblock]$Action,
        [string]$DebugHint = ""
    )
    Write-Log $Description "STEP"
    try {
        & $Action
        Write-Log "$Description completed." "SUCCESS"
    }
    catch {
        Write-Log "FAILED: $_" "ERROR"
        if ($DebugHint) {
            Write-Log "Debug: $DebugHint" "WARNING"
        }
        Write-Log "Full log: $LOG_FILE" "WARNING"
        Write-Host ""
        Read-Host "Press Enter to exit"
        exit 1
    }
}

function Save-Download {
    param([string]$Url, [string]$Dest, [string]$Label)
    if (Test-Path $Dest) {
        Write-Log "$Label already in downloads folder -- skipping." "SUCCESS"
        return
    }
    Write-Log "Downloading $Label ..."
    $ProgressPreference = 'SilentlyContinue'
    Invoke-WebRequest -Uri $Url -OutFile $Dest -UseBasicParsing -ErrorAction Stop
    $sizeMB = [math]::Round((Get-Item $Dest).Length / 1MB, 1)
    Write-Log "$Label downloaded ($sizeMB MB)." "SUCCESS"
}

function Wait-ForMariaDB {
    $mysql = Join-Path $MARIADB_BIN "mysql.exe"
    Write-Log "Waiting for MariaDB to accept connections..."
    for ($i = 1; $i -le 40; $i++) {
        $out = & $mysql -u root -p"$DbRootPassword" --connect-timeout=2 -e "SELECT 1" 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-Log "MariaDB is ready." "SUCCESS"
            return
        }
        Write-Log "Attempt $i/40 -- retrying in 3 s..."
        Start-Sleep -Seconds 3
    }
    throw "MariaDB did not become ready within 2 minutes."
}

# =============================================================================
# INIT
# =============================================================================
New-Item -ItemType Directory -Force -Path $DOWNLOAD_DIR | Out-Null
New-Item -ItemType Directory -Force -Path $LOG_DIR      | Out-Null

Write-Host ""
Write-Host "  ============================================================" -ForegroundColor Green
Write-Host "   i-doit Windows IIS Installer" -ForegroundColor Green
Write-Host "  ============================================================" -ForegroundColor Green
Write-Host ""
Write-Log "Installer started. Log file: $LOG_FILE"
Write-Log "Script directory: $SCRIPT_DIR"
Write-Log "PHP version: $PHP_VERSION | MariaDB version: $MARIADB_VERSION"

# =============================================================================
# STEP 1 -- Download all prerequisites
# =============================================================================
Invoke-Step "Step 1/12 -- Download prerequisites" {
    Save-Download $VCREDIST_URL   (Join-Path $DOWNLOAD_DIR "vc_redist.x64.exe") "Visual C++ 2019 Redistributable"
    Save-Download $PHP_URL        (Join-Path $DOWNLOAD_DIR "php.zip")           "PHP $PHP_VERSION NTS x64"
    Save-Download $URLREWRITE_URL (Join-Path $DOWNLOAD_DIR "urlrewrite.msi")    "IIS URL Rewrite Module"
    Save-Download $MARIADB_URL    (Join-Path $DOWNLOAD_DIR "mariadb.msi")       "MariaDB $MARIADB_VERSION"

    # i-doit: fetch latest version from official update feed
    Write-Log "Fetching i-doit download URL from update feed (i-doit.com/updates.xml)..."
    [xml]$xml = (Invoke-WebRequest -Uri "https://i-doit.com/updates.xml" -UseBasicParsing -ErrorAction Stop).Content
    $downloadUrl = ($xml.SelectNodes("//filename") | Select-Object -Last 1).InnerText
    $downloadUrl = $downloadUrl -replace "-update\.zip$", ".zip"
    Write-Log "i-doit download URL: $downloadUrl"
    Save-Download $downloadUrl (Join-Path $DOWNLOAD_DIR "idoit.zip") "i-doit (latest)"
} -DebugHint "Check your internet connection. MariaDB is downloaded from archive.mariadb.org -- this is intentional, as downloads.mariadb.com blocks automated downloads with a Cloudflare page."

# =============================================================================
# STEP 2 -- Install IIS features
# =============================================================================
Invoke-Step "Step 2/12 -- Enable IIS with CGI and management features" {
    $features = @(
        "Web-Server", "Web-Common-Http", "Web-Static-Content", "Web-Default-Doc",
        "Web-Http-Errors", "Web-CGI", "Web-ISAPI-Ext", "Web-ISAPI-Filter",
        "Web-Http-Logging", "Web-Stat-Compression", "Web-Filtering",
        "Web-Mgmt-Console", "Web-Scripting-Tools"
    )
    $result = Install-WindowsFeature -Name $features -ErrorAction Stop
    Write-Log "IIS features installed. Restart needed: $($result.RestartNeeded)"
} -DebugHint "Run 'Get-WindowsFeature Web-Server' to check IIS status. This step requires Windows Server. On Windows 10/11 use 'Enable-WindowsOptionalFeature' instead."

# =============================================================================
# STEP 3 -- Install Visual C++ 2019 Redistributable
# =============================================================================
Invoke-Step "Step 3/12 -- Install Visual C++ 2019 Redistributable (required for PHP 8.2)" {
    $exe  = Join-Path $DOWNLOAD_DIR "vc_redist.x64.exe"
    $proc = Start-Process -FilePath $exe -ArgumentList "/quiet", "/norestart" -Wait -PassThru
    # 0=success, 1638=already installed, 3010=success+reboot pending
    if ($proc.ExitCode -notin @(0, 1638, 3010)) {
        throw "VC++ installer exited with code $($proc.ExitCode)"
    }
    if ($proc.ExitCode -eq 1638) { Write-Log "VC++ Redistributable already installed." "SUCCESS" }
} -DebugHint "PHP 8.2 NTS VS16 requires the Microsoft Visual C++ 2019 runtime. Without it, php-cgi.exe crashes with STATUS_DLL_NOT_FOUND (exit code -1073741515). Exit code 1638 means it was already installed -- that is fine."

# =============================================================================
# STEP 4 -- Install PHP
# =============================================================================
Invoke-Step "Step 4/12 -- Install PHP $PHP_VERSION NTS" {
    $phpZip = Join-Path $DOWNLOAD_DIR "php.zip"
    New-Item -ItemType Directory -Force -Path $PHP_DIR | Out-Null
    Expand-Archive -Path $phpZip -DestinationPath $PHP_DIR -Force

    # Create php.ini from production template
    $phpIni = Join-Path $PHP_DIR "php.ini"
    Copy-Item (Join-Path $PHP_DIR "php.ini-production") $phpIni -Force

    # Read ini, apply all settings
    $ini = Get-Content $phpIni -Raw

    # Extension directory
    $ini = $ini -replace '(?m)^;?\s*extension_dir\s*=.*', "extension_dir = `"$PHP_DIR\ext`""

    # Enable required extensions (uncomment if commented, add if missing)
    $required = @("curl","fileinfo","gd","ldap","mbstring","mysqli","openssl","pdo_mysql","soap","sockets","zip","intl")
    foreach ($ext in $required) {
        if ($ini -match "(?m)^;extension=$ext\b") {
            $ini = $ini -replace "(?m)^;extension=$ext\b", "extension=$ext"
        } elseif ($ini -notmatch "(?m)^extension=$ext\b") {
            $ini += "`r`nextension=$ext"
        }
    }

    # PHP settings for i-doit
    $ini = $ini -replace '(?m)^;?\s*max_execution_time\s*=.*',      'max_execution_time = 300'
    $ini = $ini -replace '(?m)^;?\s*max_input_vars\s*=.*',          'max_input_vars = 10000'
    $ini = $ini -replace '(?m)^;?\s*memory_limit\s*=.*',            'memory_limit = 256M'
    $ini = $ini -replace '(?m)^;?\s*post_max_size\s*=.*',           'post_max_size = 128M'
    $ini = $ini -replace '(?m)^;?\s*upload_max_filesize\s*=.*',     'upload_max_filesize = 128M'
    $ini = $ini -replace '(?m)^;?\s*file_uploads\s*=.*',            'file_uploads = On'
    $ini = $ini -replace '(?m)^;?\s*allow_url_fopen\s*=.*',         'allow_url_fopen = On'
    $ini = $ini -replace '(?m)^;?\s*short_open_tag\s*=.*',          'short_open_tag = On'
    $ini = $ini -replace '(?m)^;?\s*date\.timezone\s*=.*',          'date.timezone = Europe/Berlin'
    $ini = $ini -replace '(?m)^;?\s*session\.gc_maxlifetime\s*=.*', 'session.gc_maxlifetime = 604800'
    $ini = $ini -replace '(?m)^;?\s*curl\.cainfo\s*=.*', "curl.cainfo = $PHP_DIR\\cacert.pem"
    $ini = $ini -replace '(?m)^;?\s*openssl\.cafile\s*=.*', "openssl.cafile = $PHP_DIR\\cacert.pem"

    Set-Content -Path $phpIni -Value $ini -NoNewline

    # Download CA certificate bundle (required for PHP cURL SSL verification on Windows)
    $cacert = Join-Path $PHP_DIR "cacert.pem"
    Write-Log "Downloading Mozilla CA certificate bundle (cacert.pem)..."
    $ProgressPreference = "SilentlyContinue"
    Invoke-WebRequest -Uri "https://curl.se/ca/cacert.pem" -OutFile $cacert -UseBasicParsing -ErrorAction Stop
    Write-Log "cacert.pem downloaded."
    $ProgressPreference = "Continue"

    # Add PHP to system PATH
    $syspath = [System.Environment]::GetEnvironmentVariable("Path", "Machine")
    if ($syspath -notlike "*$PHP_DIR*") {
        [System.Environment]::SetEnvironmentVariable("Path", "$syspath;$PHP_DIR", "Machine")
    }
    $env:Path = "$env:Path;$PHP_DIR"

    # Verify PHP works
    $ver = & "$PHP_DIR\php.exe" -v 2>&1 | Select-Object -First 1
    Write-Log "PHP check: $ver"
} -DebugHint "If php.exe exits with STATUS_DLL_NOT_FOUND, the VC++ 2019 Redistributable (Step 3) was not installed correctly. If extension errors appear, check that the ext\ folder exists under $PHP_DIR and contains the .dll files."

# =============================================================================
# STEP 5 -- Install IIS URL Rewrite Module
# =============================================================================
Invoke-Step "Step 5/12 -- Install IIS URL Rewrite Module" {
    $msi  = Join-Path $DOWNLOAD_DIR "urlrewrite.msi"
    $proc = Start-Process "msiexec.exe" -ArgumentList "/i `"$msi`" /quiet /norestart" -Wait -PassThru
    if ($proc.ExitCode -notin @(0, 1638, 3010)) {
        throw "URL Rewrite installer exited with code $($proc.ExitCode)"
    }
} -DebugHint "The URL Rewrite module is required for i-doit's clean URLs. Without it, all requests return 404 except direct calls to index.php. If exit code 1638, it was already installed."

# =============================================================================
# STEP 6 -- Install MariaDB
# =============================================================================
Invoke-Step "Step 6/12 -- Install MariaDB $MARIADB_VERSION" {
    $msi  = Join-Path $DOWNLOAD_DIR "mariadb.msi"
    $proc = Start-Process "msiexec.exe" -ArgumentList @(
        "/i", "`"$msi`"",
        "/quiet", "/norestart",
        "SERVICENAME=MariaDB",
        "PORT=3306",
        "PASSWORD=$DbRootPassword",
        "ALLOWREMOTEROOTACCESS=1",
        "SKIPNETWORKING=0"
    ) -Wait -PassThru
    if ($proc.ExitCode -notin @(0, 3010)) {
        throw "MariaDB MSI exited with code $($proc.ExitCode). If code is 1620, the downloaded file is not a valid MSI -- delete downloads\mariadb.msi and re-run."
    }

    # The MSI quiet install may not always register the Windows service.
    # Register it manually if missing.
    $svc = Get-Service -Name "MariaDB" -ErrorAction SilentlyContinue
    if (-not $svc) {
        Write-Log "MariaDB service not registered by MSI -- registering manually..." "WARNING"
        $mysqld = Join-Path $MARIADB_BIN "mysqld.exe"
        & $mysqld --install MariaDB
        if ($LASTEXITCODE -ne 0) {
            throw "Failed to register MariaDB service (mysqld --install returned $LASTEXITCODE)"
        }
        Start-Sleep -Seconds 2
    }

    Start-Service -Name "MariaDB" -ErrorAction Stop
    Start-Sleep -Seconds 2

    Wait-ForMariaDB
} -DebugHint "If MariaDB fails to start, check: (1) Is port 3306 already in use? Run: netstat -ano | findstr 3306. (2) Check Windows Event Log: Get-EventLog -LogName Application -Source MariaDB -Newest 5. (3) If MSI exit code was 1620, the downloaded file is corrupted -- delete downloads\mariadb.msi and re-run the installer."

# =============================================================================
# STEP 7 -- Configure MariaDB (performance settings for i-doit)
# =============================================================================
Invoke-Step "Step 7/12 -- Configure MariaDB (i-doit optimized settings)" {
    $myIni = Join-Path $MARIADB_DATA "my.ini"

    # Rewrite my.ini: enable TCP networking and apply i-doit optimized settings
    $newIni = @"
[mysqld]
datadir=C:/Program Files/MariaDB 10.6/data
port=3306
skip-networking=OFF
named-pipe=ON
socket=MariaDB
innodb_buffer_pool_size=1G
innodb_log_file_size=512M
max_allowed_packet=128M
max_connections=200
innodb_file_per_table=1
innodb_flush_log_at_trx_commit=1
innodb_flush_method=O_DIRECT
innodb_stats_on_metadata=0
tmp_table_size=32M
max_heap_table_size=32M
sort_buffer_size=262144
join_buffer_size=262144
sql_mode=
[client]
socket=MariaDB
protocol=pipe
plugin-dir=C:\Program Files\MariaDB 10.6/lib/plugin
"@
    [System.IO.File]::WriteAllText($myIni, $newIni, [System.Text.Encoding]::ASCII)
    Write-Log "my.ini rewritten with TCP enabled and i-doit settings."

    Restart-Service -Name "MariaDB" -ErrorAction Stop
    Wait-ForMariaDB

    # Create i-doit database user
    $mysql = Join-Path $MARIADB_BIN "mysql.exe"
    $sql   = "CREATE USER IF NOT EXISTS 'idoit'@'localhost' IDENTIFIED BY '$DbIdoitPassword'; " +
             "GRANT ALL PRIVILEGES ON idoit_system.* TO 'idoit'@'localhost'; " +
             "GRANT ALL PRIVILEGES ON idoit_data.* TO 'idoit'@'localhost'; " +
             "FLUSH PRIVILEGES;"
    & $mysql -u root -p"$DbRootPassword" -e $sql
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to create i-doit database user."
    }
    Write-Log "Database user 'idoit' created."
} -DebugHint "If MariaDB does not restart, check that the my.ini settings are valid. The innodb_flush_method=O_DIRECT is supported on Windows but may generate a warning -- this is harmless. Note: query_cache_* settings are NOT used as the query cache was removed in MariaDB 10.6."

# =============================================================================
# STEP 8 -- Register PHP with IIS (FastCGI)
# =============================================================================
Invoke-Step "Step 8/12 -- Register PHP with IIS (FastCGI handler)" {
    $appcmd = "$env:windir\system32\inetsrv\appcmd.exe"
    $phpCgi = "$PHP_DIR\php-cgi.exe"

    # Register FastCGI application pool
    & $appcmd set config /section:system.webServer/fastCGI `
        "/+[fullPath='$phpCgi',maxInstances='4',instanceMaxRequests='10000']" 2>&1 |
        ForEach-Object { Write-Log $_ }

    # Add PHP file handler (*.php -> FastCGI -> php-cgi.exe)
    & $appcmd set config /section:system.webServer/handlers `
        "/+[name='PHP_FastCGI',path='*.php',verb='GET,HEAD,POST',modules='FastCgiModule',scriptProcessor='$phpCgi',resourceType='Either',requireAccess='Script']" 2>&1 |
        ForEach-Object { Write-Log $_ }

    # Verify: test php-cgi.exe responds
    $test = & $phpCgi -v 2>&1 | Select-Object -First 1
    Write-Log "PHP-CGI check: $test"
} -DebugHint "If .php files download instead of execute, the FastCGI handler is missing. Check: appcmd list config /section:system.webServer/handlers | findstr PHP. If appcmd reports 'ERROR: Cannot find requested object', IIS was not installed with the CGI feature (Step 2 failed)."

# =============================================================================
# STEP 9 -- Deploy i-doit
# =============================================================================
Invoke-Step "Step 9/12 -- Extract i-doit to $INSTALL_DIR" {
    $idoitZip = Join-Path $DOWNLOAD_DIR "idoit.zip"

    # Remove old content but keep web.config if it exists
    Get-ChildItem $INSTALL_DIR -Exclude "web.config" |
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue

    Expand-Archive -Path $idoitZip -DestinationPath $INSTALL_DIR -Force
    Write-Log "i-doit extracted to $INSTALL_DIR."

    # Grant IIS_IUSRS full control (needed for i-doit file operations)
    $acl  = Get-Acl $INSTALL_DIR
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
        "IIS_IUSRS", "FullControl",
        [System.Security.AccessControl.InheritanceFlags]"ContainerInherit,ObjectInherit",
        [System.Security.AccessControl.PropagationFlags]"None",
        [System.Security.AccessControl.AccessControlType]"Allow"
    )
    $acl.SetAccessRule($rule)
    Set-Acl -Path $INSTALL_DIR -AclObject $acl
    Write-Log "Permissions set for IIS_IUSRS on $INSTALL_DIR."
} -DebugHint "If extraction fails with 'path too long', enable long path support: New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem' -Name 'LongPathsEnabled' -Value 1 -PropertyType DWORD -Force. If permission errors, ensure the script runs as Administrator."

# =============================================================================
# STEP 10 -- Create web.config
# =============================================================================
Invoke-Step "Step 10/12 -- Create web.config (URL rewrite rules)" {
    $webConfigPath = Join-Path $INSTALL_DIR "web.config"
    $webConfig = [System.Text.Encoding]::UTF8.GetBytes(@"
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <system.webServer>
        <defaultDocument enabled="false" />
        <rewrite>
            <rules>
                <rule name="idoit_root" stopProcessing="true">
                    <match url="^$" />
                    <action type="Rewrite" url="index.php" />
                </rule>
                <rule name="idoit_admin_slash" stopProcessing="true">
                    <match url="^admin$" />
                    <action type="Redirect" url="/admin/" redirectType="Permanent" />
                </rule>
                <rule name="idoit_admin" stopProcessing="true">
                    <match url="^admin(/.*)?$" />
                    <conditions logicalGrouping="MatchAll">
                        <add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />
                    </conditions>
                    <action type="Rewrite" url="admin/index.php" />
                </rule>
                <rule name="idoit" stopProcessing="true">
                    <match url=".*" />
                    <conditions logicalGrouping="MatchAll">
                        <add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />
                        <add input="{REQUEST_FILENAME}" matchType="IsDirectory" negate="true" />
                    </conditions>
                    <action type="Rewrite" url="index.php" />
                </rule>
            </rules>
        </rewrite>
    </system.webServer>
</configuration>
"@)
    [System.IO.File]::WriteAllBytes($webConfigPath, $webConfig)
    Write-Log "web.config written to $webConfigPath."
} -DebugHint "If i-doit shows 404 for sub-pages (e.g. /cmdb/), the URL Rewrite module (Step 5) is not installed. If the root URL returns 403, the defaultDocument section is missing or web.config was not applied."

# =============================================================================
# STEP 11 -- Install i-doit (database setup + tenant)
# =============================================================================
Invoke-Step "Step 11/12 -- Initialize i-doit database" {
    $php     = Join-Path $PHP_DIR "php.exe"
    $console = Join-Path $INSTALL_DIR "console.php"

    Write-Log "Running console.php install (this may take 1-2 minutes)..."
    & $php $console install `
        -u root -p "$DbRootPassword" `
        --host "127.0.0.1" `
        -d idoit_system `
        -U idoit -P "$DbIdoitPassword" `
        --admin-password "$AdminCenterPassword" -n 2>&1 |
        ForEach-Object { Write-Log $_ }

    if ($LASTEXITCODE -ne 0) {
        throw "console.php install failed (exit code $LASTEXITCODE). Check the i-doit log in $INSTALL_DIR\log\"
    }

    Write-Log "Running console.php tenant-create..."
    & $php $console tenant-create `
        -u root -p "$DbRootPassword" `
        -U idoit -P "$DbIdoitPassword" `
        -d idoit_data `
        -t "$TenantName" -n 2>&1 |
        ForEach-Object { Write-Log $_ }

    if ($LASTEXITCODE -ne 0) {
        throw "console.php tenant-create failed (exit code $LASTEXITCODE). Check the i-doit log in $INSTALL_DIR\log\"
    }
} -DebugHint "If console.php fails with 'Class not found' or extension errors, a required PHP extension is missing. Run: php -m | findstr <ext>. Common missing extensions: sockets, pdo_mysql. Check php.ini at $PHP_DIR\php.ini. If 'Access denied' for MariaDB, verify the root password matches what was set during MariaDB install."

# =============================================================================
# STEP 12 -- Final IIS restart
# =============================================================================
Invoke-Step "Step 12/12 -- Restart IIS" {
    iisreset /noforce | Out-Null
} -DebugHint "If iisreset fails, check Windows Event Log: Get-EventLog -LogName System -Source W3SVC -Newest 5."

# =============================================================================
# SUCCESS SUMMARY
# =============================================================================
$serverIp = (Get-NetIPAddress -AddressFamily IPv4 |
    Where-Object { $_.InterfaceAlias -notmatch "Loopback" -and $_.PrefixOrigin -ne "WellKnown" } |
    Select-Object -First 1).IPAddress

Write-Host ""
Write-Host "  ============================================================" -ForegroundColor Green
Write-Host "   i-doit installation completed successfully!" -ForegroundColor Green
Write-Host "  ============================================================" -ForegroundColor Green
Write-Host ""
Write-Host "  i-doit is now available at:" -ForegroundColor White
Write-Host "  http://$serverIp/" -ForegroundColor Yellow
Write-Host ""
Write-Host "  i-doit login" -ForegroundColor White
Write-Host "    URL      : http://$serverIp/" -ForegroundColor Cyan
Write-Host "    Username : admin" -ForegroundColor Cyan
Write-Host "    Password : admin" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Admin Center" -ForegroundColor White
Write-Host "    URL      : http://$serverIp/admin/" -ForegroundColor Cyan
Write-Host "    Username : admin" -ForegroundColor Cyan
Write-Host "    Password : $AdminCenterPassword" -ForegroundColor Cyan
Write-Host ""
Write-Host "  MariaDB" -ForegroundColor White
Write-Host "    Root     : root / $DbRootPassword" -ForegroundColor Cyan
Write-Host "    i-doit   : idoit / $DbIdoitPassword" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Recommendation:" -ForegroundColor White
Write-Host "  Log in to the Admin Center first and activate your i-doit" -ForegroundColor Yellow
Write-Host "  license under 'Licenses' before using i-doit." -ForegroundColor Yellow
Write-Host ""
Write-Host "  Log file saved to: $LOG_FILE" -ForegroundColor Gray
Write-Host "  ============================================================" -ForegroundColor Green
Write-Host ""

Write-Log "Installation complete." "SUCCESS"
Write-Log "URL: http://$serverIp/ | i-doit: admin/admin | Admin Center: admin/$AdminCenterPassword | MariaDB root: root/$DbRootPassword" "SUCCESS"
